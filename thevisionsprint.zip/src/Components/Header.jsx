import React, { useState, useEffect } from "react";
import funArrow from "../assets/fun-arrow.svg";
import rocket from "../assets/rocket.svg";

function Header() {
  const words = [
    "expert strategies",
    "innovative plans",
    "creative ideas",
    "smart solutions",
    "expert strategies.",
    "bold moves",
    "proven methods",
    "effective tactics",
    "powerful insights",
    "winning formulas",
  ];

  const [currentWord, setCurrentWord] = useState(words[0]);

  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % words.length;
      setCurrentWord(words[index]);
    }, 5000);
    return () => clearInterval(interval);
  }, [words]);

  return (
    <>
      <header className="bg-gray-900 flex items-center justify-center px-5 min-h-screen">
        <div className="text-center text-white h-auto w-full md:w-1/2 flex flex-col justify-center header_box">
          <h1 className="text-4xl md:text-5xl lg:text-5xl font-bold mb-4 header_heading">
            Take your idea to the next level with{" "}
            <span style={{ color: "var(--heading-color)" }}>
              {" "}
              {currentWord}
            </span>
          </h1>
          <p className="text-lg md:text-xl mb-8">
            Transform your idea into reality with proven strategies, innovative
            solutions, and expert guidance. Unlock your potential, address
            market needs, and build a sustainable foundation for long-term
            success and growth.
          </p>
          <div className="flex justify-center space-x-4">
            <a
              href="#"
              className="text-white font-semibold py-2 px-4 tracking-[1.7px] rounded"
              style={{ background: "var(--primary-color)" }}
            >
              {" "}
              Explore for Free{" "}
            </a>
            <a
              href="#"
              className="text-white font-semibold border rounded py-2 px-4 flex items-center space-x-2"
            >
              <span> Success Stories </span>
            </a>
          </div>
        </div>
        <img src={funArrow} alt="arrow image" className="arrowimg" />
        <img src={rocket} alt="arrow image" className="rocketimg" />
      </header>
    </>
  );
}

export default Header;
