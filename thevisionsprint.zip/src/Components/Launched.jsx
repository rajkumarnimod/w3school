import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRocket} from '@fortawesome/free-solid-svg-icons';
import Check from "./Check";

function Launched() {
  return (
    <>
      <section className="bg-gray-900 flex items-center justify-center px-5 py-12 lg:py-24">
        <div className="text-center text-white h-auto w-full md:w-2/3 lg:w-7/10 flex flex-col justify-center header_box">
          <h2 className="text-3xl md:text-5xl lg:text-4xl font-bold mb-4">
            Register{" "}
            <span style={{ color: "var(--green-color)" }}> Your Startup </span>{" "}
            Today and Gain <FontAwesomeIcon icon={faRocket} className="text-blue-500" /> Instant Visibility and Feedback
          </h2>
          <p className="text-lg md:text-xl mb-8 text-gray-500">
            List your newly launched startup, attract attention from a vast
            audience, receive valuable views and comments, and create a strong
            impression on the very first day of your launch.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-between gap-5">
            <div className="md:w-1/2 p-2 md:p-2 mt-4 md:mt-0 border border-spanText rounded-lg hover:scale-105 transform transition duration-300">
              <h2 className="text-2xl font-bold mb-4">
                Why Register Your Startup?
              </h2>
              <ul>
                <li> <Check /> Instant Visibility </li>
                <li> <Check /> Feedback & Insights </li>
                <li> <Check /> Build Credibility</li>
              </ul>
            </div>
            <div className="md:w-1/2 p-2 md:p-2 mt-4 md:mt-0 border border-headingColor rounded-lg hover:scale-105 transform transition duration-300">
              <h2 className="text-2xl font-bold mb-4">How It Benefits Your Startup</h2>
              <ul>
                <li> <Check /> Reach More People </li>
                <li> <Check /> Community Engagement </li>
                <li> <Check /> Boost Growth </li>
              </ul>
            </div>
          </div>
          <div className="flex justify-center space-x-4 mt-10">
            <a
              href="#"
              className="text-white font-semibold py-2 px-8 tracking-[1.7px] rounded"
              style={{ background: "var(--primary-color)" }}
            >
              Register Your Startup
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

export default Launched;
