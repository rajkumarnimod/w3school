import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLightbulb,faBullhorn,faTools,faGraduationCap} from '@fortawesome/free-solid-svg-icons';

function About() {

  return (
    <section className="bg-gray-900 flex items-center justify-center py-10 px-5 lg:py-24">
      <div className="text-center text-white w-full md:w-2/3 lg:w-10/12 flex flex-col justify-center">
        <h2 className="text-3xl md:text-5xl lg:text-4xl font-bold mb-4">
          {" "}
          <span style={{ color: "var(--heading-color)"}} > About us </span>Startup Made Easy
        </h2>
        <p className="text-lg md:text-xl mb-8 text-gray-500">
        Get step-by-step guidance, essential tools, and free resources <br /> to build, market, and grow your startup successfully.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 border rounded-xl shadow hover:scale-105 transform transition duration-300">
                <FontAwesomeIcon icon={faLightbulb} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Build Your Startup Foundation</h2>
                <p className="text-gray-400">We guide you step-by-step to build a strong startup foundation. From creating business plans to assembling the right team, we provide all the essential knowledge you need to start confidently.</p>
            </div>
            <div className="p-4 border border-headingColor rounded-xl shadow hover:scale-105 transform transition duration-300">
            <FontAwesomeIcon icon={faBullhorn} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Master Marketing Strategies</h2>
                <p className="text-gray-400">Learn marketing strategies that help your startup grow. Our content covers everything from branding to reaching your target audience, ensuring your startup gets the attention it deserves.</p>
            </div>
            <div className="p-4 border rounded-xl shadow hover:scale-105 transform transition duration-300">
            <FontAwesomeIcon icon={faTools} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Access Essential Tools and Resources</h2>
                <p className="text-gray-400">Discover free and useful tools for startups, like logo creation, domain registration, and website setup. We provide everything you need to make your startup stand out in the market.</p>
            </div>
            <div className="p-4 border-2 border-spanText rounded-xl shadow lg:scale-105 transform transition duration-300">
            <FontAwesomeIcon icon={faGraduationCap} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Free Courses for Entrepreneurs</h2>
                <p className="text-gray-400">Explore free courses and resources to gain startup knowledge. From beginner to advanced levels, our courses guide you through every aspect of launching and running a successful business.</p>
            </div>
        </div>
      </div>
    </section>
  );
}

export default About;
