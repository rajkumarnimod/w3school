import React, { useState, useEffect } from "react";
import Logo from "../assets/logo.svg";
import { Link, NavLink } from "react-router-dom";

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll event to change background color
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
   <>
    <div className="topscroll">
  </div>
    <nav
      className={`${
        isScrolled ? "bg-[#111827]" : "bg-transparent"
      } fixed top-0 left-0 w-full z-50 shadow-md`}
    >
      <div className="flex flex-wrap items-center justify-between w-full py-4 px-4 relative lg:px-10">
        {/* Logo */}
        <div>
          <Link to="/" aria-label="Logo" className="flex items-center gap-2">
            <img src={Logo} alt="logo" />
            <span className="text-xl text-white">TheVisionSprint</span>
          </Link>
        </div>

        {/* Toggle Button for Small Screens */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle Menu"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
            />
          </svg>
        </button>

        {/* Navigation Links */}
        <div
          className={`${
            isMenuOpen ? "block" : "hidden"
          } w-full md:flex md:items-center md:w-auto md:mt-0 absolute md:relative top-full left-0 z-50 
          ${isMenuOpen ? "py-5 px-3 bg-gradient-to-b from-[rgb(17,24,39)] to-[rgb(17,24,39)]" : ""}`}
        >
          <ul className="flex flex-col md:flex-row gap-y-5 md:gap-0">
          <li className="md:mr-4">
              <NavLink to="/" className="block text-white py-1 mx-1 md:inline-block">
              Home
              </NavLink>
            </li>
            <li className="md:mr-4 navhidden">
              <NavLink to="/about" className="block text-white py-1 mx-1 md:inline-block">
                About
              </NavLink>
            </li>
            <li className="md:mr-4 navhidden">
              <NavLink to="/launchPadToday" className="block text-white py-1 mx-1 md:inline-block">
              LaunchPad Today
              </NavLink>
            </li>
            <li className="md:mr-4">
              <NavLink to="/startupIdeas" className="block text-white py-1 mx-1 md:inline-block">
              Startup Ideas
              </NavLink>
            </li>
            <li className="md:mr-4">
              <NavLink to="/contact" className="block text-white py-1 mx-1 md:inline-block">
              Contact Us
              </NavLink>
            </li>
            <li className="md:mr-4">
              <NavLink to="/freeResources" className="block ms-1 text-white rounded bg-sky-600 py-1 px-4 md:inline-block">
              Free Resources
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
   </>
  );
}

export default Navbar;
