import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLightbulb,faChartLine,faBuilding,faRocket} from '@fortawesome/free-solid-svg-icons';

function FreeResource() {

  return (
    <section className="bg-gray-900 flex items-center justify-center px-5 py-10 lg:py-20">
      <div className="text-center text-white h-auto w-full md:w-2/3 lg:w-10/12 flex flex-col justify-center header_box">
        <h2 className="text-3xl md:text-5xl lg:text-5xl font-bold" style={{ color: "var(--green-color)"}} >
        Access Premium <span style={{ color: "var(--heading-color)"}} className="line-through"> Paid </span> Resources for Free: Tools, Guides, and Insights
        </h2>
        <p className="text-lg md:text-xl mt-4 mb-8 text-gray-500">
        Explore essential tools, expert guidance, and free resources to help start, grow, and succeed with your business ideas.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:pt-8">
            <div className="p-4 border-2 border-spanText rounded-xl shadow lg:scale-105 transform transition duration-300">
                <FontAwesomeIcon icon={faLightbulb} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Start Strong with Your Idea</h2>
                <p className="text-gray-400">Begin your entrepreneurial journey with a solid foundation. Learn how to identify problems, design innovative solutions, and analyze market gaps effectively with our free, structured resources.</p>
            </div>
            <div className="p-4 border rounded-xl shadow hover:scale-105 transform transition duration-300">
            <FontAwesomeIcon icon={faChartLine} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Plan and Research Like a Pro</h2>
                <p className="text-gray-400">Access detailed guides on industry trends, competitor analysis, customer persona creation, and revenue model development to turn your business idea into a well-researched, actionable plan.</p>
            </div>
            <div className="p-4 border rounded-xl shadow hover:scale-105 transform transition duration-300">
            <FontAwesomeIcon icon={faBuilding} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Build Your Startup Foundation</h2>
                <p className="text-gray-400">Set up your business legally and structurally with tips on company registration, tax compliance, and professional branding. Discover tools for team building, mentorship, and workspace setup.</p>
            </div>
            <div className="p-4 border-2 border-headingColor rounded-xl shadow lg:scale-105 transform transition duration-300">
            <FontAwesomeIcon icon={faRocket} className="text-blue-500 text-4xl" />
                <h2 className="text-2xl mb-4 font-semibold">Develop, Launch, and Grow</h2>
                <p className="text-gray-400">From product development and testing to marketing strategies and funding opportunities, explore every step required to successfully launch, sustain, and scale your startup.</p>
            </div>
        </div>
      </div>
    </section>
  );
}

export default FreeResource;
