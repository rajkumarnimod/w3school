import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckDouble} from '@fortawesome/free-solid-svg-icons';

function Check() {
  return (
    <FontAwesomeIcon icon={faCheckDouble} className="text-blue-500" />
  )
}

export default Check