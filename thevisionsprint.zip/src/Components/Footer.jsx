import React from "react";
import Logo from "../assets/logo.svg";

function Footer() {
  return (
    <footer className="p-4 md:p-8 lg:p-10 dark:bg-gray-800 border-t border-slate-700 text-center">
      <div className="mx-auto max-w-screen-xl">
        <a
          href="#"
          className="flex justify-center items-center text-2xl font-semibold text-gray-500 dark:text-white"
        >
          <img src={Logo} alt="TheVisionSprint Logo" className="mx-3" />
          TheVisionSprint
        </a>
        <p className="my-6 text-gray-500 dark:text-gray-400">
          Open-source library of over 400+ web components and interactive
          elements built for better web.
        </p>
        <ul className="flex flex-wrap justify-center items-center mb-6 text-gray-500 dark:text-white">
          {["About", "Premium", "Campaigns", "Blog", "Affiliate Program", "FAQs", "Contact"].map(
            (item, index) => (
              <li key={index}>
                <a href="#" className="mr-4 hover:underline md:mr-6">
                  {item}
                </a>
              </li>
            )
          )}
        </ul>
        <span className="text-sm text-gray-500 sm:text-center dark:text-gray-400">
          © 2021-{new Date().getFullYear()}{" "}
          <a href="#" className="hover:underline">
            TheVisionSprint ™
          </a>{" "}
          || All Rights Reserved.
        </span>
      </div>
    </footer>
  );
}

export default Footer;