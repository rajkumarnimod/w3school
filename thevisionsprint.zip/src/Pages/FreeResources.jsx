import React from 'react'

function FreeResources() {
  return (
    <div>FreeResources</div>
  )
}

export default FreeResources