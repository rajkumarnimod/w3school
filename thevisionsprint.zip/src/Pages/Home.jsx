import React from 'react'
import Header from '../Components/Header'
import About from '../Components/About'
import Launched from '../Components/Launched'
import FreeResource from '../Components/FreeResource'
import Subscribe from '../Components/Subscribe'

function Home() {
  return (
    <>
    <Header />
    <About />
    <Launched/>
    <FreeResource/>
    <Subscribe/>
    </>
  )
}

export default Home