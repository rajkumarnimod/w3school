import React from 'react'

function LaunchPadToday() {
  return (
    <div>LaunchPadToday</div>
  )
}

export default LaunchPadToday