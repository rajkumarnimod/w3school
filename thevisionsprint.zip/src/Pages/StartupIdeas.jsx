import React from 'react'

function StartupIdeas() {
  return (
    <div>StartupIdeas</div>
  )
}

export default StartupIdeas