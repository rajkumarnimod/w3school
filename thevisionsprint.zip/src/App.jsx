import React from 'react'
import { Routes,Route } from 'react-router-dom'
import Home from './pages/Home'
import About from './pages/About'
import Contact from './pages/Contact'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import FreeResources from './Pages/FreeResources'
import StartupIdeas from './Pages/StartupIdeas'
import LaunchPadToday from './Pages/LaunchPadToday'

function App() {
  return (
    <>
    <Navbar />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path='/about' element={<About />} />
      <Route path='/launchPadToday' element={<LaunchPadToday/>} />
      <Route path='/freeResources' element={<FreeResources />} />
      <Route path='/startupIdeas' element={<StartupIdeas/>} />
      <Route path='/contact' element={<Contact />} />
    </Routes>
    <Footer/>
    </>
  )
}

export default App