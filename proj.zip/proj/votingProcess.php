<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn how to participate in the voting process at PrajaLeaders.org. Follow these simple steps to vote for your MLA and share your support or dissatisfaction with their performance.">
    <meta name="keywords" content="Voting Process, Vote for MLA, Rajasthan Politics, District Selection, Tehsil, Select MLA, Political Leaders, Support MLA, Public Opinion, Political Engagement">
    <meta name="author" content="PrajaLeaders.org">
    <meta property="og:title" content="Voting Process - PrajaLeaders.org" />
    <meta property="og:description" content="Participate in the voting process at PrajaLeaders.org by selecting your district, tehsil, and MLA. Share your support or dissatisfaction with political leaders in Rajasthan." />
    <meta property="og:url" content="https://www.prajaleaders.org/votingprocess" />
    <meta property="og:type" content="website" />
    <link rel="canonical" href="https://www.prajaleaders.org/votingprocess" />
    <title>Voting Process - PrajaLeaders</title>
    <?php include 'style.php'; ?>
</head>

<body>
    <?php include 'navbar.php'; ?>
    
    <section>
        <div class="page-hero-bg">
            <h1 class="page-hero-title"> Voting Process</h1>
        </div>
        <div class="container">
            <h1 class="para-heading">How to Participate</h1>
            <p class="para-title">
                At prajaleaders.org, we have developed a simple and secure voting
                process that allows you to express your opinion on your elected
                representatives. By following a few straightforward steps, you can
                vote for your MLA and show your support or dissatisfaction. Here’s how
                it works:
            </p>
            <h1 class="para-heading">1. Select Your District</h1>
            <p class="para-title">
                The first step in the voting process is to select your district. We have
                categorized the entire state, making it easy for you to find your
                district from the list. Simply choose the district you belong to, and
                you’ll be guided to the next step.
            </p>

            <h1 class="para-heading">2. Choose Your Tehsil</h1>
            <p class="para-title">
                After selecting your district, you will be asked to select the Tehsil
                (sub-district) where you reside. This step helps us filter the voting
                process down to your local area, ensuring that you are voting for the
                correct representative.
            </p>

            <h1 class="para-heading">3. Select Your MLA</h1>
            <p class="para-title">
                Once your Tehsil is selected, you will be able to view the list of MLAs
                (Members of Legislative Assembly) representing that area. At this stage,
                you can choose the MLA you wish to vote for based on their work and
                contributions in your region.
            </p>

            <h1 class="para-heading">4. Like</h1>
            <p class="para-title">
                After selecting your MLA, you will have the option to like their work. A 'like' shows that you are satisfied with their performance. Your vote reflects your views on how well they have served the people.
            </p>

            <p class="para-title">
                This simple, step-by-step process makes it easy for you to participate and help shape
                the future by highlighting leaders who truly work for the people.
            </p>
        </div>
    </section>

    <?php include 'footer.php'; ?>
    <?php include 'scriptcdn.php'; ?>
</body>

</html>