const contentArray = [
    "Apna Manpasand Neta",
    "Make Your Voice Heard",
    "Shape the Future: Vote Now",
    "Your Vote Matters",
    "Be a Part of Change",
    "Join the Movement: Vote Today",
    "Stand with Your Leader: Vote Now",
    "Show Your Support",
    "Like Your Leader’s Work? Vote Now!",
    "Back Your MLA: Vote Today",
    "Vote for Better Governance",
    "Help Us Recognize the Best: Vote Now",
    "Let’s Make a Difference Together: Vote"
];
let index = 0;
let charIndex = 0;
let currentContent = '';

function typeWriterEffect() {
    if (charIndex < currentContent.length) {
        document.getElementById("autotext").textContent += currentContent.charAt(charIndex);
        charIndex++;
        setTimeout(typeWriterEffect, 100);
    }
}

function setRandomContent() {
    const randomIndex = Math.floor(Math.random() * contentArray.length);
    currentContent = contentArray[randomIndex];
    document.getElementById("autotext").textContent = '';
    charIndex = 0;

    typeWriterEffect();
}

setRandomContent();
setInterval(setRandomContent, 10000);