<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Basic Meta Tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="title" content="Praja Leaders - Leadership That Matters, Insights That Count">
  <meta name="description" content="Janta Ke Dil Ka Sikandar: Kaun Hai Jo Chhaye Sab Par? Discover the leaders who capture hearts through their work and passion. Share your thoughts and opinions on the leaders who have touched your life the most.">
  <meta name="keywords" content="Praja Leaders, Leadership, Janta Ke Dil Ka Sikandar,rajasthan Top Leaders,Rajasthan Political Insights, Vote for Leaders,Rajasthan Popular Leaders, Leader Insights, Community Leaders, Heart-Winning Leaders, Leadership That Matters, Public Opinion, Vote Insights, Popular Politics, Influential Leaders">
  <meta name="author" content="Praja Leaders Team">

  <!-- Open Graph / Facebook -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.prajaleaders.org">
  <meta property="og:title" content="Praja Leaders - Leadership That Matters, Insights That Count">
  <meta property="og:description" content="Discover the leaders who have won the hearts of people through their work. Share your opinions on who truly stands out as Janta Ke Dil Ka Sikandar.">
  <meta property="og:image" content="https://www.prajaleaders.com/assets/hero.webp">

  <!-- Twitter -->
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:url" content="https://www.prajaleaders.org">
  <meta property="twitter:title" content="Praja Leaders - Leadership That Matters, Insights That Count">
  <meta property="twitter:description" content="Vote for the leader who has truly made a difference. Share your thoughts on the leader who resonates the most with you.">

  <meta property="og:site_name" content="Praja Leaders">
  <meta property="og:locale" content="en_IN">
  <meta property="og:updated_time" content="2024-10-03T10:00:00+05:30">
  <meta property="og:type" content="article">
  <meta property="article:section" content="Political Leadership">
  <meta property="article:tag" content="Leadership, Political Leaders, Public Vote, Popularity Contest">
  <meta property="article:author" content="Praja Leaders Team">
  <link rel="shortcut icon" href="assets/favicon.png" type="image/x-icon">
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "Praja Leaders - Leadership That Matters, Insights That Count",
      "url": "https://www.prajaleaders.org",
      "description": "Janta Ke Dil Ka Sikandar: Kaun Hai Jo Chhaye Sab Par? Discover the leaders who capture hearts through their work and passion. Share your opinions on the leaders who have touched your life the most.",
      "inLanguage": "hi",
      "mainEntity": {
        "@type": "Article",
        "headline": "Janta Ke Dil Ka Sikandar",
        "alternativeHeadline": "Kaun Hai Jo Chhaye Sab Par?",
        "description": "Explore and share insights about the leaders who have won the hearts of people through their work. Participate in this engaging journey to select the top political leaders based on public opinions.",
        "image": {
          "@type": "ImageObject",
          "url": "https://www.prajaleaders.org/assets/hero.webp",
          "height": "600",
          "width": "1200"
        },
        "author": {
          "@type": "Organization",
          "name": "Praja Leaders Team",
          "url": "https://www.prajaleaders.org",
          "logo": {
            "@type": "ImageObject",
            "url": "https://www.prajaleaders.org/assets/logo.png",
            "height": "60",
            "width": "200"
          }
        },
        "publisher": {
          "@type": "Organization",
          "name": "Praja Leaders Team",
          "logo": {
            "@type": "ImageObject",
            "url": "https://www.prajaleaders.org/assets/img/logo.png",
            "height": "60",
            "width": "200"
          }
        },
        "datePublished": "2024-10-03",
        "dateModified": "2024-10-03",
        "articleSection": "Leadership Insights, Voting Trends, Public Opinion",
        "keywords": [
          "Praja Leaders",
          "Leadership",
          "Janta Ke Dil Ka Sikandar",
          "Political Leaders",
          "Top Leaders",
          "Vote Insights",
          "Public Opinion",
          "Leadership that Matters"
        ]
      },
      "breadcrumb": {
        "@type": "BreadcrumbList",
        "itemListElement": [{
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://www.prajaleaders.org"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "About",
            "item": "https://www.prajaleaders.org/about"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Voting Process",
            "item": "https://www.prajaleaders.org/votingprocess"
          },
          {
            "@type": "ListItem",
            "position": 4,
            "name": "Star Leader",
            "item": "https://www.prajaleaders.org/starleader"
          },
          {
            "@type": "ListItem",
            "position": 5,
            "name": "Contact",
            "item": "https://www.prajaleaders.org/contact"
          }
        ]
      },
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.prajaleaders.org/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      },
      "about": {
        "@type": "Thing",
        "name": "Political Leaders",
        "sameAs": [
          "https://en.wikipedia.org/wiki/Politics",
          "https://en.wikipedia.org/wiki/List_of_leaders"
        ]
      },
      "interactionStatistic": {
        "@type": "InteractionCounter",
        "interactionType": {
          "@type": "LikeAction",
          "name": "Like"
        },
        "userInteractionCount": "1500"
      },
      "audience": {
        "@type": "Audience",
        "audienceType": "General Public",
        "geographicArea": {
          "@type": "Place",
          "name": "India"
        }
      }
    }
  </script>

  <?php include 'style.php'; ?>
  <title>Praja Leaders -leadership that matters, insights that count</title>
  <style>
    body {
      background: linear-gradient(45deg, #09f1b75e, #14b8a549, #d9901253 50%, #347e8546 98%);
    }
  </style>
</head>

<body>
  <?php include 'navbar.php'; ?>
  <?php include 'header.php'; ?>
  <?php include 'timeline.php'; ?>
  <?php include 'subscribe.php'; ?>
  <?php include 'footer.php'; ?>


  <?php include 'scriptcdn.php'; ?>
</body>

</html>