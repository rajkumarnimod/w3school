<!DOCTYPE html>
<html lang="en">

<head>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="title" content="Praja Leaders - Leadership That Matters, Insights That Count">
        <meta name="description" content="Praja Leaders is your platform to engage with and evaluate Rajasthan's political leaders. Share your opinions, vote for your favorite leader, and be a part of the change.">
        <meta name="keywords" content="Praja Leaders, Rajasthan political leaders, public voting, leadership evaluation, political transparency, government accountability, yearly newsletter, top leaders, political feedback">
        <meta name="author" content="prajaleaders.org">
        <meta name="robots" content="index, follow">
        <meta property="og:title" content="Praja Leaders - Leadership That Matters, Insights That Count">
        <meta property="og:description" content="Explore Rajasthan's political leaders, share your opinions, and vote for the leaders who stand out in governance and accountability.">
        <meta property="og:image" content="https://www.prajaleaders.org/assets/hero.webp">
        <meta property="og:url" content="https://www.prajaleaders.org">
        <meta property="og:type" content="website">
        <title>About praja leaders - Engage with Rajasthan's Political Leaders</title>
        <?php include 'style.php'; ?>
    </head>

    <?php include 'style.php'; ?>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section>
        <div class="page-hero-bg">
            <h1 class="page-hero-title">About prajaleaders</h1>
        </div>
        <div class="container">
            <h1 class="para-heading">Welcome to PrajaLeaders.org</h1>
            <p class="para-title">
                Welcome to prajaleaders.org, your dedicated platform for engaging with
                and evaluating Rajasthan's political leaders. Our mission is to bridge
                the gap between the people and their elected representatives by
                providing a space where you can voice your opinions, share your
                experiences, and highlight the work of leaders who truly serve the
                public.
            </p>
            <h1 class="para-heading">Our Mission</h1>
            <p class="para-title">
                At Netainside.org, we are committed to promoting transparency and
                accountability in governance. Our mission is to spotlight those
                leaders who are genuinely working for the benefit of the community. By
                highlighting their efforts, we aim to encourage good practices and set
                a benchmark for effective leadership.
            </p>
            <h1 class="para-heading">How It Works</h1>
            <ol class="para-title">
                <li><u>Explore the Leaders:</u> - Browse through our extensive list of political leaders from Rajasthan. Each leader's profile includes their name, image, and a summary of their work.</li>
                <li><u>Share Your Story:</u> - Have you had a significant interaction with a leader or witnessed their work firsthand? Share your story with us! Your experiences help paint a complete picture of each leader’s impact on the community.</li>
            </ol>
        </div>
        <div class="container" style="margin-top: -50px;">
            <h1 class="para-heading">Yearly Newsletter</h1>
            <p class="para-title">
                Our yearly newsletter celebrates the top 10 leaders who have made a remarkable impact through their work. This newsletter, compiled from user feedback and stories, serves as a platform to recognize and honor those who excel in serving their constituents. We ensure that only the most dedicated and effective leaders are highlighted, providing inspiration and setting high standards for public service.
            </p>
            <h1 class="para-heading">Privacy and Confidentiality</h1>
            <p class="para-title">
                We value your privacy. All feedback and stories shared on Netainside.org are confidential and used solely for the purpose of our yearly newsletter. Your input helps us recognize leaders who are making a difference, but rest assured, your personal information and stories remain private.
            </p>
            <h1 class="para-heading">Why It Matters</h1>
            <p class="para-title">
                Your engagement with Netainside.org helps foster a more accountable and responsive political environment. By sharing your experiences and feedback, you contribute to a platform that values transparency and effective governance. Together, we can ensure that leaders who are genuinely dedicated to serving the public are acknowledged and celebrated.
            </p>
            <h1 class="para-heading">Join Us</h1>
            <p class="para-title">
                Be a part of this important process. Visit Netainside.org today to learn more about your leaders, share your stories, and contribute to our yearly newsletter. Your voice is important, and together, we can highlight the leaders who are making a real difference in our community.
            </p>
            <h1 class="para-heading"><i>Thank you for your support and participation.</i></h1>
        </div>


    </section>

    <?php include 'footer.php'; ?>
    <?php include 'scriptcdn.php'; ?>
</body>

</html>