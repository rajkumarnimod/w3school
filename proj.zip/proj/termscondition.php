<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Read the Terms and Conditions for using PrajaLeaders.org, including acceptance of terms, user contributions, intellectual property, disclaimers, and governing law.">
    <meta name="keywords" content="Terms and Conditions, PrajaLeaders.org, User Agreement, Website Use, Legal Terms, Intellectual Property, Liability Limitation, Governing Law">
    <meta name="author" content="PrajaLeaders.org">
    <meta property="og:title" content="Terms and Conditions - PrajaLeaders.org" />
    <meta property="og:description" content="Learn about the Terms and Conditions governing your use of PrajaLeaders.org, including user contributions, intellectual property rights, and liability limitations." />
    <meta property="og:type" content="website" />
    <title>Terms and Conditions - PrajaLeaders</title>
    <?php include 'style.php'; ?>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section>
        <div class="page-hero-bg">
            <h1 class="page-hero-title">Terms and Conditions</h1>
        </div>
        <div class="container">
            <h1>Terms and Conditions for PrajaLeaders.org</h1>
            <p class="para-title">Effective Date: [Insert Date]</p>

            <p class="para-title">Welcome to PrajaLeaders.org. These terms and conditions outline the rules and regulations for the use of our website.</p>

            <h2 class="para-heading">1. Acceptance of Terms</h2>
            <p class="para-title">By accessing and using PrajaLeaders.org, you accept and agree to be bound by these terms and conditions. If you do not agree with any part of these terms, you must not use our website.</p>

            <h2 class="para-heading">2. Changes to Terms</h2>
            <p class="para-title">We reserve the right to modify these terms and conditions at any time. Changes will be effective immediately upon posting on this page. It is your responsibility to review these terms periodically.</p>

            <h2 class="para-heading">3. Use of the Site</h2>
            <p class="para-title">You agree to use PrajaLeaders.org only for lawful purposes and in a manner that does not infringe upon the rights of others. You must not use our site in any way that could damage, disable, or impair the website or interfere with any other party's use of it.</p>

            <h2 class="para-heading">4. User Contributions</h2>
            <p class="para-title">You are responsible for any content you submit to PrajaLeaders.org, including feedback, stories, and voting information. By submitting content, you grant us a non-exclusive, royalty-free, worldwide, perpetual, and irrevocable license to use, reproduce, modify, and publish that content.</p>

            <h2 class="para-heading">5. Intellectual Property</h2>
            <p class="para-title">All content on PrajaLeaders.org, including text, graphics, logos, and images, is the property of PrajaLeaders.org or its content suppliers and is protected by applicable copyright and intellectual property laws. You may not reproduce, distribute, or create derivative works without our express written permission.</p>

            <h2 class="para-heading">6. Disclaimers</h2>
            <p class="para-title">PrajaLeaders.org is provided on an "as-is" basis. We make no representations or warranties of any kind, express or implied, regarding the operation of our website or the information, content, materials, or products included on it. Your use of this site is at your own risk.</p>

            <h2 class="para-heading">7. Limitation of Liability</h2>
            <p class="para-title">To the fullest extent permitted by law, PrajaLeaders.org will not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising from your use of our site or any content, products, or services obtained through our site.</p>

            <h2 class="para-heading">8. Governing Law</h2>
            <p class="para-title">These terms and conditions shall be governed by and construed in accordance with the laws of [Your Jurisdiction]. Any disputes arising under or in connection with these terms shall be subject to the exclusive jurisdiction of the courts of [Your Jurisdiction].</p>

            <h2 class="para-heading">9. Contact Us</h2>
            <p class="para-title">If you have any questions or concerns about these Terms and Conditions, please contact us at:</p>
            <ul>
                <li><strong>Email:</strong> [Insert Email Address]</li>
                <li><strong>Website:</strong> [Insert Website URL]</li>
            </ul>
        </div>
    </section>

    <?php include 'footer.php'; ?>
    <?php include 'scriptcdn.php'; ?>
</body>

</html>