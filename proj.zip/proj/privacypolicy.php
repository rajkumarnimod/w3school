<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about the Privacy Policy of PrajaLeaders.org, detailing how we collect, use, and protect your personal information when engaging with our platform.">
    <meta name="keywords" content="Privacy Policy, PrajaLeaders.org, Personal Information, Data Security, User Rights, Cookies, Children's Privacy, Third-Party Links">
    <meta name="author" content="PrajaLeaders.org">
    <meta property="og:title" content="Privacy Policy - PrajaLeaders.org" />
    <meta property="og:description" content="Read about the Privacy Policy for PrajaLeaders.org, including information collection, usage, data security, and user rights." />
    <meta property="og:type" content="website" />
    <title>Privacy Policy - PrajaLeaders.org</title>
    <?php include 'style.php'; ?>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section>
        <div class="page-hero-bg">
            <h1 class="page-hero-title">privacy policy</h1>
        </div>
        <div class="container">
            <h1>Privacy Policy for PrajaLeaders.org</h1>
            <p class="para-title">Effective Date: [Insert Date]</p>

            <p class="para-title">Welcome to PrajaLeaders.org. Your privacy is of utmost importance to us. This Privacy Policy outlines how we collect, use, and protect your information when you engage with our platform.</p>

            <h2 class="para-heading">1. Information We Collect</h2>
            <ul>
                <li><strong>Personal Information:</strong> Name, email address, and any other information you choose to share while submitting feedback or stories.</li>
                <li><strong>Voting Information:</strong> Data related to your voting preferences, including your selected district, Tehsil, and MLA.</li>
            </ul>

            <h2 class="para-heading">2. How We Use Your Information</h2>
            <ul>
                <li><strong>To Facilitate Voting:</strong> To allow you to participate in our voting process and express your opinions about your elected representatives.</li>
                <li><strong>To Analyze Feedback:</strong> To evaluate user feedback and stories to identify top-performing leaders.</li>
                <li><strong>To Communicate with You:</strong> To send newsletters and updates related to our platform and the leaders recognized through user feedback.</li>
            </ul>

            <h2 class="para-heading">3. Data Confidentiality</h2>
            <p class="para-title">We value your privacy. All feedback and stories submitted to PrajaLeaders.org will be treated as confidential. We will not disclose your personal information or any details about your stories without your consent, except as required by law.</p>

            <h2 class="para-heading">4. Data Security</h2>
            <p class="para-title">We implement reasonable security measures to protect your information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its absolute security.</p>

            <h2 class="para-heading">5. User Rights</h2>
            <ul>
                <li>Access and Update Your Information:- You can request access to the personal information we hold about you and request corrections if needed.</li>
                <li>Withdraw Consent:- You may withdraw your consent for us to use your personal information at any time, although this may affect your ability to participate in certain features of our platform.</li>
            </ul>

            <h2 class="para-heading">6. Cookies</h2>
            <p class="para-title">PrajaLeaders.org may use cookies and similar tracking technologies to enhance user experience. You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can modify your browser settings to decline cookies if you prefer.</p>

            <h2 class="para-heading">7. Third-Party Links</h2>
            <p class="para-title">Our website may contain links to third-party websites. We do not control and are not responsible for the content or practices of these sites. We encourage you to review the privacy policies of any third-party sites you visit.</p>

            <h2 class="para-heading">8. Children's Privacy</h2>
            <p class="para-title">PrajaLeaders.org is not intended for children under the age of 13. We do not knowingly collect personal information from children under this age. If we become aware that we have collected personal data from a child under 13, we will take steps to delete such information from our records.</p>

            <h2 class="para-heading">9. Changes to This Privacy Policy</h2>
            <p class="para-title">We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on our website. You are advised to review this Privacy Policy periodically for any changes.</p>

            <h2 class="para-heading">10. Contact Us</h2>
            <p class="para-title">If you have any questions or concerns about this Privacy Policy or our practices regarding your personal information, please contact us at:</p>
            <ul>
                <li>Email: [Insert Email Address]</li>
                <li>Website: [Insert Website URL]</li>
            </ul>

        </div>
    </section>

    <?php include 'footer.php'; ?>
    <?php include 'scriptcdn.php'; ?>
</body>

</html>