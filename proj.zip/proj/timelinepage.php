<!DOCTYPE html>
<html lang="en">

<head>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="title" content="Praja Leaders - Leadership That Matters, Insights That Count">
        <meta name="description" content="Praja Leaders is your platform to engage with and evaluate Rajasthan's political leaders. Share your opinions, vote for your favorite leader, and be a part of the change.">
        <meta name="keywords" content="Praja Leaders, Rajasthan political leaders, public voting, leadership evaluation, political transparency, government accountability, yearly newsletter, top leaders, political feedback">
        <meta name="author" content="prajaleaders.org">
        <meta name="robots" content="index, follow">
        <meta property="og:title" content="Praja Leaders - Leadership That Matters, Insights That Count">
        <meta property="og:description" content="Explore Rajasthan's political leaders, share your opinions, and vote for the leaders who stand out in governance and accountability.">
        <meta property="og:image" content="https://www.prajaleaders.org/assets/hero.webp">
        <meta property="og:url" content="https://www.prajaleaders.org">
        <meta property="og:type" content="website">
        <title>About praja leaders - Engage with Rajasthan's Political Leaders</title>
        <?php include 'style.php'; ?>
    </head>

    <?php include 'style.php'; ?>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section class="py-5">
  <div class="timeline">
    <h2 class="title">
      Party in <span class="theme_color"> Power </span> Through the Years
      <img src="assets/political.webp" alt="Political party" class="icon" />
    </h2>
    <h1 class="subtitle">Power Timeline: Party by Year</h1>
    <div class="underline"></div>
  </div>

  <div class="timeline-row">
    <div class="timeline-col">
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1949</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Heera Lal Shastri</h3>
          <p class="timeline-period">7 April 1949 to 5 January 1951</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1951</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">C. S. Venkatachari</h3>
          <p class="timeline-period">6 January 1951 to 25 April 1951</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1951</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Jai Narayan Vyas</h3>
          <p class="timeline-period">26 April 1951 to 3 March 1952</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1952</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Tika Ram Paliwal</h3>
          <p class="timeline-period">March 1952 to 31 October 1952</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1952</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Jai Narayan Vyas</h3>
          <p class="timeline-period">1 November 1952 to 12 November 1954</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1952</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Mohan Lal Sukhadia</h3>
          <p class="timeline-period">1 November 1952 to 9 July 1971</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1971</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Barkatullah Khan</h3>
          <p class="timeline-period">9 July 1971 to 11 October 1973</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1973</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Hari Dev Joshi</h3>
          <p class="timeline-period">11 October 1973 to 29 April 1977</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
    </div>

    <div class="timeline-col">
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1977</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Bhairon Singh Shekhawat</h3>
          <p class="timeline-period">22 June 1977 to 16 February 1980</p>
          <button type="button" class="timeline-button">
            Janata Party
          </button>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1980</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Jagan Nath Pahadia</h3>
          <p class="timeline-period">6 June 1980 to 14 July 1981</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1981</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Shiv Charan Mathur</h3>
          <p class="timeline-period">14 July 1981 to 23 February 1985</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1985</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Hari Dev Joshi</h3>
          <p class="timeline-period">10 March 1985 to 20 January 1988</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1988</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Shiv Charan Mathur</h3>
          <p class="timeline-period">20 January 1988 to 4 December 1989</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1990</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Bhairon Singh Shekhawat</h3>
          <p class="timeline-period">4 March 1990 to 15 December 1992</p>
          <a type="button" class="timeline-button" href="https://www.bjp.org/" target="_blank">
            <img src="assets/bjplogo.webp" alt="BJP" class="timeline-logo" />
            BJP
          </a>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1992</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Professor Tika Ram</h3>
          <p class="timeline-period">15 December 1992 to 4 December 1993</p>
          <button type="button" class="timeline-button">
            President's Rule
          </button>
        </div>
      </div>

      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1993</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Bhairon Singh Shekhawat</h3>
          <p class="timeline-period">4 December 1993 to 29 November 1998</p>
          <a type="button" class="timeline-button" href="https://www.bjp.org/" target="_blank">
            <img src="assets/bjplogo.webp" alt="BJP" class="timeline-logo" />
            BJP
          </a>
        </div>
      </div>

    </div>

    <div class="timeline-col">
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">1998</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Ashok Gehlot</h3>
          <p class="timeline-period">1 December 1998 to 8 December 2003</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">2003</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Vasundhara Raje</h3>
          <p class="timeline-period">8 December 2003 to 13 December 2008</p>
          <a type="button" class="timeline-button" href="https://www.bjp.org/" target="_blank">
            <img src="assets/bjplogo.webp" alt="BJP" class="timeline-logo" />
            BJP
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">2008</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Ashok Gehlot</h3>
          <p class="timeline-period">13 December 2008 to 13 December 2013</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">2013</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Vasundhara Raje</h3>
          <p class="timeline-period">13 December 2013 to 17 December 2018</p>
          <a type="button" class="timeline-button" href="https://www.bjp.org/" target="_blank">
            <img src="assets/bjplogo.webp" alt="BJP" class="timeline-logo" />
            BJP
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">2018</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Ashok Gehlot</h3>
          <p class="timeline-period">17 December 2018 to 15 December 2023</p>
          <a type="button" class="timeline-button" href="https://inc.in/" target="_blank">
            <img src="assets/congresslogo.webp" alt="Congress" class="timeline-logo" />
            Congress
          </a>
        </div>
      </div>
      <div class="timeline-item">
        <div class="timeline-year">
          <span class="timeline-year-text">2023</span>
        </div>
        <div class="timeline-line">
          <div class="timeline-marker">
            <div class="timeline-dot"></div>
          </div>
        </div>
        <div class="timeline-content">
          <h3 class="timeline-title">Bhajanlal Sharma</h3>
          <p class="timeline-period">15 December 2023 to present...</p>
          <a type="button" class="timeline-button" href="https://www.bjp.org/" target="_blank">
            <img src="assets/bjplogo.webp" alt="BJP" class="timeline-logo" />
            BJP
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

    <?php include 'footer.php'; ?>
    <?php include 'scriptcdn.php'; ?>
</body>

</html>