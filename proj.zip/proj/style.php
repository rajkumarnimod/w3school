<!-- Additional Meta Tags -->
<meta name="robots" content="index, follow">
<meta name="language" content="Hindi, English">
<meta name="theme-color" content="#0056b3">
<meta name="rating" content="General">
<meta name="distribution" content="Global">
<meta name="subject" content="Political Leaders Insights and Voting">
<meta name="category" content="Politics, Leadership, Community Insights">
<meta name="target" content="Citizens, Political Enthusiasts, Voters">
<meta name="format-detection" content="telephone=no">
<meta name="copyright" content="© 2024 Praja Leaders">
<meta name="reply-to" content="support@prajaleaders.com">
<meta name="revisit-after" content="7 days">
<meta name="coverage" content="Worldwide">
<meta name="audience" content="All">
<link rel="shortcut icon" href="assets/favicon.png" type="image/x-icon">

<link rel="stylesheet" href="css/navbar.css">
<link rel="stylesheet" href="css/commanstyle.css">
<link rel="stylesheet" href="css/timeline.css">
<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/pagesstyle.css">
<link rel="stylesheet" href="css/subscribe.css ">
<link rel="stylesheet" href="css/footer.css ">


<!-- bootstrap css cdn  -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- font-awesome css cdn  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />