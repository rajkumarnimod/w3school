<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Constituency Selector</title>
    <style>
       #leaderscard_sec{
        padding: 3rem 1rem;
       }
        .container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .dropdowns {
            background-color: #3D9FFF;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
            padding: 10px;
            border-radius: 20px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown select {
            width: 250px;
            padding: 10px 20px; 
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .search-bar {
            width: 250px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .card {
            width: calc(20% - 10px);
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: #f9f9f9;
            text-align: center;
        }

    </style>
     <?php include 'style.php'; ?>
</head>
<body>
<?php include 'navbar.php'; ?>
<section id="leaderscard_sec">
    <div>
        <h1 class="title text-center"> Empower Leaders, Your
        <span class="theme_color"> Voice </span>
        Matters</h1>
    </div>
<div class="container">
    <!-- First Div: Dropdowns and Search Bar -->
    <div class="dropdowns">
        <div class="dropdown">
            <select id="district-dropdown">
                <option value="">Select District</option>
                <option value="district1">District 1</option>
                <option value="district2">District 2</option>
                <option value="district3">District 3</option>
                <!-- Add more districts as needed -->
            </select>
        </div>
        <div class="dropdown">
            <select id="constituency-dropdown">
                <option value="">Select Constituency</option>
                <!-- Constituencies will be populated based on district selection -->
            </select>
        </div>
        <input type="text" class="search-bar" placeholder="Search..." />
    </div>

    <!-- Second Div: Card Section -->
    <div class="d-flex justify-content-center row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3 gap-3" id="card-section">
        <!-- Default cards will be displayed here -->
    </div>
</div>
</section>
<?php include 'footer.php'; ?>
<script>
    const constituencies = {
        district1: ['Constituency 1.1', 'Constituency 1.2', 'Constituency 1.3'],
        district2: ['Constituency 2.1', 'Constituency 2.2', 'Constituency 2.3'],
        district3: ['Constituency 3.1', 'Constituency 3.2', 'Constituency 3.3']
    };

    // Function to display constituency cards
    function displayConstituencyCards(constituency) {
        const cardSection = document.getElementById('card-section');
        cardSection.innerHTML = ''; // Clear previous cards
        for (let i = 1; i <= 10; i++) {
            const card = document.createElement('div');
            card.className = 'card';
            card.textContent = `${constituency} Card ${i}`;
            cardSection.appendChild(card);
        }
    }

    // Function to populate the constituency dropdown
    function populateConstituencyDropdown(district) {
        const constituencyDropdown = document.getElementById('constituency-dropdown');
        constituencyDropdown.innerHTML = '<option value="">Select Constituency</option>';

        if (district) {
            constituencies[district].forEach(constituency => {
                const option = document.createElement('option');
                option.value = constituency;
                option.textContent = constituency;
                constituencyDropdown.appendChild(option);
            });
            constituencyDropdown.disabled = false;
        } else {
            constituencyDropdown.disabled = true;
        }
    }

    // On page load, show default district and constituency
    window.onload = function() {
        // Set default district
        const defaultDistrict = 'district1';
        document.getElementById('district-dropdown').value = defaultDistrict;
        
        // Populate default constituency dropdown and show default constituency cards
        populateConstituencyDropdown(defaultDistrict);
        displayConstituencyCards(constituencies[defaultDistrict][0]); // Display first constituency's cards
    };

    // Event listener for district dropdown change
    document.getElementById('district-dropdown').addEventListener('change', function() {
        const selectedDistrict = this.value;
        populateConstituencyDropdown(selectedDistrict);
    });

    // Event listener for constituency dropdown change
    document.getElementById('constituency-dropdown').addEventListener('change', function() {
        const selectedConstituency = this.value;
        displayConstituencyCards(selectedConstituency);
    });
</script>



<?php include 'scriptcdn.php'; ?>
</body>
</html>
