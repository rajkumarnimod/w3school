<nav>
  <div class="wrapper">
    <div class="logo">
      <a href="index">
        <img src="assets/logo.png" alt="logo">
      </a>
    </div>
    <input type="radio" name="slider" id="menu-btn">
    <input type="radio" name="slider" id="close-btn">
    <ul class="nav-links">
      <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="votingProcess.php"> Voting process</a></li>
      <li><a href="starleader.php">Star leaders</a></li>
      <li><a href="#">Contact us</a></li>
    </ul>
    <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
  </div>
</nav>