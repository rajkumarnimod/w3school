<section class="subscribe_sec">
    <div class="subscribe">
        <h2 class="title" style="text-align: center;">  Star <span class="theme_color">leaders</span> spotlight newsletter</h2>
        <p class="fs-5 subscribe__copy">Be the first to receive our annual newsletter featuring the top 10 most powerful leaders. Subscribe now to get exclusive updates delivered straight to your inbox. Stay ahead with the latest insights and highlights!</p>
        <div class="sub_form">
            <input type="email" name="emailid" class="form__email" placeholder="Enter your email address" />
            <button class="form__button">Send</button>
        </div>
    </div>
</section>