<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Explore the power of CSS transforms with this comprehensive guide. Learn about translate(), rotate(), scale(), skew(), and matrix() methods for dynamic web development.">
    <meta name="keywords" content="CSS, Transforms, Web Development, Animation, Scaling, Rotation, Skewing, Matrix">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">
    <meta name="og:title" property="og:title" content="The Power of CSS Transforms: A Comprehensive Guide">
    <meta name="og:description" property="og:description" content="Explore the power of CSS transforms with this comprehensive guide. Learn about translate(), rotate(), scale(), skew(), and matrix() methods for dynamic web development.">
    <meta name="twitter:title" content="The Power of CSS Transforms: A Comprehensive Guide">
    <meta name="twitter:description" content="Explore the power of CSS transforms with this comprehensive guide. Learn about translate(), rotate(), scale(), skew(), and matrix() methods for dynamic web development.">
    <title>Transforms view</title>

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">

    <style>
        section {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        #result-section {
            width: 80%;
            height: 300px;
            padding: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #transform-box {
            width: 80px;
            height: 80px;
            background-color: #3498db;
            transform-origin: center;
            transition: transform 0.5s ease-in-out;
        }

        #transform-buttons {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-block: 20px;
        }

        #transform-buttons>div button {
            width: 200px;
            padding: 5px;
            margin: 2px;
            background-color: rgb(241, 189, 137);
            border: none;
            font-size: 1rem;
            transition: background-color 0.3s ease, transform 0.5s ease;
            cursor: pointer;
        }

        @media only screen and (max-width: 600px) {
            #transform-buttons>div button {
                width: 100px;
            }
        }

        @media only screen and (max-width: 320px) {
            #transform-buttons>div button {
                width: 250px;
            }

            #transform-buttons div {
                display: flex;
                align-items: stretch;
                flex-direction: column;
            }
        }

        #transform-buttons>div button:hover {
            background-color: rgb(200, 150, 100);
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <section style="background-color: rgb(232, 209, 186);">
        <div id="result-section">
            <div id="transform-box"></div>
        </div>
        <div id="transform-buttons">
            <div>
                <button onclick="applyTransform('translate(30px, 60px)')">Translate</button>
                <button onclick="applyTransform('rotate(40deg)')">Rotate</button>
            </div>
            <div>
                <button onclick="applyTransform('scale(3, 2)')">Scale</button>
                <button onclick="applyTransform('scaleX(2)')">ScaleX</button>
            </div>
            <div>
                <button onclick="applyTransform('scaleY(2)')">ScaleY</button>
                <button onclick="applyTransform('skew(30deg, 10deg)')">Skew</button>
            </div>
            <div>
                <button onclick="applyTransform('skewX(10deg)')">SkewX</button>
                <button onclick="applyTransform('skewY(10deg)')">SkewY</button>
            </div>
            <div>
                <button onclick="resetTransform()">Reset</button>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

    <script>
        function applyTransform(transformValue) {
            document.getElementById('transform-box').style.transform = transformValue;
        }

        function resetTransform() {
            document.getElementById('transform-box').style.transform = 'none';
        }
    </script>
</body>

</html>