<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn how to use the CSS outline property to create outlines around elements. This guide covers how to set outlines using various styles and explores length and color values.">
    <meta name="keywords" content="CSS, Outline Property, Web Design, CSS Outlines, Outline Values, Length, Color, Outline Offset">
    <meta name="author" content="Rajkumar Nimod">

    <!-- Page Title -->
    <title>CSS Outline Property</title>

    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="Understanding the CSS Outline Property">
    <meta property="og:description" content="Learn how to use the CSS outline property to create outlines around elements. This guide covers how to set outlines using various styles and explores length and color values.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.example.com/css-outline-property">
    <meta property="og:image" content="https://www.example.com/images/css-outline-guide.png">

    <!-- Twitter Meta Tags for Social Sharing -->
    <meta name="twitter:title" content="Understanding the CSS Outline Property">
    <meta name="twitter:description" content="Learn how to use the CSS outline property to create outlines around elements. This guide covers how to set outlines using various styles and explores length and color values.">
    <meta name="twitter:url" content="https://www.example.com/css-outline-property">
    <meta name="twitter:image" content="https://www.example.com/images/css-outline-guide.png">

    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        section {
            width: 100%;
            display: grid;
            place-items: center;
        }

        #result-section {
            width: 100%;
            height: 200px;
            outline: 12px solid #20BEFF;
            margin-bottom: 20px;
        }

        #outline-buttons {
            width: 100%;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 5px;
            justify-items: center;
        }

        #outline-buttons button {
            width: 250px;
            padding: 10px;
            background-color: #9addf7;
            border: none;
            font-size: 1rem;
            cursor: pointer;
        }

        @media only screen and (max-width: 1024px) {
            #outline-buttons {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        @media only screen and (max-width: 991px) {
            #outline-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media only screen and (max-width: 600px) {
            #outline-buttons {
                grid-template-columns: 1fr;
            }

            #outline-buttons button {
                width: 100%;
            }
        }
    </style>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 2.5rem;">
        <div>
            <h2 class="text-center">Outline Property Preview Online</h2>
            <hr>
        </div>
        <section>
            <div id="result-section"></div>
            <div id="outline-buttons">
                <button onclick="applyOutline('dotted')">Dotted</button>
                <button onclick="applyOutline('dashed')">Dashed</button>
                <button onclick="applyOutline('solid')">Solid</button>
                <button onclick="applyOutline('double')">Double</button>
                <button onclick="applyOutline('groove')">Groove</button>
                <button onclick="applyOutline('ridge')">Ridge</button>
                <button onclick="applyOutline('inset')">Inset</button>
                <button onclick="applyOutline('outset')">Outset</button>
                <button onclick="applyOutline('none')">None</button>
                <button onclick="applyOutline('hidden')">Hidden</button>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

    <script>
        function applyOutline(outlineStyle) {
            document.getElementById('result-section').style.outlineStyle = outlineStyle;
        }
    </script>

</body>

</html>
