<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="author" content="Rajkumar nimod">
    <!-- Primary Meta Tags -->
    <title>50 Days Web Challenge - masterinwebdesign</title>
    <meta name="title" content="50 Days Web Challenge - masterinwebdesign" />
    <meta name="description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://masterinwebdesign.com/learningzone.html" />
    <meta property="og:title" content="50 Days Web Challenge - masterinwebdesign" />
    <meta property="og:description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />
    <meta property="og:image" content="https://masterinwebdesign.com/assets/project.webp" />

    <!-- Twitter -->
    <meta property="twitter:url" content="https://masterinwebdesign.com/learningzone.html" />
    <meta property="twitter:title" content="50 Days Web Challenge - masterinwebdesign" />
    <meta property="twitter:description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />
    <meta property="twitter:image" content="https://masterinwebdesign.com/assets/project.webp" />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        .challenge_sec{
    width: 100%;
}

.challenge_row{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(18rem, 0.5rem));
    gap: 1.5rem;
    align-items: flex-start;
    justify-content: center;
    margin: 1rem;
}

.card {
    display: flex;
    flex-wrap: wrap;
    align-items: stretch;
    margin-bottom: 2rem;
    width: 270px;
    display: flex;
    flex-direction: column;
    border-radius: 0.25rem;
    padding: 1rem;
  }
  
  .hea {
    display: flex;
    flex-direction: column;
  }
  
  .title {
    font-size: 1rem;
    line-height: 2rem;
    font-weight: 200;
    color: #fff
  }
  
  .price {
    font-size: 3rem;
    line-height: 1;
    font-weight: 700;
    color: #fff
  }
  
  .desc {
    margin-top: 0.75rem;
    margin-bottom: 0.75rem;
    line-height: 1.625;
    color: rgba(156, 163, 175, 1);
  }
  
  .lists {
    margin-bottom: 1.5rem;
    flex: 1 1 0%;
    color: rgba(156, 163, 175, 1);
    padding-left: 0;
  }
  
  .lists .list {
    margin-bottom: 0.5rem;
    display: flex;
  }
 
  .lists .list svg {
    height: 1.5rem;
    width: 1.5rem;
    flex-shrink: 0;
    margin-right: 0.5rem;
    color: rgba(167, 139, 250, 1);
  }
  
  .action {
    border: none;
    outline: none;
    display: inline-block;
    border-radius: 0.25rem;
    background-color: rgba(167, 139, 250, 1);
    padding-left: 1.25rem;
    padding-right: 1.25rem;
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
    text-align: center;
    font-weight: 600;
    letter-spacing: 0.05em;
    color: rgba(17, 24, 39, 1);
    text-decoration: none;
  }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main>
        <section class="py-2 mt-3 text-center container">
            <div class="row py-lg-5">
                <div class="col-lg-12 col-md-10 mx-auto">
                    <p style="font-size: 1rem;">Take Up a 50-Day Web Design Task!</p>
                    <h1 class="display-5 fw-bold">50 DAYS <span style="color: blue;">WEB</span> Learningzone</h1>
                    <p>
                        Ready to take on HTML, CSS, and JavaScript? <br /> This challenge takes you from basic talent to advanced talent. Start with HTML layout, go straight to CSS for styling, and finish with dynamic JavaScript.
                        Stay confident by sharing your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Rebuild your
                        coding ability by adding newbies to a website.
                        Challenges are opportunities—take a 50-day web design challenge, witness daily progress, and join
                        the realm of Internet development. Best wishes, and happy coding!
                    </p>
                </div>
            </div>
        </section>
        <section class="challenge_sec">
            <div class="challenge_row">

            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->
    <script type="application/ld+json">
        {
          "@context": "https://schema.org/",
          "@type": "Article",
          "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://masterinwebdesign.com/learningzone.html"
          },
          "headline": "Take Up a 50-Day Web Design Task!  50 DAYS WEB Design",
          "description": "Ready to take on HTML, CSS, and JavaScript? This challenge takes you from basic talent to advanced talent. Start with HTML layout, go straight to CSS for styling, and finish with dynamic JavaScript. Stay confident by sharing your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Rebuild your coding ability by adding newbies to a website. Challenges are opportunities—take a 50-day web design challenge, witness daily progress, and join the realm of Internet development. Best wishes, and happy coding!",
          "author": {
            "@type": "Person",
            "name": "Rajkumar nimod"
          },
          "publisher": {
            "@type": "Organization",
            "name": "Rajkumar nimod",
            "logo": {
              "@type": "ImageObject",
              "url": "https://masterinwebdesign.com/assets/favicon-32x32.png",
              "width": "32px",
              "height": "32px"
            }
          },
          "datePublished": "2024-04-11",
          "dateModified": "2024-04-22"
        }
        </script>
        <script src="./js/challange.js"></script>
</body>

</html>