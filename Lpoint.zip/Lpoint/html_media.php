<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Exploring HTML Media Tags: Video, Audio, Iframe, and SVG. Learn how HTML media tags enrich internet content with dynamic and interactive elements.">
    <meta name="keywords" content="HTML, Media Tags, Video, Audio, Iframe, SVG">
    <meta name="author" content="rajkumar nimod">
    <title>Exploring HTML Media Tags : - video audio iframe</title>

    <!-- Open Graph meta tags for social sharing -->
    <meta property="og:title" content="Exploring HTML Media Tags: Video, Audio, Iframe, and SVG">
    <meta property="og:description"
        content="Learn how HTML media tags enrich internet content with dynamic and interactive elements.">
    <meta property="og:type" content="website">

    <!-- Twitter Card meta tags for Twitter sharing -->
    <meta name="twitter:title" content="Exploring HTML Media Tags: Video, Audio, Iframe, and SVG">
    <meta name="twitter:description"
        content="Learn how HTML media tags enrich internet content with dynamic and interactive elements.">


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">Exploring HTML Media Tags: Video, Audio, Iframe, and SVG</h1>
                    <p class="blog-post-meta">March 7, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <h4>Video Tag:</h4>
                    <p>The <code>&lt;video&gt;</code> tag allows effortless integration of videos. Imagine a website
                        providing an instructional:</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
 <code>&lt;video width="800" height="450" controls&gt;</code>
 <code>&lt;source src="tutorial.mp4" type="video/mp4"&gt;</code>
 Your browser does not support the video tag.
 <code>&lt;/video&gt;</code></pre>
                        </div>
                    </div>
                    <h4>Audio Tag:</h4>
                    <p>The <code>&lt;audio&gt;</code> tag permits seamless embedding of audio content. Consider a track
                        internet site showcasing a new album:</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
  <code>&lt;audio controls&gt;</code>
  <code>&lt;source src="new_album.mp3" type="audio/mp3"&gt;</code>
   Your browser does not support the audio tag.
  <code>&lt;/audio&gt;</code> </pre>
                        </div>
                    </div>
                    <h4>Iframe Tag:</h4>
                    <p>The <code>&lt;iframe&gt;</code> tag is valuable for embedding external content material. Picture
                        a tour weblog proposing an interactive Google Map:</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
 <code>&lt;iframe src="https://www.google.com/maps/embed?"&gt; &lt;/iframe&gt;</code> </pre>
                        </div>
                    </div>
                    <h4>SVG Tag:</h4>
                    <p>The <code>&lt;svg&gt;</code> tag empowers developers to showcase scalable vector pics. Imagine a
                        business enterprise internet site featuring a dynamic logo:</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
 <code>&lt;svg width="200" height="200"&gt;</code>
 <code>&lt;circle cx="100" cy="100" r="80" stroke="blue" stroke-width="5" fill="orange" /&gt;</code>
 <code>&lt;/svg&gt;</code></pre>
                        </div>
                    </div>
                    <h4>Conclusion:</h4>
                    <p>These real-life examples show how HTML media tags seamlessly combine multimedia, outside content,
                        and vector graphics, raising the richness and interactivity of modern web pages.</p>

                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
        </div>
    </main>


    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>