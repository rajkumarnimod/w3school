<!DOCTYPE html>
<html lang="en">

<head>
    <!-- --------------- meta tags ------------------------------>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!---------------------- page title ---------------------->
    <title>Demystifying HTML Semantic Elements</title>
    <meta name="description" content="Demystifying HTML Semantic Elements: Crafting Intuitive Web Structures. Explore HTML's semantic elements and their real-life applications to enhance content structure and readability.">
    <meta name="keywords" content="HTML, Semantic Elements, Header, Nav, Section, Article, Aside, Footer, Details, Summary">
    <meta name="author" content="rajkumar nimod">
    <meta property="og:title" content="Demystifying HTML Semantic Elements: Crafting Intuitive Web Structures">
    <meta property="og:description" content="Explore HTML's semantic elements and their real-life applications to enhance content structure and readability.">
    <meta property="og:type" content="website">
    <meta name="twitter:title" content="Demystifying HTML Semantic Elements: Crafting Intuitive Web Structures">
    <meta name="twitter:description" content="Explore HTML's semantic elements and their real-life applications to enhance content structure and readability.">


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        code {
            font-size: 1.2rem;
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">HTML Semantic Elements: Crafting Intuitive Web Structures</h1>
                    <p class="blog-post-meta">March 6, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <h4>1. <code>&lt;header&gt;</code> Element</h4>
                    <p>The <code>&lt;header&gt;</code> tag encapsulates introductory content, usually found at the top
                        of a document
                        or a section. For example, a website's main header may contain a logo and navigation links.</p>

                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
 <code>&lt;header&gt;</code>
     <code>&lt;h1&gt;My Website header&lt;/h1&gt;</code>
      <code>&lt;nav&gt;</code>
     <code>&lt;ul&gt;</code>
         <code>&lt;li&gt;&lt;a href="#home">Home&lt;/a&gt;</li&gt;</code>
         <code>&lt;li&gt;&lt;a href="#about">About&lt;/a&gt;</li&gt;</code>
         <code>&lt;li&gt;&lt;a href="#contact">Contact&lt;/a&gt;</li&gt;</code>
     <code>&lt;/ul&gt;</code>
     <code>&lt;/nav&gt;</code>
  <code>&lt;/header&gt;</code></pre>
                        </div>
                    </div>
                    <h4>2. <code>&lt;nav&gt;</code> Element</h4>
                    <p>Used for defining navigation links within a web page, the <code>&lt;nav&gt;</code> tag aids in
                        creating
                        intuitive menus. Here's an example:</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
              <code>&lt;nav&gt;</code>
                <code>&lt;ul&gt;</code>
                   <code>&lt;li&gt;&lt;a href="#home">Home&lt;/a&gt;</li&gt;</code>
                   <code>&lt;li&gt;&lt;a href="#services">Services&lt;/a&gt;</li&gt;</code>
                   <code>&lt;li&gt;&lt;a href="#portfolio">Portfolio&lt;/a&gt;</li&gt;</code>
                <code>&lt;/ul&gt;</code>
              <code>&lt;/nav&gt;</code>
                    </pre>
                        </div>
                    </div>
                </article>
            </div>
            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>