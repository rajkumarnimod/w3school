 <nav class="navbar navbar-expand-lg navbar-light fixed-top bg-white" id="navbar">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="./assets/logo.png" alt="masterinwebdesign logo" width="140px">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link active text-dark nav_font-size"  aria-current="page" href="index">Home</a>
                    <a class="nav-link text-dark nav_font-size"  href="learningzone.php">LearningZone</a>
                    <a class="nav-link text-dark nav_font-size"  href="project.php">Project</a>
                    <a class="nav-link text-dark nav_font-size"  href="#">Blog</a>
                    <a class="nav-link text-dark nav_font-size"  href="WinningZone.php">WinningZone</a>
                    <a class="nav-link text-dark nav_font-size"  href="https://github.com/rajkumarnimod" target="_blank"> <i class="fa-brands fa-github fs-4"></i></a>
                </div>
            </div>
        </div>
    </nav>