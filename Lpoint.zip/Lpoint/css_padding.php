<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Learn how to use the CSS padding property to create space inside an element. This guide covers setting padding using one, two, three, or four values, and explores length and percentage values.">
<meta name="keywords" content="CSS, Padding Property, Web Design, CSS Padding, Padding Values, Length, Percentage, Padding Top, Padding Right, Padding Bottom, Padding Left">
<meta name="author" content="Rajkumar Nimod">
<title>CSS Padding Property</title>

<!-- Open Graph meta tags for social sharing -->
<meta property="og:title" content="Understanding the CSS Padding Property">
<meta property="og:description" content="Learn how to use the CSS padding property to create space inside an element. This guide covers setting padding using one, two, three, or four values, and explores length and percentage values.">
<meta property="og:type" content="website">
<meta name="twitter:title" content="Understanding the CSS Padding Property">
<meta name="twitter:description" content="Learn how to use the CSS padding property to create space inside an element. This guide covers setting padding using one, two, three, or four values, and explores length and percentage values.">


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">Padding Property in CSS</h2>
                    <p class="blog-post-meta">March 14, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>The padding property in CSS is used to create space inside an element, between the content and the border. You can set padding using one, two, three, or four values. Each value can be a length or a percentage. Negative values are not allowed.</p>

                    <section>
                        <h2>Using One, Two, Three, or Four Values : </h2>
                        <ul>
                            <li><b>One Value:</b> Applies the same padding to all four sides</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>padding: 20px; /* 20px on top, right, bottom, and left */</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Two Values:</b> The first value applies to the top and bottom, and the second value applies to the left and right.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>padding: 10px 20px; /* 10px top and bottom, 20px left and right */</code><pre></div>
                            </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Three Values:</b> The first value applies to the top, the second to the right and left, and the third to the bottom.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>padding: 10px 20px 30px; /* 10px top, 20px left and right, 30px bottom */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Four Values:</b> The values apply to the top, right, bottom, and left in that order (clockwise).</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>padding: 10px 20px 30px 40px; /* 10px top, 20px right, 30px bottom, 40px left */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <h2>Values </h2>
                        <ul>
                            <li><b>Length:</b> Specifies a fixed size for the padding</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>padding: 10px; /* Fixed padding of 10 pixels */</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Percentage:</b> Specifies the padding as a percentage of the element's containing block's width.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>padding: 10%; /* 10% of the containing block's width */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Auto:</b> Lets the browser choose a suitable margin. This is often used to center elements.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 0 auto; /* Centers the element horizontally */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <p><b>Padding Values:</b> The computed value for each padding side (top, right, bottom, and left) is either the percentage you specified or the exact length.</p>
                        <ul>
                         <li><b> padding-top:</b> </li>
                         <li><b> padding-right:</b> </li>
                         <li><b> padding-bottom:</b> </li>
                         <li><b> padding-left:</b> </li>
                        </ul>
                    </section>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>