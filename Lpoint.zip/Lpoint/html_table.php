<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Mastering HTML Tables: A Comprehensive Guide">
    <title>HTML Table tag</title>
    <!--  --------------meta tags ------------------  -->
    <meta name="keywords" content="HTML, Tables, HTML Table Elements, Rowspan, Colspan, Table Structure">
    <meta name="author" content="rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">
    <meta name="language" content="English">
    <meta name="rating" content="General">
    <meta property="og:title" content="Mastering HTML Tables: A Comprehensive Guide">
    <meta property="og:description" content="Learn the art of creating HTML tables with this comprehensive guide.">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">Mastering HTML Tables</h1>
                    <p class="blog-post-meta">March 9, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>

                    <h4>Key Elements of the HTML Table</h4>
                    <ul>
                        <li><code>&lt;table&gt;</code>: Serves as the box for the entire table structure.</li>
                        <li><code>&lt;tr&gt;</code>: Defines a table row, grouping a set of table cells together.</li>
                        <li><code>&lt;td&gt;</code> and <code>&lt;th&gt;</code>: Define table cells, with
                            <code>&lt;td&gt;</code>
                            for regular data cells and <code>&lt;th&gt;</code> for header cells.
                        </li>
                        <li><code>&lt;thead&gt;</code>, <code>&lt;tbody&gt;</code>, and <code>&lt;tfoot&gt;</code>:
                            Group the table
                            header, body, and footer content, respectively.</li>
                        <li><code>&lt;caption&gt;</code>: Provides a title or description for the whole table.</li>
                    </ul>

                    <h4>The Power of rowspan and colspan</h4>
                    <p>Rowspan attribute:- Allows a table cell to span multiple rows. Useful for data covering
                        multiple rows.</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;td rowspan="value"&gt;</code></pre>
                        </div>
                    </div>
                    <p>Colspan attribute:- Allows a table cell to span multiple columns. Useful for data covering
                        multiple columns.</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;td colspan="value"&gt;</code></pre>
                        </div>
                    </div>
                    <h4>Example Table</h4>
                    <table class="w-100">
                        <thead>
                            <tr>
                                <th>Header 1</th>
                                <th>Header 2</th>
                                <th>Header 3</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Data 1</td>
                                <td>Data 2</td>
                                <td>Data 3</td>
                            </tr>
                            <tr>
                                <td>Data 4</td>
                                <td colspan="2">Spanning multiple columns</td>
                            </tr>
                            <tr>
                                <td rowspan="2">Spanning multiple rows</td>
                                <td>Data 5</td>
                                <td>Data 6</td>
                            </tr>
                            <tr>
                                <td>Data 7</td>
                                <td>Data 8</td>
                            </tr>
                        </tbody>
                    </table>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
        </div>

    </main>


    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>