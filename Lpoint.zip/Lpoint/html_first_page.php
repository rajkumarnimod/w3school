<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Primary Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
    <meta name="revisit-after" content="7 days">
    <title>Creating Your First HTML Website</title>
    <meta name="title" content="Creating Your First HTML Website" />
    <meta name="description" content="A beginner's guide to creating your first HTML website. Learn the essential steps to set up your development environment, write HTML code, and view your webpage." />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://masterinwebdesign.com/html_first_page" />
    <meta property="og:title" content="Creating Your First HTML Website" />
    <meta property="og:description" content="A beginner's guide to creating your first HTML website. Learn the essential steps to set up your development environment, write HTML code, and view your webpage." />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="https://masterinwebdesign.com/html_first_page" />
    <meta property="twitter:title" content="Creating Your First HTML Website" />
    <meta property="twitter:description" content="A beginner's guide to creating your first HTML website. Learn the essential steps to set up your development environment, write HTML code, and view your webpage." />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">Creating Your First HTML Website</h1>
                    <p class="blog-post-meta">March 5, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>

                    <h4>Step 1: Set Up Your Development Environment</h4>
                    <p>Open a text editor for your PC. You can use a simple text editor like Notepad (Windows), TextEdit
                        (Mac), or a
                        more advanced code editor like Visual Studio Code, Sublime Text, or Atom.</p>

                    <h4>Step 2: Write the HTML Code</h4>
                    <p>Copy and paste the following HTML code into your text editor:</p>

                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
 <code>&lt;!DOCTYPE html&gt;</code>
 <code>&lt;html lang="en"&gt;</code>                        
 <code>&lt;head&gt;</code>
     <code>&lt;meta charset="UTF-8"&gt;</code>
     <code>&lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;</code>
     <code>&lt;title&gt;Hello, World!&lt;/title&gt;</code>
 <code>&lt;/head&gt;</code>                                     
 <code>&lt;body&gt;</code>
     <code>&lt;h1&gt;Hello, World!&lt;/h1&gt;</code>
 <code>&lt;/body&gt;</code>                                    
 <code>&lt;/html&gt;</code></pre>
                        </div>
                    </div>
                    <h4>Step 3: Save the File</h4>
                    <p>Save the document with an ".html" extension. For example, you could save it as "index.html".</p>

                    <h4>Step 4: Open in a Web Browser</h4>
                    <p>Open the saved HTML file in a web browser. You can do that by right-clicking the file, choosing
                        "Open with,"
                        and selecting your preferred internet browser.</p>

                    <h4>Step 5: View Your First Webpage</h4>
                    <p>You should see a website with the text "Hello, World!" displayed as a heading.</p>

                    <h4>Congratulations!</h4>
                    <p>You've just created and viewed your first HTML website. This is a fundamental example, and you
                        can build on
                        this foundation to learn more about HTML, CSS, and JavaScript to create more complex and
                        interactive web
                        pages.</p>

                    <h1 class="heading">HTML Tag Anatomy Example</h1>

                    <h4>HTML Tag Anatomy</h4>
                    <p>Opening Tag: The tag that marks the beginning of an HTML element. It includes the detailed name
                        enclosed in
                        angle brackets.</p>
                    <p>Closing Tag: The tag that marks the end of an HTML element. It is similar to the opening tag but
                        consists of
                        a forward slash before the element name.</p>
                    <p>Content: The real content of the HTML element that's placed between the opening and closing tags.
                    </p>
                    <p>Attribute: Additional information or properties about the element. Attributes are added to the
                        opening tag
                        and provide more information.</p>

                    <h4>HTML Example</h4>
                    <p>Let's create an easy example of a paragraph element with some text:</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre>
 <code>&lt;!DOCTYPE html&gt;</code>
 <code>&lt;html lang="en"&gt;</code>                               
 <code>&lt;head&gt;</code>
     <code>&lt;meta charset="UTF-8"&gt;</code>
     <code>&lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;</code>
     <code>&lt;title&gt;Hello, World!&lt;/title&gt;</code>
  <code>&lt;/head&gt;</code>                             
 <code>&lt;body&gt;</code>
    <code>&lt;h1&gt;Hello, World!&lt;/h1&gt;</code>
 <code>&lt;/body&gt;</code>                           
 <code>&lt;/html&gt;</code></pre>
                        </div>
                    </div>

                    <p>In this case:</p>
                    <ul>
                        <li><code>&lt;p&gt;</code> is the opening tag for a paragraph element.</li>
                        <li><code>&lt;/p&gt;</code> is the closing tag.</li>
                        <li>"This is a simple paragraph." is the content of the paragraph.</li>
                        <li>Additionally, the <code>lang="en"</code> attribute in the <code>&lt;html&gt;</code> tag
                            specifies the
                            language as English, and the <code>&lt;meta&gt;</code> tags within the
                            <code>&lt;head&gt;</code> section
                            provide metadata about the HTML document.
                        </li>
                    </ul>
                </article>
            </div>
            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>