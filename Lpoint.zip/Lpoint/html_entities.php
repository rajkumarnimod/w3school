<!DOCTYPE html>
<html lang="en">

<head>
    <!-- --------------- meta tags ------------------------------>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="HTML Entities: Special Codes for Characters and Symbols. Learn how HTML entities represent reserved characters, symbols, and fonts in HTML documents. Ensure accurate rendering on browsers for elegant content presentation.">
    <meta name="keywords" content="HTML, Entities, HTML Symbols, Reserved Characters, Special Characters, Fonts, Accented Characters, Numeric Symbols, Arrows, Web Development">
    <meta name="author" content="rajkumar nimod">
    <!---------------- page title ---------------------->
    <title>HTML Entities: Special Codes for Characters and Symbols</title>

    <meta property="og:title" content="HTML Entities: Special Codes for Characters and Symbols">
    <meta property="og:description" content="Learn how HTML entities represent reserved characters, symbols, and fonts in HTML documents. Ensure accurate rendering on browsers for elegant content presentation.">
    <meta property="og:type" content="website">
    <meta name="twitter:title" content="HTML Entities: Special Codes for Characters and Symbols">
    <meta name="twitter:description" content="Learn how HTML entities represent reserved characters, symbols, and fonts in HTML documents. Ensure accurate rendering on browsers for elegant content presentation.">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">HTML Entities: Special Codes for Characters and Symbols</h1>
                    <p class="blog-post-meta">March 4, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>

                    <h4>Introduction to HTML Entities</h4>
                    <p>HTML entities are special codes used to represent characters and symbols stored in HTML documents. These characters, like &lt;, &gt;, and &amp;, have specific meanings in HTML and cannot be used directly as text. HTML entities ensure that browsers interpret these characters correctly and display them as desired.</p>

                    <h4>Examples of Basic Symbols</h4>
                    <p>For example, the lowercase symbol is represented by &amp;lt;, the uppercase symbol by &amp;gt;, and the ampersand &amp; by &amp;amp;.</p>

                    <h4>Wide Range of Fonts</h4>
                    <p>HTML entities cover a wide range of fonts, including accented characters, numeric symbols, and arrows. For example, the copyright symbol is represented by &copy; copy;, the euro currency symbol is &euro; euro;, and the arrow symbol is &rarr; rarr;.

                    <h4>Importance in Web Development</h4>
                    <p>The use of HTML entities ensures proper rendering on browser devices, contributing to the accuracy and presentation of content on the web. Web developers often use HTML entities to handle special characters elegantly while maintaining the integrity of their HTML documents.</p>
                </article>
                <article class="blog-post">
                    <h4>HTML Entities example :</h4>
                    <table class="w-100">
                        <thead>
                            <tr>
                                <th>Character</th>
                                <th>HTML Entity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Less Than (&lt;)</td>
                                <td>&amp;lt;</td>
                            </tr>
                            <tr>
                                <td>Greater Than (&gt;)</td>
                                <td>&amp;gt;</td>
                            </tr>
                            <tr>
                                <td>Ampersand (&amp;)</td>
                                <td>&amp;amp;</td>
                            </tr>
                            <tr>
                                <td>Double Quote (")</td>
                                <td>&amp;quot;</td>
                            </tr>
                            <tr>
                                <td>Single Quote (')</td>
                                <td>&amp;apos;</td>
                            </tr>
                            <tr>
                                <td>Copyright Symbol (©)</td>
                                <td>&amp;copy;</td>
                            </tr>
                            <tr>
                                <td>Registered Trademark (®)</td>
                                <td>&amp;reg;</td>
                            </tr>
                            <tr>
                                <td>Euro Symbol (€)</td>
                                <td>&amp;euro;</td>
                            </tr>
                            <tr>
                                <td>Em Dash (—)</td>
                                <td>&amp;mdash;</td>
                            </tr>
                            <tr>
                                <td>Trade Mark (™)</td>
                                <td>&amp;trade;</td>
                            </tr>
                        </tbody>
                    </table>
                </article>
            </div>
            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
    </main>


    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>