<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Decoding CSS Selectors: An All-Inclusive Guide with Illustrations">
    <meta name="keywords" content="CSS, Selectors, Web Development, Styling, HTML">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">
    <meta name="theme-color" content="#3498db">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="application-name" content="CSS Selector Guide">
    <meta property="og:title" content="Decoding CSS Selectors: An All-Inclusive Guide">
    <meta property="og:description" content="Explore the realm of CSS selectors with real-world examples in this comprehensive guide.">
    <meta property="og:type" content="website">
    <meta name="twitter:title" content="Decoding CSS Selectors: An All-Inclusive Guide">
    <meta name="twitter:description" content="Explore the realm of CSS selectors with real-world examples in this comprehensive guide.">
    <title>css selectors - masterinwebdesign</title>

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">CSS Selectors: An All-Inclusive Guide with Illustrations
                    </h2>
                    <p class="blog-post-meta">March 14 , 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>The mainstay of web styling, Cascading Style Sheets (CSS) selectors enable programmers to
                        precisely target
                        and style HTML components. Comprehending the subtleties of CSS selectors is essential for
                        creating
                        aesthetically pleasing and orderly web pages. This post will explore the realm of CSS selectors,
                        going over
                        different kinds and using real-world examples to show how to use them.</p>
                    <section>
                        <h1 style="color: rgb(98, 56, 14);"> Basic Selectors :</h1>
                        <h3>1. Universal Selector (*) :-</h3>
                        <p>Every element on a page is selected by the universal selector. It can be useful for global
                            styling, but
                            exercise caution to prevent unexpected outcomes.
                            This example creates a clear foundation for uniform spacing by setting the margin and
                            padding of every
                            element to zero.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
  * {
      margin: 0;
      padding: 0;
    } </pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>2. Tag Selector (Element Selector) :-</h3>
                        <p>HTML elements are targeted by tag selectors. To style every paragraph on a page, for example,
                            use the
                            following:In this case, all
                        <p> components will be dark gray in color and have a font size of 16 pixels.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
  p {
       font-size: 16px;
       color: #333;
    }</pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>3. Class Selector (.) :-</h3>
                        <p>Elements with a certain class property are the focus of class selectors. In CSS, they have a
                            period (.)
                            prefixed to them. Take a look at this instance:This sets the background color of buttons
                            with the class
                            "primary-button" to blue and the text color to white.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
   html:
   <code>&lt;button class="primary-button"&gt;Click me&lt;/button &gt;</code>  
                    
    css:
   <code>
   .primary-button {
                background-color: #3498db;
                color: #fff;
                   }</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>4. ID Selector (#) :-</h3>
                        <p>ID selectors focus on a single, distinct element that has a certain ID attribute. In CSS,
                            they are preceded
                            by a hash (#). For instance, in this case, the element with the ID "header" has its
                            background and text
                            colors modified.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
   html: 
   <code>&lt;div id="header"&gt;</code> 
     <code>&lt;h1&gt;Welcome to My Website&lt;/h1&gt;</code> 
    <code>&lt;/div&gt;</code> 
                
    css:
   <code>
   .#header {
          background-color: #333;
          color: #fff;
            } </code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>5. Grouping Selectors:-</h3>
                        <p>You can apply the same style to numerous selectors within a single rule by grouping
                            selectors. This can help
                            your CSS become more manageable and succinct. As an illustration, consider this:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
   h1, h2, h3 {
                color: #4CAF50;
               font-family: 'Arial', sans-serif;
             } </code></pre>
                            </div>
                        </div>
                    </section>
                </article>
                <article class="blog-post">
                    <section>
                        <h3>6. <u>Combining Selectors</u>:-</h3>
                        <p>You can apply the same style to numerous selectors within a single rule by grouping
                            selectors. This can help
                            your CSS become more manageable and succinct. As an illustration, consider this:</p>
                    </section>
                    <section>
                        <h3> A. Descendant Selector (Whitespace)</h3>
                        <p>Elements that are descended from a given element are the target of descendant selectors. As an example, this
                            applies italic text styling to all paragraphs (
                            <code>&lt;p&gt;</code>) that descend from an
                            <code>&lt;article&gt;</code> element.
                        </p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
   article p {
                font-style: italic;
                } </code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>B. Child Selector (>)</h3>
                        <p>The direct children of a given element are the target of the child selector. Think about the
                            following:This style uses a square bullet point to list items (<code>&lt;li&gt;</code>) that are a
                            <code>&lt;ul&gt;</code>'s immediate
                            offspring.
                        </p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
   <code>
   ul > li {
         list-style-type: square;
         }</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3> C. Adjacent Sibling Selector (+)</h3>
                        <p> This selection looks for an element that comes before a given element exactly. As an illustration, this
                            bolds the paragraphs (
                            <code>&lt;p&gt;</code>) that come right after a
                            <code>&lt;h2&gt;</code> element.
                        </p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  h2 + p {
      font-weight: bold;
     }</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>D. Combining Selectors with the Sibling Combinator (~)</h3>
                        <p> When selecting all sibling elements that come
                            after a given element in CSS, use the sibling combinator (~). It's especially helpful for styling
                            elements that share a parent but come after another element.</p>
                    </section>
                    <section>
                        <h2 class="heading">Pseudo-classes and pseudo-elements</h2>
                        <p> Pseudocoles and pseudo-elements are introduced by CSS to style elements
                            according to their position or status.</p>
                        <p>1. Hover Pseudo-class (:hover) :-When the mouse is over links, this causes their color to change.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  a:hover {
           color: #ff5733;
          }</code></pre>
                            </div>
                        </div>
                        <p>2. First-child Pseudo-element (::first-child) :- Because of this, the first paragraph of its parent element
                            is bold.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
   p::first-child {
                  font-weight: bold;
                  }</code></pre>
                            </div>
                        </div>
                    </section>
                </article>
            </div>

           <!-- topics list -->
           <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>