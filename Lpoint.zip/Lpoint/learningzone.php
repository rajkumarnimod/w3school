<!DOCTYPE html>
<html lang="en">

<head>
<!-- Primary Meta Tags -->
<title>50 Days Web Challenge - masterinwebdesign</title>
<meta name="title" content="50 Days Web Challenge - masterinwebdesign" />
<meta name="description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://masterinwebdesign.com/learningzone" />
<meta property="og:title" content="50 Days Web Challenge - masterinwebdesign" />
<meta property="og:description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="https://masterinwebdesign.com/learningzone" />
<meta property="twitter:title" content="50 Days Web Challenge - masterinwebdesign" />
<meta property="twitter:description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main>
        <div class="container py-4">
            <div class="p-3 mb-4 rounded-3 bg-light">
                <div class="container-fluid py-3">
                    <p>Take Up a 50-Day Web Design Task!</p>
                    <h1 class="display-5 fw-bold">50 DAYS <span style="color: blue;">WEB</span> Learningzone</h1>
                    <p class="fs-6">Are you ready to study HTML, CSS, and JavaScript? With this challenge, your talent advances from basic to advanced. The first step is HTML layout, which is quickly followed by CSS styling and dynamic JavaScript to finish the design. Stay confident by posting updates about your progress on social media with the hashtag #50DAYSWEBDESIGNCHALLENGE. Add beginners to a website to practice your coding. Challenges present opportunities; join a 50-day web design challenge to witness everyday progress and sample the Internet development industry. Best wishes and happy coding!</p>
                    <a class="btn btn-lg header_btn type1" type="button" href="challange50days.php"></a>
                </div>
            </div>

            <div class="row align-items-md-stretch">
                <div class="col-md-6 my-2">
                    <div class="h-100 p-5 border rounded-3" id="tut-sec">
                        <h2>HTML Tutorial</h2>
                        <p>It's fun to learn HTML, the primary language used to generate web pages, and it lets you make your own website. Check out our free HTML tutorials to learn the basics and get started creating your own website right away. Set off on the journey to become a web developer!</p>
                        <a class="btn btn-outline-secondary" type="button" href="html_Introduction.php">Master HTML with Our Free Tutorials</a>
                    </div>
                </div>
                <div class="col-md-6 my-2">
                    <div class="h-100 p-5 border rounded-3" id="tut-sec">
                        <h2>CSS Tutorial</h2>
                        <p>The appearance of web elements is improved using CSS styling HTML texts. To produce innovative and useful designs, follow our tutorial, which covers everything from fundamentals to sophisticated methods. To create visually appealing and user-friendly websites, learn CSS. Launch right now!</p>
                        <a class="btn btn-outline-secondary" type="button" href="css_introduction.php">Master css with Our Free Tutorials</a>
                    </div>
                </div>
                <div class="col-md-6 my-2">
                    <div class="h-100 p-5 border rounded-3" id="tut-sec">
                        <h2>JAVASCRIPT Tutorial</h2>
                        <p>Create dynamic, responsive websites with JavaScript, the dynamic language required for interactive web pages. Take advantage of our free JavaScript tutorials to learn the fundamentals, develop features, and improve your web development abilities. Get started with coding now!</p>
                        <a class="btn btn-outline-secondary" type="button" href="html_Introduction.php">Master JavaScript with Our Free Tutorials</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->
</body>

</html>