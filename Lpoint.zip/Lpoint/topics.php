<div class="col-lg-2 col-md-3">
    <div class="position-sticky" style="top: 3rem;">
        <div class="py-4 px-1">
            <h4 class="fst-italic">Other topic</h4>
            <ol class="list-unstyled mb-0">
                <li><a href="html_Introduction.php">Html Introdution</a></li>
                <li><a href="html_Installation.php">Installation</a></li>
                <li><a href="html_first_page.php">Html First Page</a></li>
                <li><a href="html_tags.php">Html Tags</a></li>
                <li><a href="html_classid.php">Class / Id</a></li>
                <li><a href="html_list.php">Html List</a></li>
                <li><a href="html_table.php">Html Table</a></li>
                <li><a href="html_form.php">Html Form</a></li>
                <li><a href="html_media.php">Html Media</a></li>
                <li><a href="html_layout.php">Page Layout</a></li>
                <li><a href="html_entities.php">Html Entities</a></li>
                <li><a href="html_brackpoints.php">Html Brackpoints</a></li>
                <li><a href="html_sizeunits.php">Size Units</a></li>
                <li><a href="html_metatags.php">Html Meta Tags</a></li>
            </ol>
        </div>
    </div>
</div>