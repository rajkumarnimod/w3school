var lead = [
    {name:"Rajkumar sharma", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"https://www.linkedin.com/in/rajkumar-nimod/"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/flat-round/48/star--v1.png", day:"50/50 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/737373/star--v1.png", day:"50/45 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"},
    // {name:"Your name", Image:"https://img.icons8.com/ios-filled/48/b45309/star--v1.png", day:"50/40 days", linkedin:"https://img.icons8.com/fluency/48/linkedin.png",link:"#"}
]


function showLeaderBoard(){
    var clutter = "";
    lead.forEach(function(obj) {
        clutter += `  <div class="leaderboard_member_col">
        <div>
          <img width="48" height="48" src="${obj.Image}" alt="star--v1" />
        </div>
        <div class="leader_name">
          <h5>${obj.name}</h5>
          <p style="font-size: 16px;">${obj.day}</p>
        </div>
        <div>
        <a href="${obj.link}" target="_blank">
          <img width="48" height="48" src="${obj.linkedin}" alt="linkedin" />
          </a>
        </div>
      </div>`;
    });
 document.querySelector(".leaderboard_member_row").innerHTML = clutter;
}
showLeaderBoard();