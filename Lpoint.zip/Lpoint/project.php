<!DOCTYPE html>
<html lang="en">

<head>
<!-- Primary Meta Tags -->
<title>Inspiring Project Showcase - masterinwebdesign</title>
<meta name="title" content="Exploring Web Design || Inspiring Project Showcase - masterinwebdesign" />
<meta name="description" content="Welcome to our collection of projects! Here, you'll find a variety of examples and projects that showcase the world of web design. Whether you're looking for ideas or just want to see what's possible, this section has something for everyone." />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://masterinwebdesign.com/project" />
<meta property="og:title" content="Exploring Web Design || Inspiring Project Showcase - masterinwebdesign" />
<meta property="og:description" content="Welcome to our collection of projects! Here, you'll find a variety of examples and projects that showcase the world of web design. Whether you're looking for ideas or just want to see what's possible, this section has something for everyone." />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="https://masterinwebdesign.com/project" />
<meta property="twitter:title" content="Exploring Web Design || Inspiring Project Showcase - masterinwebdesign" />
<meta property="twitter:description" content="Welcome to our collection of projects! Here, you'll find a variety of examples and projects that showcase the world of web design. Whether you're looking for ideas or just want to see what's possible, this section has something for everyone." />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">

    <style>
        /* body {
            background: linear-gradient(#76c5f3b6, #f2e390c3, #8ae2d8be, #f3cd8bbb 50%, #6eedf9c3 98%);
        } */

        .challenge_head {
            font-size: 5vw;
        }

        @media screen and (max-width: 768px) {
            .challenge_head {
                font-size: 7vw;
            }
        }

        @media screen and (max-width: 400px) {
            .challenge_head {
                font-size: 12vw;
            }
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main>
        <section class="py-5 text-center container">
            <div class="row py-lg-5">
                <div class="col-lg-12 col-md-10 mx-auto">
                    <p style="font-size: 1rem;">Start a Web Design Challenge|| Code Mastery Journey!</p>
                    <h5 class="challenge_head"> Exploring Web Design: Inspiring<span style="color:#0B5ED7;"> Project
                        </span>Showcase</h5>
                    <p>
                        Welcome to our collection of projects! Here, you'll find a variety of examples and projects that showcase
                        the world of web design. Whether you're looking for ideas or just want to see what's possible, this section
                        has something for everyone.
                    </p>
                </div>
            </div>
        </section>

        <section class="container my-3">
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/1m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton1"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/2m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton2"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/3m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton3"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/4m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton4"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/5m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton5"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/6m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton6"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/7m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton7"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/8m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton8"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/9m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton9"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/10m.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton10"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/11m.webp" class="card-img-top" alt="masterinwebdesign project" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton11"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/12m.webp" class="card-img-top" alt="masterinwebdesign project" title="css project two">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary" id="downloadButton12"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</button>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/13m.webp" class="card-img-top" alt="masterinwebdesign project" title="css project two">
                        <div class="card-body">
                            <a href="https://github.com/rajkumarnimod/13m-project" target="_blank" class="btn btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/age_calculator.webp" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <a href="https://github.com/rajkumarnimod/age-calculator" target="_blank" class="btn btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/digitalclock.JPG" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <a href="https://github.com/rajkumarnimod/Digital-Clock-with-date" target="_blank" class="btn btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/stopwatch.JPG" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <a href="https://github.com/rajkumarnimod/stopwatch" target="_blank" class="btn btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/tictactoe.JPG" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <a href="https://github.com/rajkumarnimod/Tic-Tac-Toe" target="_blank" class="btn btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="./assets/projectspic/backgroundslider.JPG" class="card-img-top" alt="masterinwebdesign project two" title="css project two">
                        <div class="card-body">
                            <a href="https://github.com/rajkumarnimod/background-slider" target="_blank" class="btn btn-primary"><i class="fa-solid fa-cloud-arrow-down"></i> Download Assets</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

    <script>
        // Function to handle the click event for each button
        function handleButtonClick(imagePath) {
            return function() {
                var downloadLink = document.createElement("a");
                downloadLink.href = imagePath;
                downloadLink.download = imagePath.substring(imagePath.lastIndexOf('/') + 1);
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            };
        }

        // Add event listeners to each button
        document.getElementById("downloadButton1").addEventListener("click", handleButtonClick("./assets/projectspic/1m.webp"));
        document.getElementById("downloadButton2").addEventListener("click", handleButtonClick("./assets/projectspic/2m.webp"));
        document.getElementById("downloadButton3").addEventListener("click", handleButtonClick("./assets/projectspic/3m.webp"));
        document.getElementById("downloadButton4").addEventListener("click", handleButtonClick("./assets/projectspic/4m.webp"));
        document.getElementById("downloadButton5").addEventListener("click", handleButtonClick("./assets/projectspic/5m.webp"));
        document.getElementById("downloadButton6").addEventListener("click", handleButtonClick("./assets/projectspic/6m.webp"));
        document.getElementById("downloadButton7").addEventListener("click", handleButtonClick("./assets/projectspic/7m.webp"));
        document.getElementById("downloadButton8").addEventListener("click", handleButtonClick("./assets/projectspic/8m.webp"));
        document.getElementById("downloadButton9").addEventListener("click", handleButtonClick("./assets/projectspic/9m.webp"));
        document.getElementById("downloadButton10").addEventListener("click", handleButtonClick("./assets/projectspic/10m.webp"));
        document.getElementById("downloadButton11").addEventListener("click", handleButtonClick("./assets/projectspic/11m.webp"));
        document.getElementById("downloadButton12").addEventListener("click", handleButtonClick("./assets/projectspic/12m.webp"));
    </script>
</body>

</html>