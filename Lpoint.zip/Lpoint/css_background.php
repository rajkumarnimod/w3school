<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Mastering CSS Background Properties: A Comprehensive Guide. Learn about various CSS background properties including color, image, repeat, attachment, position, and shorthand, with examples.">
    <meta name="keywords" content="CSS, Background Properties, Web Design, Background Color, Background Image, Background Repeat, Background Attachment, Background Position, CSS Shorthand">
    <meta name="author" content="Rajkumar Nimod">
    <title>Mastering CSS Background Properties: - masterinwebdesign</title>

    <!-- Open Graph meta tags for social sharing -->
    <meta property="og:title" content="Mastering CSS Background Properties: A Comprehensive Guide">
    <meta property="og:description" content="Learn about various CSS background properties including color, image, repeat, attachment, position, and shorthand, with examples.">
    <meta property="og:type" content="website">
    <meta name="twitter:title" content="Mastering CSS Background Properties: A Comprehensive Guide">
    <meta name="twitter:description" content="Learn about various CSS background properties including color, image, repeat, attachment, position, and shorthand, with examples.">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        span {
            color: rgb(97, 187, 97);
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">Mastering CSS Background Properties: A Comprehensive Guide</h2>
                    <p class="blog-post-meta">March 12, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>In web design, creating an attractive layout is important. One of the most powerful tools in a
                        web designer’s arsenal is CSS, especially the various background properties it offers. From
                        adding colors and graphics to managing their positioning and repetition, CSS external elements
                        can be complex manipulations. Let’s examine each of these properties with examples to better
                        understand their potential.</p>
                    <section>
                        <h3>1. background-color</h3>
                        <p>The background-color property sets the color of an element's background. It can be specified
                            using color names, HEX codes, RGB, RGBA, HSL, or HSLA values.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                div {
                                background-color: #3498db; <span> /* HEX color */</span>
                                }
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>2. background-image</h3>
                        <p>With background-image, you can set an image as the background of an element. This property
                            accepts URLs pointing to image files.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                div {
                                background-image: url('background.jpg'); <span>/* Image URL */</span>
                                }
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3> 3. background-repeat</h3>
                        <p>The background-repeat property defines how a background image should repeat both horizontally
                            and vertically. It can take values like repeat, repeat-x, repeat-y, and no-repeat.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                div {
                                background-image: url('pattern.png');
                                background-repeat: repeat-x; <span>/* Repeat horizontally */</span>
                                }
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3> 4. background-attachment</h3>
                        <p> background-attachment specifies whether a background image should scroll with the content or
                            remain fixed as the viewport moves.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                div {
                                background-image: url('hero-bg.jpg');
                                background-attachment: fixed; <span>/* Fixed background */</span>
                                }
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3>5. background-position</h3>
                        <p>This property determines the starting position of a background image within its containing
                            element. It can accept various values such as keywords (top, center, bottom) or length units
                            (px, %).</p>

                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                div {
                                background-image: url('banner.jpg');
                                background-position: center top; <span>/* Centered horizontally, aligned to top */</span>
                                }
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3> 6. background (shorthand property)</h3>
                        <p> The background shorthand property allows you to set all background properties in one
                            declaration. It follows a specific order: background-color, background-image,
                            background-repeat,
                            background-attachment, and background-position.</p>

                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                div {
                                background: #fff url('bg.png') no-repeat fixed center;
                                }
                            </div>
                        </div>
                    </section>

                </article>

                <article class="blog-post">
                    <h2>summary :</h2>
                    <p>Optimizing CSS background assets provides countless possibilities for creating beautiful web
                        designs. Designers can add depth and personality to their web pages through background colors,
                        background images, background repetition, background juxtaposition, background style, and
                        shorthand background type If you use these elements and understand their nuances will definitely
                        improve your design skills.</p>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>