<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Character Set -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn how to use the CSS outline property to create outlines around elements. This guide covers how to set outlines using various styles and explores length and color values.">
    <meta name="keywords" content="CSS, Outline Property, Web Design, CSS Outlines, Outline Values, Length, Color, Outline Offset">
    <meta name="author" content="Rajkumar Nimod">

    <!-- Page Title -->
    <title>CSS Outline Property</title>

    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="Understanding the CSS Outline Property">
    <meta property="og:description" content="Learn how to use the CSS outline property to create outlines around elements. This guide covers how to set outlines using various styles and explores length and color values.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.example.com/css-outline-property">
    <meta property="og:image" content="https://www.example.com/images/css-outline-guide.png">

    <!-- Twitter Meta Tags for Social Sharing -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Understanding the CSS Outline Property">
    <meta name="twitter:description" content="Learn how to use the CSS outline property to create outlines around elements. This guide covers how to set outlines using various styles and explores length and color values.">
    <meta name="twitter:url" content="https://www.example.com/css-outline-property">
    <meta name="twitter:image" content="https://www.example.com/images/css-outline-guide.png">

    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        .border_style {
            display: inline-block;
            padding: 5px 10px;
        }

        p.dotted {
            border: dotted;
        }

        p.dashed {
            border: dashed;
        }

        p.solid {
            border: solid;
        }

        p.double {
            border-style: double;
        }

        .border_style3d {
            padding: 2vw;
        }

        p.groove {
            border-style: groove;
        }

        p.ridge {
            border-style: ridge;
        }

        p.inset {
            border-style: inset;
        }

        p.outset {
            border-style: outset;
        }

        p.style3dp {
            border-width: 15px;
            border-color: rgb(14, 14, 14);
            margin: 10px;
            display: inline-block;
            padding: 15px 20px;
        }

        p.none {
            border-style: none;
            margin: 10px;
            display: inline-block;
            padding: 15px 20px;
        }

        p.hidden {
            border-style: hidden;
            margin: 10px;
            display: inline-block;
            padding: 15px 20px;
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">Uncovering the Potential of CSS Outline Property: An All-Inclusive Manual</h2>
                    <p class="blog-post-meta">March 12, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>An essential component of web design is the CSS outline feature, which gives programmers the ability to highlight an element without affecting its size. The outline-style attribute, which determines the kind of outline to be displayed, is the fundamental component of this property. To appreciate the variety it provides, let's examine a few different styles using real-world instances.</p>

                    <section>
                        <h2>Dotted Outline: <a href="css_outline_view.php" type="button" class="btn btn-outline-primary">Preview</a></h2>
                        <p>A row of dots is drawn along the outline in the dotted style. To do this, change the outline style to dotted. For instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .element {
      outline-style: dotted;
  }</code></pre>
                            </div>
                        </div>
                        <p class="dotted outline_style">Dotted Outline / outline: 2px dotted black;</p>
                    </section>
                    <section>
                        <h2>Dashed Outline:</h2>
                        <p>The dashed style creates an outline with dashed lines for a more pronounced divide. For instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
 .element {
      outline-style: dashed;
 }</code></pre>
                            </div>
                        </div>
                        <p class="dashed outline_style">Dashed Outline / outline: 2px dashed black;</p>
                    </section>
                    <section>
                        <h2>Solid Outline:</h2>
                        <p>This is the most basic and default style; it creates a continuous, solid line. For instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .element {
      outline-style: solid;
  }</code></pre>
                            </div>
                        </div>
                        <p class="solid outline_style">Solid Outline / outline: 2px solid black;</p>
                    </section>
                    <section>
                        <h2>Double Outline:</h2>
                        <p>The double style gives the impression of being bolder by drawing two parallel lines. For instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .element {
      outline-style: double;
  }
        </code></pre>
                            </div>
                        </div>
                        <p class="double outline_style">Double Outline / outline: 2px double black;</p>
                    </section>

                    <section>
                        <h2>3D Outlines: Inset, Ridge, Outset, and Groove:</h2>
                        <p>These outline styles, which depend on the outline-color value for visual impact, add a three-dimensional effect. As an illustration:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .grooved {
      outline-style: groove;
      outline-color: #3498db;
  }
              
  .ridged {
      outline-style: ridge;
      outline-color: #e74c3c;
  }
              
  .inset {
      outline-style: inset;
      outline-color: #2ecc71;
  }
              
  .outset {
      outline-style: outset;
      outline-color: #f39c12;
  }</code></pre>
                            </div>
                            <div class="outline_style3d bg-orangebtn">
                                <p class="inset style3dp">Inset Outline</p>
                                <p class="ridge style3dp">Ridge Outline</p>
                                <p class="outset style3dp">Outset Outline</p>
                                <p class="groove style3dp">Groove Outline</p>
                            </div>
                    </section>

                    <section>
                        <h2>No Outline and Hidden Outline:</h2>
                        <p>Outlines are completely removed when outline-style is set to none; they remain invisible but take up space when set to hidden. As an illustration:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .no-outline { 
      outline-style: none;
  }
              
  .hidden {
      outline-style: hidden;
  }</code></pre>
                            </div>
                        </div>
                        <div class="outline_style3d bg-orangebtn">
                            <p class="none">No Outline</p>
                            <p class="hidden">Hidden Outline</p>
                        </div>
                    </section>
                    <a href="css_outline_view.php" type="button" class="btn btn-outline-primary w-100">View Preview</a>
                </article>

                <article class="blog-post">
                    <h2>Summary:</h2>
                    <p>Understanding these outline-style variations empowers developers to craft visually appealing and diverse designs, elevating the aesthetics of web interfaces. Experimenting with these styles provides hands-on experience in leveraging the full potential of the CSS outline property for creative and polished web development.</p>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>