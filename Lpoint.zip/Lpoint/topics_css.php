<div class="col-lg-2 col-md-3">
    <div class="position-sticky" style="top: 3rem;">
        <div class="py-4 px-1">
            <h4 class="fst-italic">Other topic</h4>
            <ol class="list-unstyled mb-0">
                <li><a href="css_introduction.php">Css Introdution</a></li>
                <li><a href="css_selector.php">Css selector</a></li>
                <li><a href="css_syntax.php">Css syntax</a></li>
                <li><a href="css_border.php">Css border</a></li>
                <li><a href="css_outline.php">Css outline</a></li>
                <li><a href="css_padding.php">Css padding</a></li>
                <li><a href="css_margin.php">Css margin</a></li>
                <li><a href="css_background.php">Css background</a></li>
                <li><a href="css_text.php">Css test</a></li>
                <li><a href="css_font.php">Css font</a></li>
                <li><a href="css_display.php">Css display</a></li>
                <li><a href="css_flex.php">Css flex</a></li>
                <li><a href="css_transforms.php">Css transform</a></li>
                <li><a href="css_transition.php">Css transitions</a></li>
            </ol>
        </div>
    </div>
</div>