// questions.js

const questions = [
    {
      question: "What is the capital of France?",
      options: ["Berlin", "Madrid", "Paris", "Rome"],
      correctOption: "Paris"
    },
    {
      question: "What is the capital of Germany?",
      options: ["Berlin", "Madrid", "Paris", "Rome"],
      correctOption: "Berlin"
    },
    {
      question: "What is the capital of Spain?",
      options: ["Berlin", "Madrid", "Paris", "Rome"],
      correctOption: "Madrid"
    },
    // Add more questions here...
  ];
  
  export default questions;
  