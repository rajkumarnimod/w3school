var copyButtons = document.querySelectorAll(".copyButton");

  // Attach the copyContent function to each button
  copyButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      copyContent(button);
    });
  });

  function copyContent(clickedButton) {
    // Find the container relative to the clicked button
    var container = clickedButton.closest(".contentToCopy");
    if (!container) return;

    // Find elements within the container
    var copyButton = container.querySelector(".copyButton");
    var copyMessage = container.querySelector(".copyMessage");

    // Create a temporary element to hold the content
    var tempContainer = document.createElement("div");

    // Clone the container content (excluding the copyButton)
    var contentClone = container.cloneNode(true);
    var buttonToRemove = contentClone.querySelector(".copyButton");
    if (buttonToRemove) {
      contentClone.removeChild(buttonToRemove);
    }

    // Append the cloned content to the temporary container
    tempContainer.appendChild(contentClone);

    // Create a temporary textarea
    var tempTextarea = document.createElement("textarea");
    tempTextarea.value = tempContainer.textContent;

    // Append the textarea to the document
    document.body.appendChild(tempTextarea);

    // Select the text in the textarea
    tempTextarea.select();
    tempTextarea.setSelectionRange(0, 99999); /* For mobile devices */

    // Copy the text inside the textarea
    document.execCommand("copy");

    // Remove the temporary textarea from the document
    document.body.removeChild(tempTextarea);

    // Show the "Copied" message inside the button
    copyButton.textContent = "Copied";
    copyMessage.textContent = "!";
    copyMessage.style.display = "absolute";

    // Hide the message and revert button text after 2 seconds
    setTimeout(function () {
      copyButton.textContent = "Copy";
      copyMessage.textContent = "";
      copyMessage.style.display = "none";
    }, 2000);
  }
