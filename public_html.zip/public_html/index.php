<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Google Tag Manager -->
  <script>
    (function(w, d, s, l, i) {
      w[l] = w[l] || [];
      w[l].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
      });
      var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != 'dataLayer' ? '&l=' + l : '';
      j.async = true;
      j.src =
        'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
      f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-N37GWT54');
  </script>
  <!-- End Google Tag Manager -->

  <!-- Required meta tags -->
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
  <!-- Primary Meta Tags -->
  <title>masterinwebdesign - Master Front-End Skills for Your Dream Job</title>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="Rajkumar Nimod">

<!-- Primary Meta Tags -->
<title>masterinwebdesign - Embark on Your Journey into Front-End Development</title>
<meta name="title" content="masterinwebdesign - Embark on Your Journey into Front-End Development" />
<meta name="description" content="Embark on your journey into the exciting world of front-end development with masterinwebdesign. Whether you're passionate about design, fascinated by technology, or simply looking for a new challenge, web design offers endless possibilities for creativity and growth. Don't wait any longer - take the first step now and watch your career soar to new heights!" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://masterinwebdesign.com/" />
<meta property="og:title" content="masterinwebdesign - Embark on Your Journey into Front-End Development" />
<meta property="og:description" content="Embark on your journey into the exciting world of front-end development with masterinwebdesign. Whether you're passionate about design, fascinated by technology, or simply looking for a new challenge, web design offers endless possibilities for creativity and growth. Don't wait any longer - take the first step now and watch your career soar to new heights!" />
<meta property="og:image" content="https://masterinwebdesign.com/assets/project.webp" />

<!-- Twitter -->
<meta property="twitter:url" content="https://masterinwebdesign.com/" />
<meta property="twitter:title" content="masterinwebdesign - Embark on Your Journey into Front-End Development" />
<meta property="twitter:description" content="Embark on your journey into the exciting world of front-end development with masterinwebdesign. Whether you're passionate about design, fascinated by technology, or simply looking for a new challenge, web design offers endless possibilities for creativity and growth. Don't wait any longer - take the first step now and watch your career soar to new heights!" />
<meta property="twitter:image" content="https://masterinwebdesign.com/assets/project.webp" />

  <!--INCLUDE file: commanstyle css file -->
  <?php include './commanstyle.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!--INCLUDE file: navbar_js -->
  <?php include './js/navbar_js.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!--INCLUDE file: Navbar -->
  <?php include './js/cdn.php'; ?>
  <!--INCLUDE file: Navbar -->
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/navbar.css">

  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-26CRVZNL45"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-26CRVZNL45');
  </script>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org/",
      "@type": "WebSite",
      "name": "masterinwebdesign",
      "url": "https://masterinwebdesign.com/",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://masterinwebdesign.com/learningzone.html{search_term_string}https://masterinwebdesign.com/leaderboard.html",
        "query-input": "required name=search_term_string"
      }
    }
  </script>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Article",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": "https://masterinwebdesign.com/"
      },
      "headline": "Front-End Development Master front-end skills for a career.",
      "image": [
        "https://masterinwebdesign.com/assets/project.webp",
        "https://masterinwebdesign.com/assets/questions.svg",
        "https://masterinwebdesign.com/assets/blog.svg"
      ],
      "author": {
        "@type": "Person",
        "name": "Rajkumar nimod"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Rajkumar nimod",
        "logo": {
          "@type": "ImageObject",
          "url": "https://masterinwebdesign.com/assets/favicon-32x32.png"
        }
      },
      "datePublished": "2024-04-09",
      "dateModified": "2024-04-22"
    }
  </script>
</head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <!-- top left to right animation  -->
  <div class="topscroll">
  </div>

  <!--INCLUDE file: Navbar -->
  <?php include 'navbar.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!-- header section start  -->
  <header>
    <div class="container pb-5" id="header">
      <div class="row g-5">
        <div class="col-md-7 d-flex justify-content-center align-items-center flex-column">
          <h2 class="display-5 fw-bold header_heading" style="margin-top: 3.3vw;">Explore Front-End Development:<span class="text-muted"> Master Web Design!</span></h2>
          <p title="masterinwebdesign hero line" style="padding-right: 3vw;">Embark on your journey into the exciting world of front-end development &#128187; with masterinwebdesign. Whether you're passionate about design, fascinated by technology, or simply looking for a new challenge, web design offers endless possibilities for creativity and growth. &#127942; Don't wait any longer - take the first step now and watch your career soar to new heights! &#128640;</p>
        </div>
        <div class="col-md-5 d-flex justify-content-center align-items-center flex-column">
          <img src="./assets/header_img.svg" alt="" class="img-fluid mx-auto" width="500" height="500">
        </div>
      </div>
    </div>
  </header>
  <!-- header section end-->

  <!----- who mwd section start ----->
  <section style=" background: linear-gradient(to right, #09f1b720, #00a2ff17, #ff00d012, #feda0f20);">
    <div class="container py-5">
      <h1 class="display-10 pb-2 text-center">Who's on MasterinWebDesign ?</h1>
      <div class="row justify-content-between g-3">
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <h4 class="pb-2">Learners <i class="fa-solid fa-graduation-cap"></i></h4>
            <p>Master HTML, CSS, and JavaScript through our engaging projects, interactive quizzes, and comprehensive tutorials designed for all levels </p>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4 mt-md-5 mt-lg-5">
          <div class="p-3 border shadow custom-card" style="border-radius: 15px;">
            <h4 class="pb-2"> Developers <i class="fa-solid fa-code" style="color: #20BEFF;"></i></h4>
            <p>Enhance your web development skills with our extensive project templates, practical code snippets, and challenging quizzes.</p>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <h4 class="pb-2">Designers <i class="fa-regular fa-paste" style="color: #1FA741;"></i></h4>
            <p>Create stunning websites using our curated CSS frameworks, inspiring design projects, and interactive quizzes to refine your skills. </p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!----- who mwd section end ----->

  <!-- html tutorial section start  -->
  <section>
    <div class="container responsive-padding">
      <h4 class="display-10 pb-3 px-2"><i class="fa-brands fa-html5"></i> HTML Learning Zone</h4>
      <div class="row justify-content-between g-3">
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-book-open fs-3" style="color: #FAE041;"></i>
            </div>
            <h3 class="fw-normal">HTML Tutorial</h3>
            <p>Master HTML fundamentals and advanced techniques for proficient web development skills.</p>
            <div class="my-2">
              <a href="html_Introduction.php" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-lightbulb fs-3" style="color: #20BEFF;"></i>
            </div>
            <h3 class="fw-normal">HTML Project</h3>
            <p>Create practical HTML projects to strengthen foundational coding abilities and enhance web development proficiency.</p>
            <div class="my-2">
              <a href="project.php" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-clipboard-question fs-3" style="color: #1FA741;"></i>
            </div>
            <h3 class="fw-normal">HTML Quiz</h3>
            <p>Test your HTML knowledge with interactive quizzes covering syntax, elements, and web development concepts.</p>
            <div class="my-2">
              <a href="./projects.html" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- html tutorial section end  -->

  <!--css tutorial section start  -->
  <section>
    <div class="container responsive-padding">
      <h4 class="display-10 pb-3 px-2"><i class="fa-brands fa-css3-alt"></i> CSS Learning Zone</h4>
      <div class="row justify-content-between g-3">
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-book-open fs-3" style="color: #FAE041;"></i>
            </div>
            <h3 class="fw-normal">CSS Tutorial</h3>
            <p>Master css fundamentals and advanced techniques for proficient web development skills.</p>
            <div class="my-2">
              <a href="css_introduction.php" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-lightbulb fs-3" style="color: #20BEFF;"></i>
            </div>
            <h3 class="fw-normal">CSS Project</h3>
            <p>Build expertise with responsive and current web layouts, refine design strategies, and strengthen core styling abilities by creating useful CSS projects.</p>
            <div class="my-2">
              <a href="project.php" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-clipboard-question fs-3" style="color: #1FA741;"></i>
            </div>
            <h3 class="fw-normal">CSS Quiz</h3>
            <p>Take interactive quizzes on syntax, elements, and web development principles to see how much you know about CSS.</p>
            <div class="my-2">
              <a href="./projects.html" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--css tutorial section end  -->

  <!--javascript tutorial section start  -->
  <section>
    <div class="container responsive-padding">
      <h4 class="display-10 pb-3 px-2"><i class="fa-brands fa-js"></i> JAVASCRIPT Learning Zone</h4>
      <div class="row justify-content-between g-3">
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-book-open fs-3" style="color: #f6d920;"></i>
            </div>
            <h3 class="fw-normal">JAVASCRIPT Tutorial</h3>
            <p>Learn the foundations and advanced techniques of JavaScript to become a professional web developer..</p>
            <div class="my-2">
              <a href="./projects.html" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-lightbulb fs-3" style="color: #20BEFF;"></i>
            </div>
            <h3 class="fw-normal">JAVASCRIPT Project</h3>
            <p>Build useful Javascript projects to bolster your basic coding skills and advance your web development knowledge..</p>
            <div class="my-2">
              <a href="./projects.html" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-5 col-lg-4">
          <div class="p-3 border box_shadow custom-card">
            <div class="feature-icon">
              <i class="fas fa-clipboard-question fs-3" style="color: #1FA741;"></i>
            </div>
            <h3 class="fw-normal">JAVASCRIPT Quiz</h3>
            <p>Check your knowledge of Javascript with interactive tests on language, elements, and web building concepts.</p>
            <div class="my-2">
              <a href="./projects.html" class="cta text-decoration-none">
                <span> Explore</span>
                <svg width="18px" height="12px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--javascript tutorial section end  -->

  <section>
    <div class="px-3 my-3 border-bottom py-5 text-center scroll-reveal" style=" background: linear-gradient(to right, #09f1b720, #00a2ff17, #ff00d012, #feda0f20);">
      <h1 class="display-4 fw-bold"><span>Master web design projects confidently.</span></h1>
      <div class="col-lg-8 mx-auto">
        <p class="lead mb-4"><span>Masterinwebdesign provides comprehensive resources and knowledge essential for your upcoming real-world web design projects, offering everything you need to succeed in creating professional and effective websites.</span></p>
      </div>
      <div class="overflow-hidden" style="max-height: 30vh;">
        <div class="container">
          <div class="row justify-content-center gap-3">
            <div class="col-3">
              <h1 class="text-center"><span class="counter" data-count="150" style="color: #FAE041;">0</span> <br>Tutorial</h1>
            </div>
            <div class="col-3">
              <h1 class="text-center"><span class="counter" data-count="250" style="color: #20BEFF;">0</span> <br>project</h1>
            </div>
            <div class="col-3">
              <h1 class="text-center"><span class="counter" data-count="100" style="color: #1FA741;">0</span> <br>Blog</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- top button -->
  <button class="topbtn"><i class="fa-solid fa-arrow-up"></i> Back to top</button>

  <!-- Footer -->
  <?php include 'footer.php'; ?>
  <!-- Footer -->

  <script>
    // number counting script 

    $(document).ready(function() {
      function animateCounter($element, start, end, duration) {
        $({
          count: start
        }).animate({
          count: end
        }, {
          duration: duration,
          easing: 'swing',
          step: function() {
            $element.text(Math.ceil(this.count));
          }
        });
      }

      function checkVisibility() {
        $('.counter').each(function() {
          var $this = $(this);
          if ($this.visible(true) && !$this.hasClass('counted')) {
            $this.addClass('counted');
            var endValue = parseInt($this.data('count'));
            animateCounter($this, 0, endValue, 3000);
          }
        });
      }

      $(window).on('scroll', checkVisibility);
      checkVisibility();
    });

    $.fn.visible = function(partial) {
      var $t = $(this),
        $w = $(window),
        viewTop = $w.scrollTop(),
        viewBottom = viewTop + $w.height(),
        _top = $t.offset().top,
        _bottom = _top + $t.height(),
        compareTop = partial === true ? _bottom : _top,
        compareBottom = partial === true ? _top : _bottom;

      return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
    };
  </script>
   <script>
const topbtn = document.querySelector('.topbtn');

const displayButton = () => {
  window.addEventListener('scroll', () => {
    console.log(window.scrollY);
  
    if (window.scrollY > 500) {
      topbtn.style.display = "block";
    } else {
      topbtn.style.display = "none";
    }
  });
};

const scrollToTop = () => {
  topbtn.addEventListener("click", () => {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    }); 
    console.log(event);
  });
};

displayButton();
scrollToTop();
    </script>
</body>

</html>