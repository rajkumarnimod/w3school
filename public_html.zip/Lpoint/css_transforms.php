<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Explore the power of CSS transforms with this comprehensive guide. Learn about translate(), rotate(), scale(), skew(), and matrix() methods for dynamic web development.">
    <meta name="keywords" content="CSS, Transforms, Web Development, Animation, Scaling, Rotation, Skewing, Matrix">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">
    <meta name="og:title" property="og:title" content="The Power of CSS Transforms: A Comprehensive Guide">
    <meta name="og:description" property="og:description" content="Explore the power of CSS transforms with this comprehensive guide. Learn about translate(), rotate(), scale(), skew(), and matrix() methods for dynamic web development.">
    <meta name="twitter:title" content="The Power of CSS Transforms: A Comprehensive Guide">
    <meta name="twitter:description" content="Explore the power of CSS transforms with this comprehensive guide. Learn about translate(), rotate(), scale(), skew(), and matrix() methods for dynamic web development.">
    <title>Transforms full Guide</title>

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        .transform_box {
            width: 50px;
            height: 50px;
            transition: all 0.9s ease;
            margin: 15px 0 0 0;
        }

        .scale:hover {
            transform: scale(0.5);
        }

        .scaleX:hover {
            transform: scaleX(0.5);
        }

        .rotate:hover {
            transform: rotate(45deg);
        }

        .skewX:hover {
            transform: skewX(-25deg);
        }

        .skew:hover {
            transform: skew(20deg, 5deg);
        }

        .translate:hover {
            transform: translate(5px, 10px);
        }

        .matrix:hover {
            transform: matrix(0.7, -0.5, 0.5, 0.4, 0.5, 0.7);
        }

        .bg-blue {
            background: #888;
        }

        .pxy {
            padding: 10px;
        }

        .bg-redbtn {
            background: #ededed;
            padding: 20px;
            border-radius: 20px;
            margin: 10px 0 20px 0
        }

        .d-flex {
            display: flex;
            gap: 2.5vw;
            align-items: center;
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">CSS Transforms full Guide</h2>
                    <p class="blog-post-meta">March 19, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <h4>Introduction to CSS Transforms: <a href="css_transforms_view.php" type="button" class="btn btn-outline-primary">Preview</a> </h4>
                    <p>CSS transforms offer builders a toolkit to manipulate elements through shifting, rotating, scaling, and skewing them. These alterations add a dynamic and visually enticing dimension to the net improvement. In this complete guide, we are able to delve into the diverse strategies of CSS transforms, offering insights into their packages and usage.</p>

                    <section>
                        <h2>Understanding CSS Transform Methods </h2>
                        <ol>
                            <li><strong>translate():</strong> The translate() technique shifts a detail along the X and Y axes. This is quite useful for creating smooth animations and repositioning elements dynamically.</li>

                            <li><strong>rotate():</strong> The Rotate() method allows you to rotate an element in the specified direction, making your layout more interesting.</li>

                            <li><strong>scaleX(), scaleY(), scale():</strong> Changing the scaling changes the size of the element. scaleX() and scaleY() allow an independent scale on the X and Y axes, while scale() provides a uniform scale.</li>

                            <li><strong>skewX(), skewY(), skew():</strong> A tilt transformation rotates an element along the X and Y axes. SkewX() and SkewY() provide independent skewing, while Skew() combines both.</li>

                            <li><strong>matrix():</strong> The Matrix() method provides full control over the 2D transformation by using a six-valued matrix.</li>
                        </ol>
                    </section>
                    <section>
                        <div class="pxy bg-redbtn flex_center">
                            <div>
                                <h2>Click the box to see the transform property effect</h2>
                            </div>
                            <div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box scale"></div>
                                    <p>transform: scale(0.5);</p>
                                </div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box scaleX"></div>
                                    <p>transform: scaleX(0.5);</p>
                                </div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box rotate"></div>
                                    <p> transform: rotate(45deg);</p>
                                </div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box skewX"></div>
                                    <p>transform: skewX(-25deg);</p>
                                </div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box skew"></div>
                                    <p>transform: skew(20deg, 5deg);</p>
                                </div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box translate"></div>
                                    <p>transform: translate(5px, 10px);</p>
                                </div>
                                <div class="d-flex">
                                    <div class="bg-blue transform_box matrix"></div>
                                    <p>transform: matrix(0.7, -0.5, 0.5, 0.4, 0.5, 0.7);</p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <p>The proper handling of CSS changes empowers developers to bring life and interactivity to their web design. Using these techniques opens up creative possibilities, enabling user interfaces to be engaging and dynamic. Add CSS transformations to your toolkit and watch your web development projects transform into visually stunning experiences.</p>
                        <a href="css_transforms_view.php" type="button" class="btn btn-outline-primary w-100">View Preview</a>
                    </section>

                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>