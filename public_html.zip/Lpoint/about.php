<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">

    <!-- Primary Meta Tags -->
    <title>masterinwebdesign - master in web design </title>
    <meta name="title" content="masterinwebdesign - master in web design ( html css javascript )" />
    <meta name="description" content="Join the web mastery challenge and create 50 articles and projects in 50 days. Learn, practice, and share your insights on LinkedIn with #masterinwebdesign. No certificates, but featured on completion. Start anytime, at your own pace. Challenge covers HTML, CSS, JavaScript basics to advanced, or create confidence-boosting projects." />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://masterinwebdesign.com/about" />
    <meta property="og:title" content="masterinwebdesign - master in web design ( html css javascript )" />
    <meta property="og:description" content="Join the web mastery challenge and create 50 articles and projects in 50 days. Learn, practice, and share your insights on LinkedIn with #masterinwebdesign. No certificates, but featured on completion. Start anytime, at your own pace. Challenge covers HTML, CSS, JavaScript basics to advanced, or create confidence-boosting projects." />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="https://masterinwebdesign.com/about" />
    <meta property="twitter:title" content="masterinwebdesign - master in web design ( html css javascript )" />
    <meta property="twitter:description" content="Join the web mastery challenge and create 50 articles and projects in 50 days. Learn, practice, and share your insights on LinkedIn with #masterinwebdesign. No certificates, but featured on completion. Start anytime, at your own pace. Challenge covers HTML, CSS, JavaScript basics to advanced, or create confidence-boosting projects." />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <section class="container py-5 mt-2">
        <h1>What is this?</h1>
        <p>This is a web mastery challenge in which you have to create 50 articles and projects in 50 days.
            You have to complete this challenge in the next 50 days, first you have been given an article, you have to
            read it, after that what have you learned from the article, you have to post it on LinkedIn. You have to
            write what you learned and also use #masterinwebdesign .If you complete this 50 day challenge you will be
            featured on our website.
        </p>
        <h4>How can I join?</h4>
        <p>
            All you need to get started with the challenge is a github account and a passion for programming (basics of
            html css and javascript).What you have to do for the next 50 days is told on the website.
        </p>
        <h4>Do I get a certificate after finishing the course?</h4>
        <p>No, but if you complete the challenge in 50 days, you will be featured on the website.</p>
        <h4>Do I have to take the challenge within a certain time frame?</h4>
        <p>No! You can take the challenge at your own pace, pause whenever you want and finish it whenever it suits your
            needs. The "50 Days" challenge is totally optional!</p>
        <h4>What will I get from this challenge ?</h4>
        <p>With this challenge you will cover the basics of HTML, CSS and JavaScript till advance or you can also create
            a project in this challenge which will give you confidence.</p>
    </section>
    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>