<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description -->
    <meta name="description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
    <meta name="keywords" content="CSS, Border Property, Web Design, CSS Borders, Border Styles, Length, Color, Border Radius">
    <meta name="author" content="Rajkumar Nimod">

    <!-- Page Title -->
    <title>CSS Border Property</title>

    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="Understanding the CSS Border Property">
    <meta property="og:description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.example.com/css-border-property">
    <meta property="og:image" content="https://www.example.com/images/css-border-guide.png">

    <!-- Twitter Meta Tags for Social Sharing -->
    <meta name="twitter:title" content="Understanding the CSS Border Property">
    <meta name="twitter:description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
    <meta name="twitter:url" content="https://www.example.com/css-border-property">
    <meta name="twitter:image" content="https://www.example.com/images/css-border-guide.png">

    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        .border_style {
            display: inline-block;
            padding: 5px 10px;
        }

        p.dotted {
            border: dotted;
        }

        p.dashed {
            border: dashed;
        }

        p.solid {
            border: solid;
        }

        p.double {
            border-style: double;
        }

        .border_style3d {
            padding: 2vw;
        }

        p.groove {
            border-style: groove;
        }

        p.ridge {
            border-style: ridge;
        }

        p.inset {
            border-style: inset;
        }

        p.outset {
            border-style: outset;
        }

        p.style3dp {
            border-width: 15px;
            border-color: rgb(14, 14, 14);
            margin: 10px;
            display: inline-block;
            padding: 15px 20px;
        }

        p.none {
            border-style: none;
            margin: 10px;
            display: inline-block;
            padding: 15px 20px;
        }

        p.hidden {
            border-style: hidden;
            margin: 10px;
            display: inline-block;
            padding: 15px 20px;
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">Uncovering the Potential of CSS Border Property: An All-Inclusive Manual
                    </h2>
                    <p class="blog-post-meta">March 12, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>An essential component of web design is the CSS border feature, which gives programmers the
                        ability to
                        improve an element's visual appeal. The border-style attribute, which determines the kind of
                        border to be
                        displayed, is the fundamental component of this property. To appreciate the variety it provides,
                        let's
                        examine a few different styles using real-world instances.</p>

                    <section>
                        <h2>Dotted Border: <a href="css_border_view.php" type="button" class="btn btn-outline-primary">Preview</a></h2>
                        <p>A row of dots is drawn along the border in the dotted style. To do this, change the border
                            style to dotted.
                            For instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .element {
      border-style: dotted;
    }</code></pre>
                            </div>
                        </div>
                        <p class="dotted border_style">Dotted Border / border: 2px dotted black;</p>
                    </section>
                    <section>
                        <h2>Dashed Border:</h2>
                        <p>The dashed style creates a border with dashed lines for a more pronounced divide. For
                            instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
        <code>
 .element {
       border-style: dashed;
 }</code></pre>
                            </div>
                        </div>
                        <p class="dashed border_style">Dashed Border / border: 2px dashed black;</p>
                    </section>
                    <section>
                        <h2>Solid Border:</h2>
                        <p>This is the most basic and default style; it creates a continuous, solid line. For instance:
                        </p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
 <code>
  .element {
        border-style: solid;
  }</code></pre>
                            </div>
                        </div>
                        <p class="solid border_style">Solid Border / border: 2px solid black;</p>
                    </section>
                    <section>
                        <h2>Double Border:</h2>
                        <p>The double style gives the impression of being bolder by drawing two parallel lines. For
                            instance:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
 <code>
  .element {
     border-style: double;
  }
        </code></pre>
                            </div>
                        </div>
                        <p class="double border_style">Double Border / border: 2px double black;</p>
                    </section>

                    <section>
                        <h2>3D Inset, Ridged, Outset, and Grooved Borders:</h2>
                        <p>These border styles, which depend on the border-color value for visual impact, add a
                            three-dimensional
                            effect. As an illustration:
                        </p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>
  .grooved {
    border-style: groove;
    border-color: #3498db;
  }
              
  .ridged {
    border-style: ridge;
    border-color: #e74c3c;
  }
              
  .inset {
    border-style: inset;
    border-color: #2ecc71;
  }
              
  .outset {
    border-style: outset;
    border-color: #f39c12;
  }</code></pre>
                            </div>
                            <div class="border_style3d bg-orangebtn">
                                <p class="inset style3dp">inset border.</p>
                                <p class="ridge style3dp">ridge border.</p>
                                <p class="outset style3dp">outset border.</p>
                                <p class="groove style3dp">groove border.</p>
                            </div>
                    </section>

                    <section>
                        <h2>No Border and Hidden Border:</h2>
                        <p>Borders are completely removed when border-style is set to none; they remain invisible but
                            take up space when
                            set to hidden. As an illustration:</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre> <code>
  .no-border { 
    border-style: none;
  }
              
   .hidden {
     border-style: hidden;
   }</code></pre>
                            </div>
                        </div>
                        <div class="border_style3d bg-orangebtn">
                            <p class="none">No Border</p>
                            <p class="hidden">Hidden Border</p>
                        </div>
                    </section>
                    <a href="css_border_view.php" type="button" class="btn btn-outline-primary w-100">view preview</a>
                </article>

                <article class="blog-post">
                    <h2>summary :</h2>
                    <p>Understanding these border-style variations empowers developers to craft visually appealing and
                        diverse
                        designs, elevating the aesthetics of web interfaces. Experimenting with these styles provides
                        hands-on
                        experience in leveraging the full potential of the CSS border property for creative and polished
                        web
                        development.</p>
                </article>
            </div>

           <!-- topics list -->
           <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>

    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>