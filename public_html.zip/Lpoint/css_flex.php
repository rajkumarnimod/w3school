<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Explore the power of Flexbox, a layout concept in Cascading Style Sheets (CSS), designed for efficient space allocation among container elements, even with variable sizes.">
    <meta name="keywords" content="Flexbox, CSS, Layout, Web Development, Responsive Design">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">
    <meta name="og:title" property="og:title" content="An Overview of Flexbox: CSS">
    <meta name="og:description" property="og:description" content="Explore the power of Flexbox, a layout concept in Cascading Style Sheets (CSS), designed for efficient space allocation among container elements, even with variable sizes.">
    <meta name="twitter:title" content="An Overview of Flexbox: CSS">
    <meta name="twitter:description" content="Explore the power of Flexbox, a layout concept in Cascading Style Sheets (CSS), designed for efficient space allocation among container elements, even with variable sizes.">
    <title>Flexbox full Guide</title>

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        section {
            margin-top: 20px;
        }

        /* --------------- width/height--------------------- */
        .w-20 {
            width: 20%;
        }

        .w-25 {
            width: 25%;
        }

        .w-33 {
            width: 33%;
        }

        .w-50 {
            width: 50%;
        }

        .w-75 {
            width: 75%;
        }

        .w-80 {
            width: 80%;
        }

        .w-90 {
            width: 90%;
        }

        .w-100 {
            width: 100%;
        }

        /* --------------------- background ------------------  */
        .bg-green {
            background: #bbf3ca;
        }

        .bg-greenbtn {
            background: #91cca1bb;
        }

        .bg-orange {
            background: #f3e7c3;
        }

        .bg-blue {
            background: #bad0f3;
        }

        .bg-w3 {
            background: #b4d5d5;
        }

        .bg-orangebtn {
            background: #f9e9b7c0;
        }

        .bg-red {
            background: #f2bbb6;
        }

        .bg-redbtn {
            background: #cb9c98ba;
        }

        .bg-black {
            background-color: #32312dc8;
        }

        /* ------------display property ------------------  */
        .inline {
            display: inline;
        }

        .inline-block {
            display: inline-block;
        }

        /* ----------------- border-radius---------------  */
        .r-10 {
            border-radius: 10px;
        }

        .r-20 {
            border-radius: 20px;
        }

        .r-30 {
            border-radius: 30px;
        }

        .r-100 {
            border-radius: 50%;
        }

        /* ------------------- border -----------------------------  */
        .b {
            border: 1px solid rgb(145, 143, 143);
        }

        .bt {
            border-bottom: 1px solid rgb(145, 143, 143);
        }

        .br {
            border-bottom: 1px solid rgb(145, 143, 143);
        }

        .bb {
            border-bottom: 1px solid rgb(145, 143, 143);
        }

        .bl {
            border-bottom: 1px solid rgb(145, 143, 143);
        }

        /* ---------------------------Text alignment--------------------- */

        .text-center {
            text-align: center;
        }

        .text-left {
            text-align: left;
        }

        .text-right {
            text-align: right;
        }

        /* ---------------------- padding / margin -----------------------  */
        .pxy {
            padding: 10px;
        }

        .px-1 {
            padding-inline: 10px;
        }

        .py-1 {
            padding-block: 10px;
        }

        .mxy {
            margin: 20px;
        }

        .mx-1 {
            margin-inline: 10px;
        }

        .my-1 {
            margin-block: 10px;
        }

        .mt-1 {
            margin-top: 10px;
        }

        .mt-2 {
            margin-top: 20px;
        }

        .mt-3 {
            margin-top: 30px;
        }

        .d-flex {
            display: flex;
            gap: 2vw;
            align-items: center;
        }

        .flex_center {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 5vw;
        }

        .flexcolum {
            display: flex;
            flex-direction: column;
        }

        .flex_justify_center {
            display: flex;
            justify-content: center;
        }

        /*------------------ copy code css start end------------------------  */
        .h {
            height: 50px;
        }

        .ffs {
            justify-content: flex-start;
        }

        .ffe {
            justify-content: flex-end;
        }

        .ffc {
            justify-content: center;
        }

        .fsa {
            justify-content: space-around;
        }

        .fsb {
            justify-content: space-between;
        }

        .fse {
            justify-content: space-evenly;
        }

        /* align items ----------------  */
        .faifs {
            align-items: flex-start;
        }

        .faife {
            align-items: flex-end;
        }

        .fais {
            align-items: stretch;
        }

        .faifc {
            align-items: center;
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">An Overview of Flexbox: CSS </h2>
                    <p class="blog-post-meta">March 17, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>A layout concept in Cascading Style Sheets (CSS) called Flexbox, or just Flexbox, was created to offer a more
                        effective and reliable method of allocating space among elements in a container, even when those items'
                        sizes are erratic or variable. The basic idea behind Flexbox is to allow the container to change the height
                        and breadth of its contents in order to optimize the amount of space that it can occupy.</p>

                    <section>
                        <h2>Flexbox properties <a href="css_flex_view.php" type="button" class="btn btn-outline-primary">Preview</a></h2>
                        <p>With features like display: flex, flex-direction, justify-content, align-items, and flex, flexbox makes
                            layout creation simpler. It increases the efficiency of web development by generating responsive and
                            adaptable architecture.</p>
                        <img src="./assets/flex_properties.png" alt="flex properties image" class="flex_properties" height="200px">
                    </section>

                    <section>
                        <h2>flex direction</h2>
                        <p>To change the direction of flex items, apply the flex-direction property to the flex container. The
                            flex-direction is initially set to 'row,' which arranges the items in a horizontal fashion.</p>

                        <div class="mt-2 pxy">
                            <div class="flex_center mt-2">
                                <h5>row(default)</h5>
                                <div class="bg-white flex_justify_center r-10 d-flex pxy inline-block w-80">
                                    <div class="r-10 w-25 h bg-green flex_center">1</div>
                                    <div class="r-10 w-25 h bg-red flex_center">2</div>
                                    <div class="r-10 w-25 h bg-orange flex_center">3</div>
                                    <div class="r-10 w-25 h bg-blue flex_center">4</div>
                                </div>
                            </div>

                            <div class="flex_center mt-2">
                                <h5>row-reverse</h5>
                                <div class="bg-white flex_justify_center r-10 d-flex pxy inline-block w-80">
                                    <div class="r-10 w-25 h bg-blue flex_center">4</div>
                                    <div class="r-10 w-25 h bg-orange flex_center">3</div>
                                    <div class="r-10 w-25 h bg-red flex_center">2</div>
                                    <div class="r-10 w-25 h bg-green flex_center">1</div>
                                </div>
                            </div>

                        </div>
                    </section>

                    <section>
                        <div class="flex_center pxy">
                            <div class=" flex_justify_center">
                                <h5>column</h5>
                            </div>
                            <div class="bg-white r-10 flexcolum pxy inline-block w-90">
                                <div class="r-10 w-100 h bg-blue flex_center mt-1">1</div>
                                <div class="r-10 w-100 h bg-orange flex_center mt-1">2</div>
                                <div class="r-10 w-100 h bg-red flex_center mt-1">3</div>
                                <div class="r-10 w-100 h bg-green flex_center mt-1">4</div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <div class="flex_center pxy">
                            <div class="w-20 flex_justify_center">
                                <h5>column-reverse</h5>
                            </div>
                            <div class="bg-white r-10 flexcolum pxy inline-block w-80">
                                <div class="r-10 w-100 h bg-green flex_center mt-1">4</div>
                                <div class="r-10 w-100 h bg-red flex_center mt-1">3</div>
                                <div class="r-10 w-100 h bg-orange flex_center mt-1">2</div>
                                <div class="r-10 w-100 h bg-blue flex_center mt-1">1</div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2>justify-content</h2>
                        <p>Flexbox aligns flex items along the main axis using the justify-content function. Item distribution within
                            the container is controlled by values such as flex-start, flex-end, center, space-between, space-around, and
                            space-evenly.</p>
                        <div class="mt-2 pxy">
                            <div class="flex_center mt-2">
                                <div class="text-center w-20">
                                    <p>flex-start(default)</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 ffs">
                                    <div style="width: 50px;" class="r-10 h bg-green flex_center">1</div>
                                    <div style="width: 50px;" class="r-10 h bg-red flex_center">2</div>
                                    <div style="width: 50px;" class="r-10 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-2">
                                <div class="text-center w-20">
                                    <p>flex-end</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 ffe">
                                    <div style="width: 50px;" class="r-10 h bg-green flex_center">1</div>
                                    <div style="width: 50px;" class="r-10 h bg-red flex_center">2</div>
                                    <div style="width: 50px;" class="r-10 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-2">
                                <div class="text-center w-20">
                                    <p>flex-center</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 ffc">
                                    <div style="width: 50px;" class="r-10 h bg-green flex_center">1</div>
                                    <div style="width: 50px;" class="r-10 h bg-red flex_center">2</div>
                                    <div style="width: 50px;" class="r-10 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-2">
                                <div class="text-center w-20">
                                    <p>space-around</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 fsa">
                                    <div style="width: 50px;" class="r-10 h bg-green flex_center">1</div>
                                    <div style="width: 50px;" class="r-10 h bg-red flex_center">2</div>
                                    <div style="width: 50px;" class="r-10 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-2">
                                <div class="text-center w-20">
                                    <p>space-between</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 fsb">
                                    <div style="width: 50px;" class="r-10 h bg-green flex_center">1</div>
                                    <div style="width: 50px;" class="r-10 h bg-red flex_center">2</div>
                                    <div style="width: 50px;" class="r-10 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-2">
                                <div class="text-center w-20">
                                    <p>space-evenly</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 fse">
                                    <div style="width: 50px;" class="r-10 h bg-green flex_center">1</div>
                                    <div style="width: 50px;" class="r-10 h bg-red flex_center">2</div>
                                    <div style="width: 50px;" class="r-10 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2>Flexbox Align Items</h2>
                        <p>
                            Within a container, flex elements are aligned along the cross axis by using the align-items property in
                            Flexbox. It enhances layout control for the content inside the flex container by controlling vertical
                            positioning with variables like flex-start, flex-end, center, baseline, and stretch.
                        </p>
                        <div class="mt-2 pxy">
                            <div class="flex_center mt-1">
                                <div class="text-center w-20">
                                    <p>flex-start</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 faifs" style="height: 170px;">
                                    <div class="r-10 w-33 h bg-green flex_center">1</div>
                                    <div class="r-10 w-33 h bg-red flex_center">2</div>
                                    <div class="r-10 w-33 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-1">
                                <div class="text-center w-20">
                                    <p>flex-end</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 faife" style="height: 170px;">
                                    <div class="r-10 w-33 h bg-green flex_center">1</div>
                                    <div class="r-10 w-33 h bg-red flex_center">2</div>
                                    <div class="r-10 w-33 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-1">
                                <div class="text-center w-20">
                                    <p>stretch</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 fais" style="height: 170px;">
                                    <div class="r-10 w-33 bg-green flex_center">1</div>
                                    <div class="r-10 w-33 bg-red flex_center">2</div>
                                    <div class="r-10 w-33 bg-orange flex_center">3</div>
                                </div>
                            </div>
                            <div class="flex_center mt-1">
                                <div class="text-center w-20">
                                    <p>center</p>
                                </div>
                                <div class="bg-black r-10 d-flex pxy inline-block w-80 faifc" style="height: 170px;">
                                    <div class="r-10 w-33 h bg-green flex_center">1</div>
                                    <div class="r-10 w-33 h bg-red flex_center">2</div>
                                    <div class="r-10 w-33 h bg-orange flex_center">3</div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2>flex-wrap</h2>
                        <p>Flexbox's flex-wrap property determines if flex elements must fit on a single line or can wrap across many
                            lines. For versatile layout control, values like nowrap, wrap, and wrap-reverse are available.
                        </p>
                    </section>

                    <section>
                        <h2>align-content</h2>
                        <p>The Flexbox align-content property modifies how flex lines are distributed inside a container. It regulates
                            how lines that are perpendicular to the main axis align. The alignment behavior is defined by values such as
                            stretch, space-between, space-around, center, flex-start, and flex-end. When it comes to managing surplus
                            space in the container, this feature is quite helpful.
                        </p>
                    </section>

                    <section>
                        <p>These days, most modern browsers feature flexbox, which is widely utilized to create responsive and adaptable
                            layouts. It makes the task of designing intricate layouts that adjust to different screen sizes and gadgets
                            easier.</p>
                    </section>

                    <a href="css_flex_view.php" type="button" class="btn btn-outline-primary w-100">view preview</a>
                </article>

            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>