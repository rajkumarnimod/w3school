<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn the basics of CSS text properties and margin settings. This guide provides examples of how to set text colors and margin values, with various formatting options explained in detail.">
    <meta name="keywords" content="CSS, Text Properties, Margin, Web Design, CSS Margin, CSS Text Color, CSS Examples, Web Development">
    <meta name="author" content="Rajkumar Nimod">

    <!-- Page Title -->
    <title>CSS Text Properties and Margin Guide</title>

    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="CSS Text Properties and Margin Guide">
    <meta property="og:description" content="Learn the basics of CSS text properties and margin settings. This guide provides examples of how to set text colors and margin values, with various formatting options explained in detail.">
    <meta property="og:type" content="article">

    <!-- Twitter Meta Tags for Social Sharing -->
    <meta name="twitter:title" content="CSS Text Properties and Margin Guide">
    <meta name="twitter:description" content="Learn the basics of CSS text properties and margin settings. This guide provides examples of how to set text colors and margin values, with various formatting options explained in detail.">
    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">CSS Text Properties
                    </h2>
                    <p class="blog-post-meta">March 12, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>In CSS, you can control how text looks and behaves using various properties. Here’s a simplified guide to some of the most important text properties with examples.</p>

                    <section>
                        <h2>Text Color</h2>
                        <p>The <b>color</b> property sets the color of your text. You can specify it in different ways.</p>
                        <ul>
                            <li> Color Name: "peru" </li>
                            <li> HEX Value: "#ffffff" </li>
                            <li> RGB Value: "rgb(255, 0, 255)" </li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    color: red; /* Sets text color to red */
 }</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Two Values:</b> The first value applies to the top and bottom, and the second value applies to the left and right.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px 20px; /* 10px top and bottom, 20px left and right */</code><pre></div>
                            </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Three Values:</b> The first value applies to the top, the second to the left and right, and the third to the bottom.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px 20px 30px; /* 10px top, 20px left and right, 30px bottom */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Four Values:</b> The values apply to the top, right, bottom, and left in that order (clockwise)</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px 20px 30px 40px; /* 10px top, 20px right, 30px bottom, 40px left */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <h2>Values </h2>
                        <ul>
                            <li><b>Length:</b> Specifies a fixed size for the margin</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px; /* Fixed margin of 10 pixels */</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Percentage:</b> Specifies the margin as a percentage of the element's containing block's width.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10%; /* 10% of the containing block's width */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Auto:</b> Lets the browser choose a suitable margin. This is often used to center elements.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 0 auto; /* Centers the element horizontally */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <h2>Margin Collapsing</h2>
                        <p>Top and bottom margins of adjacent elements sometimes collapse into a single margin. The resulting margin is equal to the larger of the two. For more details, you can look into "Mastering margin collapsing".</p>
                    </section>
                </article>

                <article class="blog-post">
                    <h2>Description:</h2>
                    <p>The margin property sets space around an element. Margins create extra space outside the element, while padding creates space inside.</p>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>