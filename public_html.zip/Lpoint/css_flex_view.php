<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Description -->
<meta name="description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
<meta name="keywords" content="CSS, Border Property, Web Design, CSS Borders, Border Styles, Length, Color, Border Radius">
<meta name="author" content="Rajkumar Nimod">

<!-- Page Title -->
<title>CSS Border Property</title>

<!-- Open Graph Meta Tags for Social Sharing -->
<meta property="og:title" content="Understanding the CSS Border Property">
<meta property="og:description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.example.com/css-border-property">
<meta property="og:image" content="https://www.example.com/images/css-border-guide.png">

<!-- Twitter Meta Tags for Social Sharing -->
<meta name="twitter:title" content="Understanding the CSS Border Property">
<meta name="twitter:description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
<meta name="twitter:url" content="https://www.example.com/css-border-property">
<meta name="twitter:image" content="https://www.example.com/images/css-border-guide.png">

<!-- SEO Meta Tags -->
<meta name="robots" content="index, follow">
<meta name="revisit-after" content="7 days">


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <style>
        .flex-box {
            width: 60px;
            height: 60px;
        }

        #result-section {
            width: 100%;
            height: 300px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgb(244, 230, 192);
        }

        #flex-buttons {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding-top: 20px;
        }

        #flex-buttons div {
            display: flex;
            align-items: stretch;
        }

        #flex-buttons div button {
            width: 200px;
            padding: 5px;
            margin: 1px;
            background-color: rgb(241, 189, 137);
            border: none;
            font-size: 1rem;
            cursor: pointer;
        }

        @media only screen and (max-width: 600px) {
            #flex-buttons div button {
                width: 100px;
                padding: 5px;
                margin: 2px;
                background-color: rgb(241, 189, 137);
                border: none;
            }
        }
        @media only screen and (max-width: 320px) {
            #flex-buttons div button {
                width: 250px;
                padding: 5px;
                margin: 2px;
                background-color: rgb(241, 189, 137);
                border: none;
            }
            #flex-buttons div {
            display: flex;
            align-items: stretch;
            flex-direction: column;
        }
        }
        .bg-blue{
            background-color: blueviolet;
        }
        .bg-red{
            background-color: tomato;
        }
        .bg-orange{
             background-color: orchid;
        }
    </style>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <section class="container">
        <div>
            <div id="result-section">
                <div class="flex-box bg-blue"></div>
                <div class="flex-box bg-red"></div>
                <div class="flex-box bg-orange"></div>
            </div>

            <div id="flex-buttons">
                <div>
                    <button onclick="applyFlex('flex-start')">flex-start</button>
                    <button onclick="applyFlex('flex-end')">flex-end</button>
                    <button onclick="applyFlex('center')">center</button>
                </div>
                <div>
                    <button onclick="applyFlex('space-between')">space-between</button>
                    <button onclick="applyFlex('space-around')">space-around</button>
                    <button onclick="applyFlex('space-evenly')">space-evenly</button>
                </div>
                <div>
                    <button onclick="applyAlignItems('flex-start')">align-items: flex-start</button>
                    <button onclick="applyAlignItems('flex-end')">align-items: flex-end</button>
                    <button onclick="applyAlignItems('center')">align-items: center</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

    <script>
        function applyFlex(value) {
            document.getElementById('result-section').style.justifyContent = value;
        }

        function applyAlignItems(value) {
            document.getElementById('result-section').style.alignItems = value;
        }
    </script>

</body>

</html>