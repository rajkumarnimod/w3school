document.addEventListener('DOMContentLoaded', function() {
    const copyIcons = document.querySelectorAll('.copy-icon');
    
    copyIcons.forEach(icon => {
      icon.addEventListener('click', function() {
        const textToCopy = this.nextElementSibling.textContent.trim();
        navigator.clipboard.writeText(textToCopy)
          .then(() => {
            // Update icon text
            const copiedText = document.createElement('span');
            copiedText.innerText = 'Copied';
            copiedText.classList.add('copied-text');
            this.parentNode.appendChild(copiedText);
  
            // Remove 'Copied' text after 2 seconds
            setTimeout(() => {
              copiedText.remove();
            }, 2000);
          })
          .catch(err => {
            console.error('Failed to copy text: ', err);
          });
      });
    });
  });