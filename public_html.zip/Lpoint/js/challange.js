var lead = [
    {level:"Intermediate", project:"project work", day:"Day- 1",full:"free resource",  info:"Html Introduction",link:"./challenge50days/50dayroadmap/Introduction.html"},
    {level:"Intermediate", project:"project work", day:"Day- 2",full:"free resource",  info:"Digital_Tapestry",link:"./challenge50days/50dayroadmap/Digital_Tapestry.html"},
    {level:"Intermediate", project:"project work", day:"Day- 3",full:"free resource",  info:"Installation",link:"./challenge50days/50dayroadmap/Installation.html"},
    {level:"Intermediate", project:"project work", day:"Day- 4",full:"free resource",  info:"Html First Page",link:"./challenge50days/50dayroadmap/First_HTML.html"},
    {level:"Intermediate", project:"project work", day:"Day- 5",full:"free resource",  info:"Html Tags",link:"./challenge50days/50dayroadmap/tags.html"},
    {level:"Intermediate", project:"project work", day:"Day- 6",full:"free resource",  info:"Class / Id",link:"./challenge50days/50dayroadmap/classid.html"},
    {level:"Intermediate", project:"project work", day:"Day- 7",full:"free resource",  info:"Html List",link:"./challenge50days/50dayroadmap/Lists.html"},
    {level:"Intermediate", project:"project work", day:"Day- 8",full:"free resource",  info:"Html Table",link:"./challenge50days/50dayroadmap/tables.html"},
    {level:"Intermediate", project:"project work", day:"Day- 9",full:"free resource",  info:"Html Form",link:"./challenge50days/50dayroadmap/form.html"},
    {level:"Intermediate", project:"project work", day:"Day- 10",full:"free resource",  info:"Html Media",link:"./challenge50days/50dayroadmap/media.html"},      
    {level:"Intermediate", project:"project work", day:"Day- 11",full:"free resource",  info:"Page Layout",link:"./challenge50days/50dayroadmap/layout.html"},
    {level:"Intermediate", project:"project work", day:"Day- 12",full:"free resource",  info:"Html Entities",link:"./challenge50days/50dayroadmap/entities.html"},
    {level:"Intermediate", project:"project work", day:"Day- 13",full:"free resource",  info:"Html Brackpoints",link:"./challenge50days/50dayroadmap/brackpoints.html"},
    {level:"Intermediate", project:"project work", day:"Day- 14",full:"free resource",  info:"Size Units",link:"./challenge50days/50dayroadmap/sizeunits.html"},
    {level:"Intermediate", project:"project work", day:"Day- 15",full:"free resource",  info:"Html Meta Tag",link:"./challenge50days/50dayroadmap/meta.html"}
 //    html end ////////////////// 
 
 ]
 
 
 function dayPrint() {
     var clutter = "";
     lead.forEach(function (obj) {
         clutter += ` <div class="card" style="background: #1e1818;">
         <div class="hea">
             <span class="title">${obj.level}</span>
             <span class="price">${obj.day}</span>
         </div>
         <p class="desc">${obj.info}</p>
         <ul class="lists">
             <li class="list">
                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path fill-rule="evenodd"
                         d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                         clip-rule="evenodd"></path>
                 </svg>
                 <span>${obj.full}</span>
             </li>
             <li class="list">
                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path fill-rule="evenodd"
                         d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                         clip-rule="evenodd"></path>
                 </svg>
                 <span>${obj.project}</span>
             </li>
         </ul>
         <a class="action" href="${obj.link}">Get Started</a>
     </div> `;
     });
     document.querySelector(".challenge_row").innerHTML = clutter;
 }
 dayPrint();