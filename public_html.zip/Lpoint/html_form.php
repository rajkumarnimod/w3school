<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Unveiling the Power of HTML <form> Tag: A Practical Guide">
    <meta name="keywords" content="HTML, Forms, HTML Form Elements, Input Types, Form Submission">
    <meta name="author" content="Rajkumar Nimod">

    <title>HTML Form Tag Guide</title>
    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row">
            <div class="col-lg-10 col-md-9" style="font-size: 1.1rem;">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">Power of HTML &lt;form&gt; Tag: A Practical Guide</h1>
                    <p class="blog-post-meta">March 6, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <h4>Anatomy of the HTML &lt;form&gt; tag</h4>
                    <p>The &lt;form&gt; tag is the container for form elements and attributes, facilitating the
                        collection and
                        submission of personal information. Key components include:</p>
                    <ul>
                        <li>action attribute:- Specifies the URL where the form information will be sent upon
                            submission.</li>
                        <li>method attribute:- Defines the HTTP method to be used for sending form information,
                            usually either GET or POST.</li>
                    </ul>

                    <h4>Key Elements Within the &lt;form&gt; Tag</h4>
                    <ol>
                        <li>&lt;input&gt; elements:- The &lt;input&gt; element is versatile, allowing users to input
                            various types of data.</li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;input type="text" id="name" required&gt;</code></pre>
                            </div>
                        </div>
                        <li>&lt;textarea&gt; Element:- The &lt;textarea&gt; element is used for multiline text
                            inputs.</li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;input type="textarea" id="name" required&gt;</code></pre>
                            </div>
                        </div>
                        <li>&lt;select&gt; Element (Dropdown):- The &lt;select&gt; element creates a drop-down menu.
                        </li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
 <code>&lt;select id="inquiry" name="inquiry" required&gt;</code>
      <code>&lt;option value="html">Html overview&lt;/option&gt;</code>
     <code>&lt;option value="css">Css overview&lt;/option&gt;</code>
      <code>&lt;option value="javascript">JavaScript&lt;/option&gt;</code>
 <code>&lt;/select&gt;</code></pre>
                            </div>
                        </div>
                        <li>&lt;button&gt; Element:- The &lt;button&gt; element is used for clickable buttons within
                            a form.</li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;button type="submit">Submit&lt;/button&gt;</code></pre>
                            </div>
                        </div>

                    </ol>
                    <h4>Real-life Example: Contact Us Form</h4>
                    <p>Let's positioned the &lt;form&gt; tag into action with a realistic example. Consider a "Contact
                        Us" form
                        that includes fields for the person's name, e-mail, message, and a dropdown for choosing the
                        inquiry kind.
                    </p>
                    <div>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;form&gt;
 <code>&lt;label for="name">Name:&lt;/label&gt;</code>
 <code>&lt;input type="text" id="name" name="name" required&gt;</code>
                
 <code>&lt;label for="email">Email:&lt;/label&gt;</code>
 <code>&lt;input type="email" id="email" name="email" required&gt;</code>
                
 <code>&lt;label for="message">Message:&lt;/label&gt;</code>
 <code>&lt;textarea id="message" name="message" rows="4" required>&lt;/textarea&gt;</code>
                
 <code>&lt;label for="inquiry">inquiry:&lt;/label&gt;</code>
 <code>&lt;select id="inquiry" name="inquiry" required&gt;</code>
        <code>&lt;option value="general">Html overview&lt;/option&gt;</code>
        <code>&lt;option value="support">Css overview&lt;/option&gt;</code>
        <code>&lt;option value="billing">JavaScript&lt;/option&gt;</code>
 <code>&lt;/select&gt;</code>
                
 <code>&lt;button type="submit">Submit&lt;/button&gt;</code>
 <code>&lt;/form&gt;</code></pre>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>