<!DOCTYPE html>
<html lang="en">

<head>
<!-- Primary Meta Tags -->
<title>Leaderboard - 50 Days Web Challenge</title>
<meta name="title" content="Leaderboard - 50 Days Web Challenge" />
<meta name="description" content="Join the 50 Days Web Challenge and compete to be among the top 100 participants. Test your skills in web design and development." />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://masterinwebdesign.com/WinningZone" />
<meta property="og:title" content="Leaderboard - 50 Days Web Challenge" />
<meta property="og:description" content="Join the 50 Days Web Challenge and compete to be among the top 100 participants. Test your skills in web design and development." />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="https://masterinwebdesign.com/WinningZone" />
<meta property="twitter:title" content="Leaderboard - 50 Days Web Challenge" />
<meta property="twitter:description" content="Join the 50 Days Web Challenge and compete to be among the top 100 participants. Test your skills in web design and development." />

 <!--INCLUDE file: commanstyle css file -->
  <?php include './commanstyle.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!--INCLUDE file: navbar_js -->
  <?php include './js/navbar_js.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!--INCLUDE file: cdn_js -->
  <?php include './js/cdn.php'; ?>
  <!--INCLUDE file: cdn_js -->


  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/navbar.css">
  <link rel="stylesheet" href="./css/winningzone.css">
</head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <!-- top left to right animation  -->
  <div class="topscroll">
  </div>

  <!--INCLUDE file: Navbar -->
  <?php include 'navbar.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!-- header section start  -->
  <header>
    <div class="container pb-5" id="header">
      <div class="row g-5">
        <div class="col-md-8 d-flex justify-content-center align-items-center flex-column">
          <h2 class="display-5 fw-bold" style="margin-top: 3.3vw;">50 DAYS WEB  <span style="color:#0B5ED7;">CHALLENGE</span>:<span class="text-muted"> The leaderboard</span></h2>
          <p title="masterinwebdesign hero line" style="padding-right: 3vw;"> Are you among the top 100 participants who joined the 50 Days Web Challenge?
        </div>
        <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
          <img src="assets/leaderboard.svg" alt="winningzone image" class="img-fluid mx-auto" width="500" height="500">
        </div>
      </div>
    </div>
  </header>
  <!-- header section end-->

  <section class="container leaderboard_member_sec">
    <div class="leaderboard_member_row">
     
    </div>
  </section>

  <!-- Footer -->
  <?php include 'footer.php'; ?>
  <!-- Footer -->

  <script src="./js/winningzone.js"></script>
</body>

</html>