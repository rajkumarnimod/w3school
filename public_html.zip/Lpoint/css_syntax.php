<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="An overview of Cascading Style Sheets (CSS) with practical examples">
  <meta name="keywords" content="CSS,Introduction, web development, styling, HTML, design">
  <meta name="author" content="rajkumar nimod">
  <title>CSS syntax with Examples</title>

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">An Overview of Cascading Style Sheets (CSS) with Practical Examples</h2>
                    <p class="blog-post-meta">March 8, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>The primary styling language used in web development is called Cascading Style Sheets (CSS), which gives
                        developers control over how online pages are presented visually. It is essential for improving the user
                        interface and experience because it specifies how HTML elements should be shown. To gain a better
                        understanding of CSS's practical applications, let's examine the language's foundations using examples from
                        everyday life.</p>
                    <h1>CSS's Importance in Web Development</h1>

                    <p>Imagine a plain HTML webpage that isn't styled. Although the content is present, it is disorganized and
                        lacks
                        visual appeal. This is where the use of CSS is necessary. Developers can use it to add fonts, colors,
                        spacing, and layout to an HTML structure to create a visually appealing and user-friendly website.</p>

                    <p>The true power of CSS is in its capacity to breathe life into HTML texts, enabling programmers to design
                        beautiful and useful websites. You'll learn more about CSS's adaptability and how it can be customized to
                        fit the specific design needs of any online project as you learn more about it.</p>

                    <h2>The three primary categories of CSS are external, internal, and inline styles.</h2>

                    <ul style="padding-top: 10px;">
                        <li><strong>Inline Styles:</strong> Applied directly with the style attribute inside HTML tags. <br> For
                            example: </li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
  <code>&lt;p style="color: blue;"&gt;This is a blue paragraph.&lt;/p&gt;</code></pre>
                            </div>
                        </div>
                        <li><strong>Internal Styles:</strong> Specified in the head part of the HTML document within the
                            &lt;style&gt; tag. <br> For example: </li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
  <code>&lt;head&gt;</code>
     <code>&lt;style&gt;</code>
      h1 {
         color: green;
         }
     <code>&lt;/style&gt;</code>
 <code>&lt;/head&gt;</code></pre>
                            </div>
                        </div>
                        <li><strong>External Styles:</strong> Linked to the HTML document and kept in a different CSS file.<br>
                            For
                            example: </li>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
 <code>&lt;head&gt;</code>
    <code>&lt;link rel="stylesheet" type="text/css" href="styles.css"&gt;</code>
 <code>&lt;/head&gt;</code></pre>
                            </div>
                        </div>
                    </ul>

                    <h2>css syntex :</h2>
                    <p>The syntax of CSS (Cascading Style Sheets) is organized around rulesets, which are made up of a selector, a
                        property, and a value.</p>
                    <p>
                        Rulesets, which are made up of a selector, property, and value, make up CSS syntax. Selectors apply a style attribute modification, whereas properties target HTML components. Values provide the chosen properties particular attributes. A ruleset can contain multiple properties, enabling thorough styling. The ease of use of the syntax enables developers to create and modify web pages' visual presentation in a sophisticated manner.
                    </p>
                    <h1 class="syntax">
                        <span style="color: peru;"> h1</span>{ <span style="color: teal;">font-size</span>: <span style="color: tomato;">20px</span>; }
                    </h1>
                    <div>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre>
  <code> h1        =  /* selector */; </code>
  <code> {         = /* declaration start / } declaration end */;</code>
  <code>font-size  = /* property */;</code>
  <code>:          = /* property/ value seprator */; </code>
  <code>20px       = /* value */;</code>
  <code>;          = /* declaration seprator */;</code></pre>
                            </div>
                        </div>
                    </div>
                    </section>
                </article>

                <article class="blog-post">
                    <h2>summary :</h2>
                    <p>
                        CSS is a crucial styling language in web development, allowing developers to control the visual presentation
                        of online pages. It specifies how HTML elements should be displayed, improving the user interface and
                        experience. CSS is essential for adding fonts, colors, spacing, and layout to an HTML structure, creating
                        visually appealing and user-friendly websites. It can be customized to fit specific design needs and is
                        divided into external, internal, and inline styles.
                    </p>
                </article>
            </div>

           <!-- topics list -->
           <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>