<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Description -->
<meta name="description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
<meta name="keywords" content="CSS, Border Property, Web Design, CSS Borders, Border Styles, Length, Color, Border Radius">
<meta name="author" content="Rajkumar Nimod">

<!-- Page Title -->
<title>CSS Border Property</title>

<!-- Open Graph Meta Tags for Social Sharing -->
<meta property="og:title" content="Understanding the CSS Border Property">
<meta property="og:description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.example.com/css-border-property">
<meta property="og:image" content="https://www.example.com/images/css-border-guide.png">

<!-- Twitter Meta Tags for Social Sharing -->
<meta name="twitter:title" content="Understanding the CSS Border Property">
<meta name="twitter:description" content="Learn how to use the CSS border property to create borders around elements. This guide covers how to set borders using various styles, and explores length, color, and border-radius values.">
<meta name="twitter:url" content="https://www.example.com/css-border-property">
<meta name="twitter:image" content="https://www.example.com/images/css-border-guide.png">

<!-- SEO Meta Tags -->
<meta name="robots" content="index, follow">
<meta name="revisit-after" content="7 days">


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        section {
            width: 100%;
            display: grid;
            place-items: center;
        }

        #result-section {
            width: 100%;
            height: 200px;
            border: 12px solid #20BEFF;
            margin-bottom: 20px;
        }

        #border-buttons {
            width: 100%;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 5px;
            justify-items: center;
        }

        #border-buttons button {
            width: 250px;
            padding: 10px;
            background-color: #9addf7;
            border: none;
            font-size: 1rem;
            cursor: pointer;
        }

        @media only screen and (max-width: 1024px) {
            #border-buttons {
                grid-template-columns: repeat(3, 1fr);
            }
        }
 @media only screen and (max-width: 991px) {
            #border-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media only screen and (max-width: 600px) {
            #border-buttons {
                grid-template-columns: 1fr;
            }

            #border-buttons button {
                width: 100%;
            }
        }
    </style>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 2.5rem;">
        <div>
            <h2 class="text-center">Border property preview online</h2>
            <hr>
        </div>
        <section>
            <div id="result-section"></div>
            <div id="border-buttons">
                <button onclick="applyBorder('dotted')">Dotted</button>
                <button onclick="applyBorder('dashed')">Dashed</button>
                <button onclick="applyBorder('solid')">Solid</button>
                <button onclick="applyBorder('double')">Double</button>
                <button onclick="applyBorder('groove')">Groove</button>
                <button onclick="applyBorder('ridge')">Ridge</button>
                <button onclick="applyBorder('inset')">Inset</button>
                <button onclick="applyBorder('outset')">Outset</button>
                <button onclick="applyBorder('none')">None</button>
                <button onclick="applyBorder('hidden')">Hidden</button>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

    <script>
        function applyBorder(borderStyle) {
            document.getElementById('result-section').style.borderStyle = borderStyle;
        }
    </script>

</body>

</html>