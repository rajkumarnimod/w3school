<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="English">
    <meta name="revisit-after" content="7 days">
    <!-- Primary Meta Tags -->
    <!-- Title and Description -->
    <title>Introduction to CSS - masterinwebdesign</title>
    <meta name="title" content="Introduction to CSS" />
    <meta name="description" content="Learn the basics of CSS (Cascading Style Sheets) and how to use it to style and layout web pages. This guide covers CSS syntax, key concepts, and practical examples." />


    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4vw;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">Introduction to css</h1>
                    <p class="blog-post-meta">March 11, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <h4>CSS, or Cascading Style Sheets: </h4>
                    <p>CSS (Cascading Style Sheets) is a language used to style and layout web pages. With CSS, you can change the font, color, size, and spacing of your content, split it into multiple columns, or add animations and other decorative features. This guide introduces you to the basics of CSS, its syntax, and how to start using it to add styling to HTML.</p>

                    <h4>Prerequisites: </h4>
                    <p>Before starting with CSS, you should: </p>
                    <ul>
                        <li> Have basic computer skills and know how to use the Web for browsing and consuming content. </li>
                        <li> Set up a basic work environment as described in "Installing basic software" and know how to create and manage files, as detailed in "Dealing with files." </li>
                        <li> Be familiar with HTML, as discussed in the "Introduction to HTML" module. </li>
                    </ul>
                    <h4>What is CSS? </h4>
                    <p>CSS (Cascading Style Sheets) lets you create attractive web pages, but how does it work? This section explains what CSS is with a simple syntax example and introduces some key terms.</p>

                    <h4>Getting Started with CSS : </h4>
                    <p>In this section, you'll learn to apply CSS to a simple HTML document, gaining practical knowledge of the language.</p>

                    <h4>How CSS is Structured: </h4>
                    <p>Now that you have an idea of what CSS is and the basics of using it, it’s time to delve deeper into the structure of the language. This section revisits concepts you’ve learned and serves as a recap if you find later topics confusing.</p>

                </article>
            </div>
           <!-- topics list -->
           <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>

    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>