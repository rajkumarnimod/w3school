<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn how to use CSS font properties to style text effectively. This guide covers font family, size, stretch, style, variant, weight, and line height, complete with examples.">
    <meta name="keywords" content="CSS, Font Properties, Web Design, Font Family, Font Size, Font Stretch, Font Style, Font Variant, Font Weight, Line Height, Typography">
    <meta name="author" content="Rajkumar Nimod">

    <!-- Page Title -->
    <title>CSS Font Properties Guide</title>

    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="CSS Font Properties Guide">
    <meta property="og:description" content="Learn how to use CSS font properties to style text effectively. This guide covers font family, size, stretch, style, variant, weight, and line height, complete with examples.">
    <meta property="og:type" content="article">

    <!-- Twitter Meta Tags for Social Sharing -->
    <meta name="twitter:title" content="CSS Font Properties Guide">
    <meta name="twitter:description" content="Learn how to use CSS font properties to style text effectively. This guide covers font family, size, stretch, style, variant, weight, and line height, complete with examples.">

    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">CSS Font Properties
                    </h2>
                    <p class="blog-post-meta">March 12, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>CSS allows you to style text in a variety of ways to improve the appearance and readability of your website content. This article discusses major font features and provides examples to help you understand how to apply them effectively.</p>

                    <section>
                        <h2>Font Family</h2>
                        <p>The font-family attribute specifies the typeface of the text. As a fallback system, you can specify a list of font names.</p>

                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    font-family: Arial, Helvetica, sans-serif; 
}</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <h2>Font Size</h2>
                        <p>The font-size property controls the size of the text. You can provide the size in pixels, ems, rems, percentages, or other units.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>h1 {
    font-size: 24px;
}</code><pre></div>
                            </div>
                    </section>
                    <section>
                       <h2>Font Stretch</h2>
                        <p>The font-stretch parameter controls the width of the text. It can be used to make the text narrower or larger.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    font-stretch: expanded; 
}</code><pre></div>
                            </div>
                            <p>Available values for font-stretch include:</p>
                            <ul>
                           <li> normal </li>
                           <li> condensed </li>
                           <li> ultra-condensed </li>
                           <li> extra-condensed </li>
                           <li> semi-condensed </li>
                           <li> expanded </li>
                           <li> semi-expanded </li>
                           <li> extra-expanded </li>
                           <li> ultra-expanded </li>
                            </ul>
                    </section>
                    <section>
                        <h2>Font Style</h2>
                        <p>The font-style property specifies the style of the text, such as italic or oblique.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    font-style: italic;
   }</code><pre></div></div>
                    </section>
                    <section>
                        <h2>Font Weight</h2>
                        <p>The font-weight parameter determines the thickness of the text.  It ranges from 100 to 900, where 400 is equivalent to normal, and 700 is equivalent to bold.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    font-style: italic;
   }</code><pre></div> </div>
                    </section>
                    <section>
                        <h2>Line Height</h2>
                        <p>The line-height attribute specifies the spacing between lines of text. It can be set in units, percentages, or as a multiple of the font size.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    line-height: 1.5; 
  }</code><pre></div> </div>
                    </section>
                    <section>
                        <h2>Combining Font Properties</h2>
                        <p>CSS additionally includes a shorthand property for setting numerous font properties in a single declaration: font. This shorthand configures the font style, variation, weight, size, line height, and family all at once.</p>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>p {
    font: italic small-caps bold 16px/1.5 Arial, sans-serif; 
   }</code><pre></div> </div>
                    </section>
                   
                </article>

                <article class="blog-post">
                    <p>Using these CSS font settings, you may significantly improve the typography of your web pages, making the text more appealing and readable.</p>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>