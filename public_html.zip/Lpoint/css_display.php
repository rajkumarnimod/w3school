<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about the CSS display property and its values: inline, inline-block, and block. Understand how to use these properties to manage the layout and arrangement of web elements effectively.">
    <meta name="keywords" content="CSS, Display Property, Inline, Inline-Block, Block, Web Design, CSS Layout, Web Development">
    <meta name="author" content="Rajkumar Nimod">

    <!-- Page Title -->
    <title>CSS Display Property  Guide</title>

    <!-- Open Graph Meta Tags for Social Sharing -->
    <meta property="og:title" content="Understanding the CSS Display Property">
    <meta property="og:description" content="Learn about the CSS display property and its values: inline, inline-block, and block. Understand how to use these properties to manage the layout and arrangement of web elements effectively.">
    <meta property="og:type" content="article">

    <!-- Twitter Meta Tags for Social Sharing -->
    <meta name="twitter:title" content="Understanding the CSS Display Property">
    <meta name="twitter:description" content="Learn about the CSS display property and its values: inline, inline-block, and block. Understand how to use these properties to manage the layout and arrangement of web elements effectively.">

    <!-- SEO Meta Tags -->
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">Css Display Property </h2>
                    <p class="blog-post-meta">March 17, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>The display property in CSS is an important tool for influencing the layout and appearance of HTML elements. This property controls how an element is displayed on a web page. In this tutorial, we'll look at three crucial values: inline, inline-block, and block. We'll go over each one in detail and provide examples to show how it works.</p>

                    <section>
                        <h2>Inline</h2>
                        <p>Elements with display: inline do not start on a new line and take up only the appropriate width. Common inline elements are &lt;span&gt;, &lt;a&gt;, and &lt;strong&gt;.</p>

                        <p>Characteristics:</p>
                        <ul>
                            <li> Does not start on a new line. </li>
                            <li> Width and height cannot be set. </li>
                            <li> Margins and paddings can be applied, but they do not affect the line height. </li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;head&gt;
    &lt;style&gt;
        .inline-ex {
            display: inline;
            background-color: lightblue;
            padding: 5px;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;p&gt;This is an &lt;span class="inline-ex"&gt;inline element&lt;/span&gt; within a paragraph.&lt;/p&gt;
&lt;/body&gt;</code></pre>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2>Inline-Block</h2>
                        <p>Elements with display: inline-block behave similarly to inline elements, but they allow you to select width and height, and margins and paddings are maintained.</p>

                        <p>Characteristics:</p>
                        <ul>
                            <li> Does not start on a new line. </li>
                            <li> Width and height can be set. </li>
                            <li> Margins and paddings are respected. </li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;head&gt;
    &lt;style&gt;
        .inline-block-ex {
            display: inline-block;
            width: 100px;
            height: 50px;
            background-color: lightcoral;
            padding: 10px;
            margin: 5px;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;div class="inline-block-ex"&gt;Inline-Block box 1&lt;/div&gt;
&lt;div class="inline-block-ex"&gt;Inline-Block box 2&lt;/div&gt;
&lt;/body&gt;</code></pre>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h2>Block</h2>
                        <p>Elements with display: block begin on a new line and take up the entire width available. Common block elements include &lt;div&gt;, &lt;p&gt;, and &lt;h1&gt; to &lt;h6&gt;.</p>

                        <p>Characteristics:</p>
                        <ul>
                          <li> Starts on a new line. </li>
                          <li> Takes up the full width available. </li>
                          <li> Width and height can be set. </li>
                          <li> Margins and paddings are respected. </li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>&lt;head&gt;
    &lt;style&gt;
        .block-ex {
            display: block;
            width: 200px;
            height: 100px;
            background-color: lightgreen;
            margin: 10px 0;
            padding: 15px;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;div class="block-ex"&gt;Inline-Block box 1&lt;/div&gt;
&lt;div class="block-ex"&gt;Inline-Block box 2&lt;/div&gt;
&lt;/body&gt;</code></pre>
                            </div>
                        </div>
                    </section>

                </article>

                <article class="blog-post">
                    <p>Understanding the display property and its three values—inline, inline-block, and block—is critical for successful web design. Each value has a unique purpose, allowing you to carefully manage the arrangement of your web pieces. Use inline for elements that should flow within text, inline-block for components that require size modifications but still flow inline, and block for elements that should take up their entire line and width. Mastering these qualities allows you to create more adaptable and visually appealing web designs.</p>
                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>