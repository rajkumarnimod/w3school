<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Primary Meta Tags -->
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="distribution" content="global">
    <meta name="revisit-after" content="7 days">
    <meta name="rating" content="general">
    <meta name="theme-color" content="#peru">
    <title>Color Palettes for Webdesigner</title>
    <meta name="title" content="Color Palettes for Webdesigner" />
    <meta name="description" content="Discover unique color palettes handpicked for web designers and artists. Get inspired for your next design project or elevate your artistic endeavors with our curated hues." />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://masterinwebdesign.com/colorplattes" />
    <meta property="og:title" content="Color Palettes for Webdesigner" />
    <meta property="og:description" content="Discover unique color palettes handpicked for web designers and artists. Get inspired for your next design project or elevate your artistic endeavors with our curated hues." />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="https://masterinwebdesign.com/colorplattes" />
    <meta property="twitter:title" content="Color Palettes for Webdesigner" />
    <meta property="twitter:description" content="Discover unique color palettes handpicked for web designers and artists. Get inspired for your next design project or elevate your artistic endeavors with our curated hues." />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <style>
        /* Styles only applied to elements within this code block */
        #color_palttes_row {
            max-width: 1150px;
            margin: auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, 16rem);
            gap: 2rem;
            align-items: flex-start;
            justify-content: center;
        }

        .color_palttes_col {
            width: 100%;
            border-radius: 3px;
            margin-bottom: 10px;
            cursor: pointer;
        }

        .mini-app-container .mini-app-box {
            margin: 5px;
            padding: 10px;
            height: 180px;
            position: relative;
            background-color: #1d1d1d;
            color: transparent;
        }

        .mini-app-container .copy-icon {
            position: absolute;
            top: 5px;
            right: 5px;
            cursor: pointer;
        }

        .mini-app-container .copied-text {
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.8);
            color: #fff;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
        }

        pre {
            white-space: pre-wrap;
            word-wrap: break-word;
        }

        @media screen and (max-width: 768px) {
            .mini-app-container .mini-app-box {
                flex: 1 0 calc(50% - 20px);
                /* Responsive adjustment for 2-column layout */
            }
        }

        @media screen and (max-width: 480px) {
            .mini-app-container .mini-app-box {
                flex: 1 0 calc(100% - 20px);
                /* Responsive adjustment for single column layout */
            }
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <section class="py-5 my-3 text-center">
        <h1 class="display-5 fw-bold mt-2">Color <span style="color:#0B5ED7;">Palettes </span> for Webdesigner</h1>
        <div class="col-lg-8 mx-auto">
            <p class="mb-4 fs-5">Welcome to our chosen color palettes for designers and artists. Whether you're looking
                for inspiration for your next design project or want to improve your artistic efforts, our hand-picked
                palettes provide a variety of hues to spark your imagination.</p>
        </div>
    </section>

    <section id="color_palttes_row">
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#ff8e3c;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#ff8e3c;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#d9376e;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#d9376e;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#abd1c6;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#abd1c6;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#f3d2c1;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#f3d2c1;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#8bd3dd;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#8bd3dd;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#f582ae;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#f582ae;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#001858;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#001858;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#bae8e8;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#bae8e8;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#ffd803;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#ffd803;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#d4d4e7;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#d4d4e7;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#fec7d7;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#fec7d7;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#8546f0;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#8546f0;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#982c71;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#982c71;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#cb5ea3;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#cb5ea3;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#f0d980;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#f0d980;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#e6d490;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#e6d490;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#f9ebb3;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#f9ebb3;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#7BC9FF;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#7BC9FF;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#A3FFD6;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#A3FFD6;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#DBA979;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#DBA979;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#ECCA9C;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#ECCA9C;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#E8EFCF;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#E8EFCF;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#AFD198;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#AFD198;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#003C43;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#003C43;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#135D66;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#135D66;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#77B0AA;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#77B0AA;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#f078e6;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#f078e6;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#d9f295;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#E3FEF7;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#FFEBB2;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#FFEBB2;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#E59BE9;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#E59BE9;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#D862BC;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#D862BC;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#8644A2;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#8644A2;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#A79277;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#A79277;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#D1BB9E;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#D1BB9E;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#EAD8C0;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#EAD8C0;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#FFF2E1;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#FFF2E1;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#86469C;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#86469C;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#BC7FCD;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#BC7FCD;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#FB9AD1;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#FB9AD1;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#FFCDEA;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#FFCDEA;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#A34343;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#A34343;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#E9C874;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#E9C874;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#FBF8DD;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#FBF8DD;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#C0D6E8;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#C0D6E8;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#D20062;"><span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#D20062;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#D6589F;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#D6589F;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#D895DA;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#D895DA;</pre>
            </div>
        </div>
        <div class="mini-app-container" class="color_palttes_col">
            <div class="mini-app-box" style="background:#C4E4FF;">
                <span class="copy-icon">
                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                </span>
                <pre>background:#C4E4FF;</pre>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const copyIcons = document.querySelectorAll('.copy-icon');

            copyIcons.forEach(icon => {
                icon.addEventListener('click', function() {
                    const textToCopy = this.nextElementSibling.textContent.trim();
                    navigator.clipboard.writeText(textToCopy)
                        .then(() => {
                            // Update icon text
                            const copiedText = document.createElement('span');
                            copiedText.innerText = 'Copied';
                            copiedText.classList.add('copied-text');
                            this.parentNode.appendChild(copiedText);

                            // Remove 'Copied' text after 2 seconds
                            setTimeout(() => {
                                copiedText.remove();
                            }, 2000);
                        })
                        .catch(err => {
                            console.error('Failed to copy text: ', err);
                        });
                });
            });
        });
    </script>

</body>

</html>