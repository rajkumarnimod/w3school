<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
    <!-- Primary Meta Tags -->
    <title>50 Days Web Challenge - masterinwebdesign</title>
    <meta name="title" content="50 Days Web Challenge - masterinwebdesign" />
    <meta name="description" content="Take up the 50 Days Web Design Challenge! Improve your HTML, CSS, and JavaScript skills from beginner to advanced. Share your progress with #50DAYSWEBDESIGNCHALLENGE on social media. Enhance your coding abilities by completing daily challenges and building new projects. Join the web development community and embark on this exciting journey!" />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">

    <style>
        @import url("https://fonts.googleapis.com/css2?family=Montserrat:wght@100;400;700&display=swap");

        header {
            text-align: center;
            background: #000;
            padding-top: 2rem;
        }

        header h1 {
            font-size: 5rem;
            margin: 0;
            color: #fff;
            text-transform: uppercase;
        }

        header h2 {
            color: #fff;
            font-weight: 100;
        }

        .article-meta {
            color: #fff;
            border-bottom: 1px solid #333333;
            border-top: 1px solid #333333;
        }

        .article-meta p {
            display: inline-block;
        }

        .section {
            padding: 4rem 2rem;
            background: #000;
        }

        .container-aut {
            width: 90%;
            margin: auto;
        }

        .tag {
            color: #bc4e9c;
            border-radius: 25px;
            font-size: 13px;
            display: inline-block;
            padding: 3px 14px;
            margin: 4px 0;
        }

        .flex_div {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-pack: justify;
            -ms-flex-pack: justify;
            justify-content: space-between;
        }

        .fullwidth {
            width: 100%;
        }

        .half {
            width: 45%;
        }

        .one_third {
            width: 30%;
        }

        .one_fourth {
            width: 25%;
        }

        figure {
            width: 100%;
            margin: 0;
        }

        figcaption {
            display: none;
        }

        .mag_content {
            padding: 20px;
            background: #1f1e1d;
        }

        .mag_content p {
            color: rgba(255, 255, 255, 0.5);
            line-height: 26px;
            font-weight: 400;
        }

        .mag_content h2 {
            color: #fff;
            margin-top: 0;
        }

        .spacer {
            height: 20px;
        }

        @media (max-width: 1024px) {
            .one_fourth {
                width: 100%;
            }

            .half {
                width: 100%;
                margin-top: 20px;
            }
        }

        .Aut_container {
            display: grid;
            gap: 10px;
            padding: 4vw;
        }

        .Aut_container div {
            height: 400px;
            clip-path: polygon(50% 0%, 100% 0, 100% 90%, 91% 100%, 0 100%, 0 92%, 0 0);
        }

        @media (min-width: 1200px) {
            .Aut_container {
                grid-template-columns: repeat(4, 1fr);
            }

            .Aut_container div {
                height: 400px;
            }
        }

        @media (min-width: 992px) and (max-width: 1199px) {
            .Aut_container {
                grid-template-columns: repeat(4, 1fr);
            }

            .Aut_container div {
                height: 350px;
            }
        }

        @media (min-width: 768px) and (max-width: 991px) {
            .Aut_container {
                grid-template-columns: repeat(3, 1fr);
            }

            .Aut_container div {
                height: 300px;
            }
        }

        @media (max-width: 767px) {
            .Aut_container {
                grid-template-columns: repeat(2, 1fr);
            }

            .Aut_container div {
                height: 250px;
            }
        }

        @media (max-width: 420px) {
            .Aut_container {
                grid-template-columns: 1fr;
            }
        }

        .Aut_container div img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }

        .Aut_container div figure {
            width: 100%;
            height: 100%;
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <header>

        <p style="color: #fff;">ABOUT AUTHOR</p>
        <h1 class="headline">RAJKUMAR NIMOD</h1>
        <h2 class="subhead">Hey! My name is Rajkumar. I am a frontend designer based in India.</h2>
    </header>

    <section class="section">
        <div class="container-aut flex_div">
            <div class="one_fourth">
                <figure>
                    <img src="./assets/author/aut2.jpg" alt="rajkumarnimod" width="100%" title="rajkumar nimod" />
                    <figcaption>rajkumar nimod</figcaption>
                </figure>
                <div class="mag_content">
                    <h3 style="color: #fff;">Rajkumar: A Journey of Passion and Purpose</h3>
                    <p>Rajkumar is a name that resonates with passion, creativity, and a deep sense of responsibility. As a web design teacher and an environmental activist, Rajkumar seamlessly blends his professional expertise with his commitment to making the world a better place. His life story is an inspiring testament to how one can effectively balance multiple roles while leaving a positive impact on society.</p>
                </div>

                <div class="spacer"></div>
                <div class="mag_content">
                    <h3 style="color: #fff;">Commitment to Environmental Activism</h3>
                    <p>Beyond his professional achievements, Rajkumar is dedicated to environmental activism. He began his journey by participating in local clean-up drives and awareness campaigns to combat urbanization's impact on natural habitats. His efforts in promoting sustainability have earned him recognition, and he leads by example, practicing sustainable living. Rajkumar believes everyone has a role in protecting the environment.
                    </p>
                </div>
            </div>
            <div class="half">
                <figure>
                    <img src="./assets/author/aut5.jpg" alt="rajkumarnimod" width="100%" title="rajkumar nimod" />
                    <figcaption>rajkumarnimod</figcaption>
                </figure>
                <div class="mag_content">
                    <h3 style="color: #fff;">A Passion for Web Design</h3>
                    <p>From a young age, Rajkumar was fascinated by the digital world. His curiosity led him to explore the intricacies of web design, a field where creativity meets technology. As he honed his skills, he realized the potential of the internet in shaping the modern world. Today, as a web design teacher, Rajkumar imparts his knowledge and passion to his students, guiding them to create aesthetically pleasing and functional websites.

                        Rajkumar's teaching style is dynamic and engaging. He believes in a hands-on approach, encouraging his students to experiment with different design elements and technologies. His classes are a hub of creativity, where students are motivated to think outside the box and develop unique solutions. Rajkumar's dedication to his craft is evident in the success of his students, many of whom have gone on to make significant contributions to the field of web design.</p>
                </div>
                <div class="spacer"></div>
                <div class="mag_content">
                    <figure>
                        <img src="https://cdn.pixabay.com/photo/2024/06/14/12/15/developer-8829735_1280.jpg" alt="rajkumarnimod" width="100%" title="rajkumar nimod" />
                        <figcaption>Photo by Nick Jones</figcaption>
                    </figure>
                </div>
            </div>
            <div class="one_fourth">
                <figure>
                    <img src="./assets/author/aut5.jpg" alt="rajkumarnimod" width="100%" title="rajkumar nimod" />
                    <figcaption>Photo by Nick Jones</figcaption>
                </figure>
                <div class="mag_content">
                    <h3 style="color: #fff;">A Positive Influence</h3>
                    <p>Rajkumar's multifaceted life is a beacon of positivity and purpose. His students admire him not just for his expertise in web design but also for his unwavering commitment to the environment. He teaches them the importance of following their passions while being mindful of their responsibilities towards the planet.
                    </p>
                    <p>
                        Through his work and travels, Rajkumar continues to inspire those around him. He proves that it is possible to pursue multiple interests and make a meaningful impact. His life story encourages others to explore their own passions and find ways to contribute positively to society.
                    </p>
                    <p>
                        In conclusion, Rajkumar is a remarkable individual who exemplifies the power of passion and purpose. As a web design teacher, environmental activist, and avid traveler, he has created a life that is both fulfilling and impactful. His journey serves as a reminder that with dedication and a positive outlook, one can achieve great things and inspire others along the way.</p>
                </div>
                <div class="spacer"></div>
            </div>
        </div>
    </section>

    <section class="Aut_container">
        <div>
            <figure>
                <img src="./assets/author/aut2.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
        <div>
            <figure>
                <img src="./assets/author/aut3.webp" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
        <div>
            <figure>
                <img src="./assets/author/aut4.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
        <div>
            <figure>
                <img src="./assets/author/aut11.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
        <div>
            <figure>
                <img src="./assets/author/aut5.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
        <div>
            <figure>
                <img src="./assets/author/aut6.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>

        <div>
            <figure>
                <img src="./assets/author/aut8.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
        <div>
            <figure>
                <img src="./assets/author/aut9.jpg" alt="rajkumarnimod" title="rajkumar nimod" />
                <figcaption>rajkumar nimod</figcaption>
            </figure>
        </div>
    </section>
    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>