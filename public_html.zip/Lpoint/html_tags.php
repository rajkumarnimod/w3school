<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Guide to HTML Tags</title>
    <!-- Meta Tags -->
    <meta name="description" content="A complete guide to HTML tags, covering document structure tags, heading tags, comments, favicon, paragraph and text formatting tags, lists, links, images, tables, forms, and additional tags.">
    <meta name="keywords" content="HTML, HTML tags, web development, document structure, headings, comments, favicon, formatting, lists, links, images, tables, forms, web design">
    <meta name="author" content="rajkumar nimod">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">
    <meta name="language" content="English">
    <meta property="og:title" content="Complete Guide to HTML Tags">
    <meta property="og:description" content="A complete guide to HTML tags, covering document structure tags, heading tags, comments, favicon, paragraph and text formatting tags, lists, links, images, tables, forms, and additional tags.">
    <meta name="og:site_name" content="Complete Guide to HTML Tags">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Complete Guide to HTML Tags">
    <meta name="twitter:description" content="A complete guide to HTML tags, covering document structure tags, heading tags, comments, favicon, paragraph and text formatting tags, lists, links, images, tables, forms, and additional tags.">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <style>
        code {
            font-size: 1.1rem;
            color: #202124;
        }
    </style>
    <script src="./js/tutscript.js"></script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h1 class="blog-post-title">Complete Guide to HTML Tags</h1>
                    <p class="blog-post-meta">March 10, 2024 by  <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>

                    <h4>Document Structure Tags</h4>
                    <p><code>&lt;DOCTYPE html&gt;</code>:The document type is specified by</p>
                    <p><code>&lt;html&gt;</code> :(Root Detail): Encloses all HTML content.</p>
                    <p> <code>&lt;body&gt;</code>: Holds the webpage's content.</p>
                    <p><code>&lt;head&gt;</code>: Contains metadata like title, scripts, and stylesheets.</p>

                    <h4>Heading Tags</h4>
                    <p><code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code>: Define headings of various levels.</p>
                    <p>Example: <code>&lt;h1&gt;Main Heading&lt;/h1&gt;</code>, <code>&lt;h4&gt;Subheading&lt;/h4&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <!----- Container Content ------>
                            <pre><code>&lt;h1&gt;Hello, World!&lt;/h1&gt;</code>
<code>&lt;h4&gt;Hello, World!&lt;/h4&gt;</code></pre>
                        </div>
                    </div>

                    <h4>Html Comment</h4>
                    <p>It is used to add comment in the source code. Comment is not displayed in the browsers.</p>
                    <p>Example: <code>&lt;! ----Html Comment-----&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;! ----Html Comment-----&gt;</code></pre>
                        </div>
                    </div>

                    <h4>Html Favicon Image</h4>
                    <ul>
                        <li>It is a small icon or logo found in front of the website.</li>
                        <li>There are png, jpg, gif, svg and icon image formats supported.</li>
                        <li>must comes under the <code>&lt;head&gt;</code> tag</li>
                    </ul>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;link rel="shortcut icon" href="favicon.ico" type="image/x-icon"&gt;</code></pre>
                        </div>
                    </div>

                    <h4>Paragraph and Text Formatting Tags</h4>
                    <p><code>&lt;p&gt;</code>: Defines a paragraph.</p>
                    <p>Example: <code>&lt;p&gt;This is a paragraph.&lt;/p&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;p&gt;This is a paragraph.&lt;/p&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;br&gt;</code>: Inserts a line break.</p>
                    <p>Example: This is a line. This is another line.</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;p&gt;This is a line.<code>&lt;br&gt;This is another line&lt;/p&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;strong&gt;</code>: Bold text.</p>
                    <p>Example: <code>&lt;strong&gt;This text is bold.&lt;/strong&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;strong&gt;This text is bold.&lt;/strong&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;em&gt;</code>: Emphasizes text (typically italics).</p>
                    <p>Example: <code>&lt;em&gt;This text is emphasized.&lt;/em&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;em&gt;This text is emphasized.&lt;/em&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;mark&gt;</code>: Marked text (often highlighted).</p>
                    <p>Example: <code>&lt;mark&gt;This text is marked.&lt;/mark&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;mark&gt;This text is marked.&lt;/mark&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;b&gt;</code> or <code>&lt;strong&gt;</code>: Bold text.</p>
                    <p>Example: <code>&lt;b&gt;This text is bold.&lt;/b&gt;</code> or
                        <code>&lt;strong&gt;This text is also bold, with great semantic significance.&lt;/strong&gt;</code>
                    </p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;b&gt;This text is bold.&lt;/b&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;i&gt;</code> or <code>&lt;em&gt;</code>: Italic text.</p>
                    <p>Example: <code>&lt;i&gt;This text is in italic.&lt;/i&gt;</code> or
                        <code>&lt;em&gt;This text is emphasized and often displayed in italics.&lt;/em&gt;</code>
                    </p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;i&gt;This text is in italic.&lt;/i&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;u&gt;</code>: Underlined text.</p>
                    <p>Example: <code>&lt;u&gt;This text is underlined.&lt;/u&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;u&gt;This text is underlined.&lt;/u&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;del&gt;</code> or <code>&lt;s&gt;</code>: Strikethrough text.</p>
                    <p>Example: <code>&lt;del&gt;This text is deleted.&lt;/del&gt;</code> or
                        <code>&lt;s&gt;This text is also struck through.&lt;/s&gt;</code>
                    </p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;del&gt;This text is deleted.&lt;/del&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;sup&gt;</code>: Superscript text.</p>
                    <p>Example: H<sup>2</sup>O</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;sup&gt;Superscript text.&lt;/sup&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;sub&gt;</code>: Subscript text.</p>
                    <p>Example: X<sub>2</sub></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;sub&gt;Subscript text&lt;/sub&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;small&gt;</code>: Smaller text.</p>
                    <p>Example: This is <code>&lt;small&gt;small text&lt;/small&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;small&gt;Smaller text.&lt;/small&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;ins&gt;</code>: Inserted text.</p>
                    <p>Example: This text will be <code>&lt;ins&gt;added&lt;/ins&gt;</code> later.</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;ins&gt;Inserted text.&lt;/ins&gt;</code></pre>
                        </div>
                    </div>
                    <p><code>&lt;abbr&gt;</code>: Abbreviation.</p>
                    <p>Example: The <code>&lt;abbr name="World Wide Web"&gt;WWW&lt;/abbr&gt;</code> is an extensive network.</p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre><code>&lt;abbr&gt;Abbreviation.&lt;/abbr&gt;</code></pre>
                        </div>
                    </div>

                    <h4>Lists</h4>
                    <p><code>&lt;ul&gt;</code>: Unordered list (bullet points).</p>
                    <p>Example: <code>&lt;ul&gt;&lt;li&gt;Item 1&lt;/li&gt;&lt;li&gt;Item 2&lt;/li&gt;&lt;/ul&gt;</code></p>

                    <p><code>&lt;ol&gt;</code>: Ordered list (numbered items).</p>
                    <p>Example: <code>&lt;ol&gt;&lt;li&gt;Step 1&lt;/li&gt;&lt;li&gt;Step 2&lt;/li&gt;&lt;/ol&gt;</code></p>

                    <h4>Links</h4>
                    <p><code>&lt;a&gt;</code>: Defines a link.</p>
                    <p>Example: <code>&lt;a href="https://www.example.com"&gt;Click here&lt;/a&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre> <code>&lt;a href="https://www.example.com"&gt;Click here&lt;/a&gt;</code></pre>
                        </div>
                    </div>

                    <h4>Images</h4>
                    <p><code>&lt;img&gt;</code>: Embeds an image.</p>
                    <p>Example: <code>&lt;img src="picture.jpg" alt="Image description"&gt;</code></p>
                    <div class="mini-app-container">
                        <div class="mini-app-box">
                            <span class="copy-icon">
                                <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                            </span>
                            <pre> <code>&lt;img src="picture.jpg" alt="Image description"&gt;</code></pre>
                        </div>
                    </div>

                    <h4>Tables</h4>
                    <p><code>&lt;table&gt;</code>: Defines a table.</p>
                    <p><code>&lt;tr&gt;</code>: Defines a table row.</p>
                    <p><code>&lt;td&gt;</code>: Defines a table cell.</p>
                    <p><code>&lt;th&gt;</code>: Defines a table header cell.</p>

                    <h4>Forms</h4>
                    <p><code>&lt;form&gt;</code>: Defines a form for the user to enter.</p>
                    <p><code>&lt;input&gt;</code>: Creates various form elements (text fields, buttons, etc.).</p>
                    <p><code>&lt;label&gt;</code>: Labels for form elements.</p>

                    <h4>Additional Tags</h4>
                    <p><code>&lt;div&gt;</code>: Defines a section of content.</p>
                    <p><code>&lt;span&gt;</code>: Defines a section of inline content.</p>
                    <p><code>&lt;header&gt;</code>: Defines a header section.</p>
                    <p><code>&lt;footer&gt;</code>: Defines a footer section.</p>
                    <p><code>&lt;nav&gt;</code>: Defines a navigation section.</p>
                    <p><code>&lt;article&gt;</code>: Defines an article section.</p>
                    <p><code>&lt;section&gt;</code>: Defines a generic section.</p>

                </article>
            </div>

            <!-- topics list -->
            <?php include 'topics.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>