<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="author" content="Rajkumar nimod">
  <meta name="language" content="English">
  <meta name="distribution" content="global">
  <meta name="rating" content="general">

  <!-- Primary Meta Tags -->
  <title>Css Gradient Backgrounds | masterinwebdesign</title>
  <meta name="title" content="Css Gradient Backgrounds | masterinwebdesign" />
  <meta name="description" content="Explore a diverse range of css gradient backgrounds to enhance your website's visual appeal. Our SEO-optimized palettes offer seamless transitions and vibrant hues to captivate your audience and boost search engine visibility." />

  <!-- Open Graph / Facebook -->
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://masterinwebdesign.com/Gradient-background" />
  <meta property="og:title" content="Css Gradient Backgrounds | masterinwebdesign" />
  <meta property="og:description" content="Explore a diverse range of css gradient backgrounds to enhance your website's visual appeal. Our SEO-optimized palettes offer seamless transitions and vibrant hues to captivate your audience and boost search engine visibility." />

  <!-- Twitter -->
  <meta property="twitter:url" content="https://masterinwebdesign.com/Gradient-background" />
  <meta property="twitter:title" content="Css Gradient Backgrounds | masterinwebdesign" />
  <meta property="twitter:description" content="Explore a diverse range of css gradient backgrounds to enhance your website's visual appeal. Our SEO-optimized palettes offer seamless transitions and vibrant hues to captivate your audience and boost search engine visibility." />

  <!--INCLUDE file: commanstyle css file -->
  <?php include './commanstyle.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!--INCLUDE file: navbar_js -->
  <?php include './js/navbar_js.php'; ?>
  <!--INCLUDE file: Navbar -->

  <!--INCLUDE file: cdn_js -->
  <?php include './js/cdn.php'; ?>
  <!--INCLUDE file: cdn_js -->

  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/navbar.css">
  <style>
    /* Styles only applied to elements within this code block */
    #color_palttes_row {
      max-width: 1150px;
      margin: auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, 20rem);
      gap: 2rem;
      align-items: flex-start;
      justify-content: center;
    }

    .color_palttes_col {
      width: 100%;
      border-radius: 3px;
      margin-bottom: 10px;
      cursor: pointer;
    }

    .mini-app-container .mini-app-box {
      margin: 5px;
      padding: 10px;
      height: 230px;
      position: relative;
      border-radius: 10px;
      background-color: #1d1d1d;
      color: transparent;
    }

    .mini-app-container .copy-icon {
      position: absolute;
      top: 7px;
      right: 7px;
      cursor: pointer;
    }

    .mini-app-container .copied-text {
      position: absolute;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      background-color: rgba(0, 0, 0, 0.8);
      color: #fff;
      padding: 5px 10px;
      border-radius: 3px;
      font-size: 14px;
    }

    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    @media screen and (max-width: 768px) {
      .mini-app-container .mini-app-box {
        flex: 1 0 calc(50% - 20px);
        /* Responsive adjustment for 2-column layout */
      }
    }

    @media screen and (max-width: 480px) {
      .mini-app-container .mini-app-box {
        flex: 1 0 calc(100% - 20px);
        /* Responsive adjustment for single column layout */
      }
    }
  </style>
</head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <!-- top left to right animation  -->
  <div class="topscroll">
  </div>

  <!--INCLUDE file: Navbar -->
  <?php include 'navbar.php'; ?>
  <!--INCLUDE file: Navbar -->

  <section class="container py-5 my-2 text-center">
    <h1 class="display-5 fw-bold mt-2">Enhance Your <span style="color:#0B5ED7;"> Website </span> with Different Gradient Backgrounds.
    </h1>
    <div class="col-lg-8 mx-auto">
      <p class="mb-4 fs-5">Our large assortment of gradient backdrops will add to the appeal of your website. Our
        palettes are designed to be versatile and visually appealing, with a wide range of colors to suit any design
        aesthetic. Explore smooth transitions and brilliant colors to fascinate your audience and boost your online
        presence.</p>
    </div>
  </section>

  <section id="color_palttes_row">
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(90deg, #FAD961 0%, #F76B1C 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(90deg, #FAD961 0%, #F76B1C 100%);pre>
          </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
          <div class="mini-app-box" style="background: linear-gradient(23deg, #f9a5a0 0%, #dcd3f8 100%);
          "><span class="copy-icon">
              <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
            </span>
            <pre>background: linear-gradient(23deg, #f9a5a0 0%, #dcd3f8 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(to left,#efe4a5, #a1e6dd, #e5c897 80%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(to top, #baebdf, #b5d1e3, #efe4a5, #a1e6dd, #e5c897 80%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(125deg, #f5d451 0%, #1da98d 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(125deg, #f5d451 0%, #1da98d 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(175deg, #a2beee 0%, #f4ace0 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(175deg, #a2beee 0%, #f4ace0 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(to top, #7ac3d4, #8992d5);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(23deg, #f9a5a0 0%, #dcd3f8 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(90deg, #74EBD5 0%, #9FACE6 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(90deg, #74EBD5 0%, #9FACE6 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(21deg, #f6a4a0 0%, #d7cef5 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(21deg, #f6a4a0 0%, #d7cef5 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(100deg, #fddf3a 0%, #e36389 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(100deg, #fddf3a 0%, #e36389 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(90deg, #ead03f 0%, #eb618a 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(90deg, #ead03f 0%, #eb618a 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(245deg, #f13ba2 0%, #7d4aaa 55%, #2987ca 100%);">
        <span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(245deg, #f13ba2 0%, #7d4aaa 55%, #2987ca 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #86c8e1 0%, #085fb6 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #86c8e1 0%, #085fb6 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #FFDB58 0%, #FF7F50 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #FFDB58 0%, #FF7F50 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #228B22 0%, #00FF00 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #228B22 0%, #00FF00 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #E6E6FA 0%, #8A2BE2 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #E6E6FA 0%, #8A2BE2 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #FF6F61 0%, #A020F0 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #FF6F61 0%, #A020F0 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #E0115F 0%, #800020 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #E0115F 0%, #800020 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #FFF44F 0%, #7FFF00 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #FFF44F 0%, #7FFF00 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #008080 0%, #000080 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #008080 0%, #000080 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #FFE5B4 0%, #FF69B4 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #FFE5B4 0%, #FF69B4 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #40E0D0 0%, #00FFFF 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #40E0D0 0%, #00FFFF 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #FFD700 0%, #CD7F32 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #FFD700 0%, #CD7F32 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #C0C0C0 0%, #808080 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #C0C0C0 0%, #808080 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #EE82EE 0%, #4B0082 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #EE82EE 0%, #4B0082 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #FFA500 0%, #8A360F 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #FFA500 0%, #8A360F 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #93ef93 0%, #18b218 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #98FF98 0%, #2E8B57 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background:linear-gradient(135deg, #d29cd2 0%, #990d89 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background:linear-gradient(135deg, #d29cd2 0%, #990d89 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #8a7689 0%, #e8664c 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #8a7689 0%, #e8664c 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #e990e6c4 0%, #bf05ed 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #e990e6c4 0%, #bf05ed 100%);</pre>
      </div>
    </div>
    <div class="mini-app-container" class="color_palttes_col">
      <div class="mini-app-box" style="background: linear-gradient(135deg, #536daa 0%, #59d2db 100%);"><span class="copy-icon">
          <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
        </span>
        <pre>background: linear-gradient(135deg, #536daa 0%, #59d2db 100%);</pre>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <?php include 'footer.php'; ?>
  <!-- Footer -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const copyIcons = document.querySelectorAll('.copy-icon');

      copyIcons.forEach(icon => {
        icon.addEventListener('click', function() {
          const textToCopy = this.nextElementSibling.textContent.trim();
          navigator.clipboard.writeText(textToCopy)
            .then(() => {
              // Update icon text
              const copiedText = document.createElement('span');
              copiedText.innerText = 'Copied';
              copiedText.classList.add('copied-text');
              this.parentNode.appendChild(copiedText);

              // Remove 'Copied' text after 2 seconds
              setTimeout(() => {
                copiedText.remove();
              }, 2000);
            })
            .catch(err => {
              console.error('Failed to copy text: ', err);
            });
        });
      });
    });
  </script>

</body>

</html>