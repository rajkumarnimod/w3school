<footer class="text-center text-lg-start bg-body-tertiary">
    <section class="py-4">
        <div class="container text-center text-md-start">
            <div class="row">
                <div class="col col-md-5 col-lg-3 col-xl-5 mb-2 mx-auto foot_col">
                    <!-- Content -->
                    <div class="mb-4">
                        <img src="./assets/logo.png" alt="masterinwebdesign logo" width="160px">
                    </div>
                    <p>
                        Master front-end skills for a career. Achieve mastery through practice.
                        Prep for interviews with coding challenges. Start now to land your dream job. Build a
                        supportive community for learning and growth.
                    </p>
                    <p>
                        <i class="fas fa-envelope me-1"></i>
                        <a href="mailto: info@masterinwebdesign.com" class="text-decoration-none text-dark"> info@masterinwebdesign.com</a>
                    </p>
                </div>
                <div class="col-6 col-md-5 col-lg-3 col-xl-3 mb-2 mx-auto foot_col">
                    <h4 class="text-uppercase mb-4 fs-5">Ressources</h4>
                    <p><a href="colorplattes.php" class="text-reset text-decoration-none" target="_blank">Color palettes</a></p>
                    <p><a href="Gradient-background.php" class="text-reset text-decoration-none" target="_blank">Gradient Background</a></p>
                    <p><a href="https://pixabay.com/images/search/" class="text-reset text-decoration-none" target="_blank">Free Image</a></p>
                    <p><a href="https://undraw.co/illustrations" class="text-reset text-decoration-none" target="_blank">Free illustrations</a></p>
                </div>
                <div class="col-6 col-md-5 col-lg-3 col-xl-2 mb-2 mx-auto foot_col">
                    <!-- Links -->
                    <h4 class="text-uppercase mb-4 fs-5">Navlinks</h4>
                    <p><a href="index.php" class="text-reset text-decoration-none" target="_blank">Home</a></p>
                    <p><a href="project.php" class="text-reset text-decoration-none" target="_blank">Projects</a></p>
                    <p><a href="./blog.html" class="text-reset text-decoration-none" target="_blank">Blog</a></p>
                    <p><a href="WinningZone.php" class="text-reset text-decoration-none" target="_blank">WinningZone</a></p>
                </div>
                <div class="col-6 col-md-5 col-lg-3 col-xl-2 mb-2 mx-auto foot_col">
                    <!-- Links -->
                    <h4 class="text-uppercase mb-4 fs-5"> Useful links</h4>
                    <p><a href="about.php" class="text-reset text-decoration-none" target="_blank">About </a></p>
                    <p><a href="registration.php" class="text-reset text-decoration-none" target="_blank">Contact</a></p>
                    <p><a href="Disclaimer.php" class="text-reset text-decoration-none" target="_blank">Disclaimer</a></p>
                    <p><a href="Privacy_policy.php" class="text-reset text-decoration-none" target="_blank">Privacy policy</a></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Copyright -->
    <div class="text-center py-3 px-4" style="background-color: rgba(0, 0, 0, 0.05);">
        <div>
            © <a class="text-reset text-decoration-none" href="index.php">mwd</a> || All right reserved
        </div>
        <div class="Copyright_link">
            <a href="about.php" class="text-reset text-decoration-none mx-2" target="_blank">About </a>
            <a href="registration.php" class="text-reset text-decoration-none mx-2" target="_blank">Contact</a>
            <a href="Disclaimer.php" class="text-reset text-decoration-none mx-2" target="_blank">Disclaimer</a>
            <a href="Privacy_policy.php" class="text-reset text-decoration-none mx-2" target="_blank">Privacy policy</a>
            <a href="#" class="text-reset text-decoration-none mx-2" target="_blank">Sitemap</a>
        </div>
    </div>
    <!-- Copyright -->
</footer>