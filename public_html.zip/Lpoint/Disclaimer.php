<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Primary Meta Tags -->
    <title>disclaimer - masterinwebdesign</title>
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="author" content="Rajkumar nimod">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">

    <!-- Primary Meta Tags -->
<title>disclaimer - masterinwebdesign</title>
<meta name="title" content="disclaimer - masterinwebdesign" />
<meta name="description" content="Read our disclaimer regarding the content and information presented on this website." />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://masterinwebdesign.com/Disclaimer" />
<meta property="og:title" content="disclaimer - masterinwebdesign" />
<meta property="og:description" content="Read our disclaimer regarding the content and information presented on this website." />

<!-- Twitter -->
<meta property="twitter:url" content="https://masterinwebdesign.com/Disclaimer" />
<meta property="twitter:title" content="disclaimer - masterinwebdesign" />
<meta property="twitter:description" content="Read our disclaimer regarding the content and information presented on this website." />

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>
    <style>
        .disclaimer_heading {
            width: 100%;
            padding: 4vw 1rem;
            background-color: rgb(252, 209, 166);
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: #202124;
        }

        .disclaimer {
            margin-top: 3vw;
        }

        @media screen and (max-width: 600px) {
            .disclaimer_heading {
                padding: 10vw 1rem 5vw 1vw;
            }

            .disclaimer {
                margin-top: 4vw;
                padding: 0 1rem;
            }
        }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->

    <section>
        <div class="disclaimer_heading">
            <h1>Disclaimer for masterinwebdesign</h1>
        </div>
        <div class="container disclaimer">
            <p>If you require any more information or have any questions about our site's disclaimer, please feel free
                to contact us by email at info@masterinwebdesign.com. </p>

            <h3>Disclaimers for masterinwebdesign</h3>

            <p>All the information on this website - https://masterinwebdesign.com/ - is published in good faith and for
                general information purpose only. masterinwebdesign does not make any warranties about the completeness,
                reliability and accuracy of this information. Any action you take upon the information you find on this
                website (masterinwebdesign), is strictly at your own risk. masterinwebdesign will not be liable for any
                losses and/or damages in connection with the use of our website.</p>

            <p>From our website, you can visit other websites by following hyperlinks to such external sites. While we
                strive to provide only quality links to useful and ethical websites, we have no control over the content
                and nature of these sites. These links to other websites do not imply a recommendation for all the
                content found on these sites. Site owners and content may change without notice and may occur before we
                have the opportunity to remove a link which may have gone 'bad'.</p>

            <p>Please be also aware that when you leave our website, other sites may have different privacy policies and
                terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well
                as their "Terms of Service" before engaging in any business or uploading any information.</p>

            <h3>Consent</h3>

            <p>By using our website, you hereby consent to our disclaimer and agree to its terms.</p>

            <h3>Update</h3>

            <p>Should we update, amend or make any changes to this document, those changes will be prominently posted
                here.</p>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>