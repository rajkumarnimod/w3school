<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn how to use the CSS margin property to create space around elements. This guide covers how to set margins using one, two, three, or four values, and explores length, percentage, and auto values.">
    <meta name="keywords" content="CSS, Margin Property, Web Design, CSS Margins, Margin Values, Length, Percentage, Auto, Margin Collapsing">
    <meta name="author" content="Rajkumar Nimod">
    <title>CSS Margin Property</title>

    <!-- Open Graph meta tags for social sharing -->
    <meta property="og:title" content="Understanding the CSS Margin Property">
    <meta property="og:description" content="Learn how to use the CSS margin property to create space around elements. This guide covers how to set margins using one, two, three, or four values, and explores length, percentage, and auto values.">
    <meta property="og:type" content="website">
    <meta name="twitter:title" content="Understanding the CSS Margin Property">
    <meta name="twitter:description" content="Learn how to use the CSS margin property to create space around elements. This guide covers how to set margins using one, two, three, or four values, and explores length, percentage, and auto values.">
    <meta name="robots" content="index, follow">
    <meta name="revisit-after" content="7 days">

    <!--INCLUDE file: commanstyle css file -->
    <?php include './commanstyle.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: navbar_js -->
    <?php include './js/navbar_js.php'; ?>
    <!--INCLUDE file: Navbar -->

    <!--INCLUDE file: cdn_js -->
    <?php include './js/cdn.php'; ?>
    <!--INCLUDE file: cdn_js -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/tutstyle.css">
    <script src="./js/tutscript.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N37GWT54" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- top left to right animation  -->
    <div class="topscroll">
    </div>

    <!--INCLUDE file: Navbar -->
    <?php include 'navbar.php'; ?>
    <!--INCLUDE file: Navbar -->


    <main class="container" style="margin-top: 4rem;">
        <div class="row g-4">
            <div class="col-lg-10 col-md-9">
                <article class="blog-post px-1">
                    <h2 class="blog-post-title">Margin Property in CSS
                    </h2>
                    <p class="blog-post-meta">March 12, 2024 by <a href="author.php" target="_blank"><span style="color: #323232;">RajkumarNimod</span></a></p>
                    <hr>
                    <p>The margin property in CSS is used to create space around elements. You can set the margins using one, two, three, or four values. Each value can be a length, a percentage, or the keyword auto. You can even use negative values to pull an element closer to its neighbors.</p>

                    <section>
                        <h2>Using One, Two, Three, or Four Values: </h2>
                        <ul>
                            <li><b>One Value:</b> Applies the same margin to all four sides</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 20px; /* 20px on top, right, bottom, and left */</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Two Values:</b> The first value applies to the top and bottom, and the second value applies to the left and right.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px 20px; /* 10px top and bottom, 20px left and right */</code><pre></div>
                            </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Three Values:</b> The first value applies to the top, the second to the left and right, and the third to the bottom.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px 20px 30px; /* 10px top, 20px left and right, 30px bottom */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Four Values:</b> The values apply to the top, right, bottom, and left in that order (clockwise)</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px 20px 30px 40px; /* 10px top, 20px right, 30px bottom, 40px left */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <h2>Values </h2>
                        <ul>
                            <li><b>Length:</b> Specifies a fixed size for the margin</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10px; /* Fixed margin of 10 pixels */</code></pre>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Percentage:</b> Specifies the margin as a percentage of the element's containing block's width.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 10%; /* 10% of the containing block's width */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <ul>
                            <li><b>Auto:</b> Lets the browser choose a suitable margin. This is often used to center elements.</li>
                        </ul>
                        <div class="mini-app-container">
                            <div class="mini-app-box">
                                <span class="copy-icon">
                                    <img width="30" height="30" src="https://img.icons8.com/ios/30/FFFFFF/copy--v1.png" alt="copy-code" />
                                </span>
                                <pre><code>margin: 0 auto; /* Centers the element horizontally */</code><pre></div>
                        </div>
                    </section>
                    <section>
                        <h2>Margin Collapsing</h2>
                        <p>Top and bottom margins of adjacent elements sometimes collapse into a single margin. The resulting margin is equal to the larger of the two. For more details, you can look into "Mastering margin collapsing".</p>
                    </section>
                </article>

                <article class="blog-post">
                    <h2>Description:</h2>
                    <p>The margin property sets space around an element. Margins create extra space outside the element, while padding creates space inside.</p>
                </article>
            </div>

             <!-- topics list -->
             <?php include 'topics_css.php'; ?>
            <!-- topics list -->
        </div>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    <!-- Footer -->

</body>

</html>